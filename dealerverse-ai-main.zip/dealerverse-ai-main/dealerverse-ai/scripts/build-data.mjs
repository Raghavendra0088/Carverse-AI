/**
 * DealerVerse AI — data pipeline
 * Reads the real CarVerse event log (170k+ rows) and precomputes a compact
 * JSON the app loads instantly. Scores ONLY meaningful milestones (once per
 * booking) and credits the ACTUAL actor's real department, so EVERY department
 * is gamified for what it really does. Everything is real.
 *
 *   node scripts/build-data.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import Papa from "papaparse";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.resolve(__dirname, "../../carverse files");
const OUT = path.resolve(__dirname, "../src/data/dealerverse.json");

const read = (f) =>
  Papa.parse(fs.readFileSync(path.join(DATA_DIR, f), "utf8"), {
    header: true, skipEmptyLines: true,
  }).data;

console.log("Reading CSVs…");
const events = read("z_event_log_may_june_2026.csv");
const employees = read("z_employees.csv");
const locations = read("z_locations.csv");
console.log(`  ${events.length} events · ${employees.length} employees · ${locations.length} locations`);

// ---------- department normalization ----------
// The 7 real departments we gamify. Everything else (TRANSPORT, SECURITY, HR…) is ignored.
const GAMIFIED = ["SALES", "FINANCE", "ACCOUNTS", "EDP", "CUSTOMER CARE", "PDI", "RTO / REGN TEAM"];
const normDept = (raw) => {
  const d = (raw || "").trim().toUpperCase();
  if (d === "CCM") return "CUSTOMER CARE";
  if (d === "RTO" || d.startsWith("RTO")) return "RTO / REGN TEAM";
  return d;
};
const isGamified = (d) => GAMIFIED.includes(d);

// ---------- lookups ----------
const locName = {};
locations.forEach((l) => (locName[l.location_code] = l.location_name));

const emp = {};
employees.forEach((e) => {
  emp[e.id] = {
    id: e.id, name: e.name || e.id, dept: normDept(e.department),
    designation: e.designation || "", manager: e.manager || "",
    loc: e.loc_code || "", locName: locName[e.loc_code] || e.loc_code || "",
  };
});

// ---------- scoring config — meaningful milestones only (17 total, under the 20 cap) ----------
// Credited to whoever actually performs them -> XP lands on the real department.
const MILESTONE_XP = {
  // SALES
  BOOKING_CREATED: 20, DISCOUNT_APPROVED: 30, INVOICE_APPROVED_SALES: 25, RGISTRATION_APPROVED_SALES: 25,
  // ACCOUNTS
  GATEPASS_ISSUED_BY_ACCOUNTS: 100, CREDIT_APPROVED: 45,
  // EDP (backend ops)
  INVOICE_APPROVED_EDP: 45, RGISTRATION_CREATED_EDP: 25,
  // EDP + RTO/REGN both file this one — credited to whoever did it
  REGISTRATION_ADDED: 40,
  // CUSTOMER CARE
  INSURANCE_APPROVED_BY_CCM: 40, DISPATCH_BY_CCM: 20, GATEPASS_BY_CCM: 20,
  // PDI (+ occasionally sales)
  RTO_REQUEST: 20, DISPATCH_BY_PDI: 20,
};
const FINANCE_FILE_XP = 10;    // derived: first finance touch on a booking ("loan file opened")
const FINANCE_CLEARED_XP = 60; // derived: booking had finance work AND advanced past finance stage
const DOC_SET_XP = 30;         // derived: full document set completed (gamify completion, not pieces)
const COLLAB_XP = 25;          // co-op bonus per contributing department on a delivered car

// Required document components for DOCUMENT_SET_COMPLETED.
const REQUIRED_DOCS = new Set([
  "DOCUMENTS_PAN", "DOCUMENTS_AADHAAR FRONT", "DOCUMENTS_VIN",
  "DOCUMENTS_FRONT", "DOCUMENTS_REAR", "DOCUMENTS_LEFT", "DOCUMENTS_RIGHT",
]);

const STAGE = { "PRE-BOOKING": 0, "PENDING-BOOKING": 1, IBNA: 2, ABNR: 3, RBND: 4, DELIVERED: 5 };
const key = (r) => `${r.location_code}|${r.enquiry_no}`;
const day = (d) => (d || "").slice(0, 10);

// ---------- group events by booking ----------
const bookings = new Map();
for (const r of events) {
  if (!r.enquiry_no || r.enquiry_no === "-") continue;
  const k = key(r);
  if (!bookings.has(k)) bookings.set(k, []);
  bookings.get(k).push(r);
}

// ---------- per-user accumulators ----------
const U = {}; // user_id -> stats
const ensure = (uid, dept) => {
  if (!U[uid]) {
    const e = emp[uid] || {};
    U[uid] = {
      id: uid, name: e.name || uid, dept: e.dept || dept || "",
      designation: e.designation || "", manager: e.manager || "",
      locName: e.locName || "", xp: 0, teamXp: 0, collab: 0,
      milestones: 0, actions: {}, days: new Set(), daily: {},
    };
  }
  return U[uid];
};
const award = (uid, dept, xp, action, date, isTeam = false) => {
  const u = ensure(uid, dept);
  u.xp += xp;
  if (isTeam) u.teamXp += xp;
  else { u.milestones++; u.actions[action] = (u.actions[action] || 0) + 1; }
  const d = day(date); u.days.add(d); u.daily[d] = (u.daily[d] || 0) + xp;
};
const deptOf = (uid) => emp[uid]?.dept || "";

const activity = [];
let collabCount = 0;

for (const [bk, evs] of bookings) {
  evs.sort((a, b) => a.created_date.localeCompare(b.created_date));
  const maxStage = Math.max(-1, ...evs.map((e) => STAGE[e.stage] ?? -1));
  const cancelled = evs.some((e) => e.stage === "CANCELLED");
  const delivered = maxStage >= STAGE.DELIVERED;
  const seen = new Set();
  const contributors = new Map(); // dept -> { uid, ts }  (last milestone actor per dept on this car)

  const pushActivity = (e, action, xp, dept, extra = {}) =>
    activity.push({ ts: e.created_date, uid: e.user_id, name: emp[e.user_id]?.name || e.user_id, dept, action, xp, bk, cancelled, ...extra });

  // (1) raw milestones — once per booking per action, credited to the real actor/department
  for (const e of evs) {
    const a = e.action_code;
    if (MILESTONE_XP[a] && !seen.has(a)) {
      seen.add(a);
      const dept = deptOf(e.user_id) || "";
      if (!cancelled) {
        award(e.user_id, dept, MILESTONE_XP[a], a, e.created_date);
        if (isGamified(dept)) contributors.set(dept, { uid: e.user_id, ts: e.created_date });
      }
      pushActivity(e, a, MILESTONE_XP[a], dept || "");
    }
  }

  // (2) derived FINANCE — file opened (first finance touch) + cleared (advanced)
  const finEvents = evs.filter((e) => deptOf(e.user_id) === "FINANCE" || e.department === "FINANCE");
  if (finEvents.length) {
    const first = finEvents[0];
    if (!cancelled) { award(first.user_id, "FINANCE", FINANCE_FILE_XP, "FINANCE_FILE_OPENED", first.created_date); contributors.set("FINANCE", { uid: first.user_id, ts: first.created_date }); }
    pushActivity(first, "FINANCE_FILE_OPENED", FINANCE_FILE_XP, "FINANCE");
    if (maxStage >= STAGE.ABNR && !cancelled) {
      const last = finEvents[finEvents.length - 1];
      award(last.user_id, "FINANCE", FINANCE_CLEARED_XP, "FINANCE_CLEARED", last.created_date);
      contributors.set("FINANCE", { uid: last.user_id, ts: last.created_date });
      pushActivity(last, "FINANCE_CLEARED", FINANCE_CLEARED_XP, "FINANCE");
    }
  }

  // (3) derived DOCUMENT_SET_COMPLETED — all required docs present -> credit the actor who finished the set
  const docEvents = evs.filter((e) => REQUIRED_DOCS.has(e.action_code));
  if (docEvents.length) {
    const have = new Set(docEvents.map((e) => e.action_code));
    if (have.size >= REQUIRED_DOCS.size) {
      const finisher = docEvents[docEvents.length - 1];
      const dept = deptOf(finisher.user_id) || "PDI";
      if (!cancelled) {
        award(finisher.user_id, dept, DOC_SET_XP, "DOCUMENT_SET_COMPLETED", finisher.created_date);
        if (isGamified(dept)) contributors.set(dept, { uid: finisher.user_id, ts: finisher.created_date });
      }
      pushActivity(finisher, "DOCUMENT_SET_COMPLETED", DOC_SET_XP, dept);
    }
  }

  // (4) collaboration co-op — a delivered car that ≥2 departments moved pays each a team bonus
  if (delivered && !cancelled && contributors.size >= 2) {
    for (const [dept, { uid, ts }] of contributors) {
      award(uid, dept, COLLAB_XP, "TEAM_BONUS", ts, true);
      U[uid].collab++;
      activity.push({ ts, uid, name: emp[uid]?.name || uid, dept, action: "TEAM_BONUS", xp: COLLAB_XP, bk, collab: true });
    }
    collabCount++;
  }
}

// ---------- streaks ----------
const streak = (daysSet) => {
  const ds = [...daysSet].sort();
  if (!ds.length) return { current: 0, longest: 0 };
  let longest = 1, run = 1;
  for (let i = 1; i < ds.length; i++) {
    const diff = (new Date(ds[i]) - new Date(ds[i - 1])) / 86400000;
    run = diff === 1 ? run + 1 : 1;
    longest = Math.max(longest, run);
  }
  let cur = 1;
  for (let i = ds.length - 1; i > 0; i--) {
    const diff = (new Date(ds[i]) - new Date(ds[i - 1])) / 86400000;
    if (diff === 1) cur++; else break;
  }
  return { current: cur, longest };
};

// ---------- ranks (per-department ladders so every dept competes on its own scale) ----------
const RANKS = {
  SALES:              ["Rookie", "Lead Hunter", "Negotiator", "Deal Closer", "Sales Champion", "Dealership Legend"],
  FINANCE:            ["Finance Trainee", "Loan Expert", "Approval Master", "Finance Hero", "Finance Ace", "Finance Legend"],
  ACCOUNTS:           ["Ledger Rookie", "Payment Verifier", "Credit Controller", "Accounts Ace", "Revenue Guardian", "Accounts Legend"],
  EDP:                ["Data Rookie", "System Operator", "Invoice Master", "Backend Ace", "Ops Architect", "EDP Legend"],
  "CUSTOMER CARE":    ["Care Trainee", "Support Specialist", "Insurance Pro", "Care Champion", "Customer Hero", "Care Legend"],
  PDI:                ["Inspection Rookie", "Quality Checker", "Dispatch Pro", "PDI Ace", "Delivery Master", "PDI Legend"],
  "RTO / REGN TEAM":  ["Filing Rookie", "Registration Clerk", "RTO Specialist", "Compliance Pro", "Registration Master", "RTO Legend"],
};
// Build 6 strictly-increasing thresholds per dept. Large depts use their real
// distribution (percentiles); tiny depts (few players) use bands of the top
// score so the ladder still makes sense. Floor-rounded so nobody lands just
// below a threshold, and the top performer always reaches the final rank.
const floorNice = (n) => n >= 1000 ? Math.floor(n / 500) * 500 : n >= 100 ? Math.floor(n / 50) * 50 : Math.floor(n / 10) * 10;
const step = (prev) => prev >= 1000 ? 500 : prev >= 100 ? 50 : 10;
const makeThresholds = (xps) => {
  const s = [...xps].sort((a, b) => a - b);
  if (!s.length) return [0, 100, 300, 700, 1500, 3000];
  const max = s[s.length - 1];
  const raw = s.length >= 8
    ? [0, 0.40, 0.65, 0.82, 0.93, 0.98].map((p) => s[Math.min(s.length - 1, Math.floor(p * s.length))])
    : [0, 0.10, 0.25, 0.45, 0.68, 0.88].map((f) => f * max);
  const out = []; let prev = -1;
  for (const r of raw) {
    let v = floorNice(r);
    if (v <= prev) v = prev + step(prev);
    out.push(v); prev = v;
  }
  out[0] = 0;
  // guarantee the top earner reaches the final rank, even when top scores cluster
  out[5] = Math.min(out[5], floorNice(max));
  for (let i = 5; i > 0; i--) if (out[i] <= out[i - 1]) out[i - 1] = out[i] - step(out[i]);
  return out;
};
const rankOf = (dept, xp, thresholds) => {
  const t = thresholds[dept]; const names = RANKS[dept] || [];
  if (!t) return { idx: 0, name: "Player", floor: 0, next: null, nextName: null };
  let idx = 0; for (let i = 0; i < t.length; i++) if (xp >= t[i]) idx = i;
  return { idx, name: names[idx] || "Player", floor: t[idx], next: t[idx + 1] ?? null, nextName: names[idx + 1] || null };
};

// ---------- badges (generic + role flavored) ----------
const badgeList = (u, rk) => {
  const b = [];
  if (u.actions.BOOKING_CREATED) b.push({ id: "first_booking", name: "First Booking", icon: "🏅" });
  if (u.milestones >= 100) b.push({ id: "century", name: "Centurion", icon: "💯" });
  if (u.collab >= 10) b.push({ id: "team", name: "Team Player", icon: "🤝" });
  if ((u.actions.DISCOUNT_APPROVED || 0) >= 25) b.push({ id: "sharp", name: "Sharpshooter", icon: "🎯" });
  if ((u.actions.FINANCE_CLEARED || 0) >= 20) b.push({ id: "fast_appr", name: "Fast Approver", icon: "⚡" });
  if ((u.actions.GATEPASS_ISSUED_BY_ACCOUNTS || 0) >= 20) b.push({ id: "gatekeeper", name: "Gatekeeper", icon: "🛡️" });
  if ((u.actions.DOCUMENT_SET_COMPLETED || 0) >= 10) b.push({ id: "paperwork", name: "Paperwork Pro", icon: "📑" });
  if (u.st?.longest >= 7) b.push({ id: "streak7", name: "7-Day Streak", icon: "🔥" });
  if (rk.idx >= 3) b.push({ id: "veteran", name: "Veteran", icon: "🎖️" });
  if (rk.idx >= 5) b.push({ id: "legend", name: "Legend", icon: "👑" });
  return b;
};

// ---------- finalize players (all gamified departments, xp > 0) ----------
const base = Object.values(U)
  .filter((u) => isGamified(u.dept) && u.xp > 0)
  .map((u) => {
    u.st = streak(u.days);
    const dailyArr = Object.entries(u.daily).sort().map(([date, xp]) => ({ date, xp }));
    const days = [...u.days].sort();
    return { u, dailyArr, lastDay: days[days.length - 1] };
  });

// per-department thresholds from real distribution
const thresholds = {};
for (const dept of GAMIFIED) {
  const xps = base.filter((x) => x.u.dept === dept).map((x) => x.u.xp);
  if (xps.length) thresholds[dept] = makeThresholds(xps);
}
const gamifiedDepts = GAMIFIED.filter((d) => thresholds[d]);

const players = base
  .map(({ u, dailyArr, lastDay }) => {
    const rk = rankOf(u.dept, u.xp, thresholds);
    return {
      id: u.id, name: u.name, dept: u.dept, designation: u.designation,
      manager: u.manager, locName: u.locName,
      xp: u.xp, teamXp: u.teamXp, collab: u.collab, milestones: u.milestones,
      actions: u.actions, streak: u.st.current, longestStreak: u.st.longest,
      activeDays: u.days.size, rank: rk.name, rankIdx: rk.idx, rankFloor: rk.floor,
      rankNext: rk.next, rankNextName: rk.nextName, badges: badgeList(u, rk),
      daily: dailyArr, lastDay,
    };
  })
  .sort((a, b) => b.xp - a.xp);

// per-employee "today" mission counts from their last active day
for (const p of players) {
  const counts = {};
  for (const a of activity) {
    if (a.uid === p.id && day(a.ts) === p.lastDay && !a.collab) counts[a.action] = (counts[a.action] || 0) + 1;
  }
  p.today = counts;
}

// ---------- department + leaderboards ----------
const deptAgg = {};
for (const p of players) {
  const d = (deptAgg[p.dept] ??= { name: p.dept, xp: 0, members: 0, collab: 0, milestones: 0 });
  d.xp += p.xp; d.members++; d.collab += p.collab; d.milestones += p.milestones;
}
const departments = Object.values(deptAgg).sort((a, b) => b.xp - a.xp);

// weekly series per dept (for manager charts) — one key per gamified department
const weekOf = (d) => { const dt = new Date(d); const on = dt.getUTCDay() || 7; dt.setUTCDate(dt.getUTCDate() - on + 1); return dt.toISOString().slice(0, 10); };
const weekly = {};
for (const a of activity) {
  if (a.cancelled || !isGamified(a.dept)) continue;
  const w = weekOf(a.ts);
  (weekly[w] ??= { week: w });
  weekly[w][a.dept] = (weekly[w][a.dept] || 0) + a.xp;
}
const weeklySeries = Object.values(weekly).sort((a, b) => a.week.localeCompare(b.week));

// most improved / fastest growing (last 2 weeks)
const wsorted = weeklySeries.map((w) => w.week);
const lastW = wsorted[wsorted.length - 1], prevW = wsorted[wsorted.length - 2];
const perUserWeek = {};
for (const a of activity) { if (a.cancelled) continue; const w = weekOf(a.ts); (perUserWeek[a.uid] ??= {})[w] = (perUserWeek[a.uid][w] || 0) + a.xp; }
const withDelta = players.map((p) => {
  const pw = perUserWeek[p.id] || {}; const delta = (pw[lastW] || 0) - (pw[prevW] || 0);
  return { id: p.id, name: p.name, dept: p.dept, delta, lastWeek: pw[lastW] || 0 };
});
const mostImproved = [...withDelta].sort((a, b) => b.delta - a.delta).slice(0, 5);
const fastestGrowing = [...withDelta].filter((x) => x.lastWeek > 0).sort((a, b) => b.lastWeek - a.lastWeek).slice(0, 5);

// activity feed (chronological, milestones only, richest recent slice)
activity.sort((a, b) => a.ts.localeCompare(b.ts));
const feed = activity.filter((a) => !a.cancelled).slice(-800);

// per-player recent milestones
const recentByUser = {};
for (const a of activity) { if (a.cancelled) continue; (recentByUser[a.uid] ??= []).push(a); }
for (const p of players)
  p.recent = (recentByUser[p.id] || []).slice(-14).reverse()
    .map((a) => ({ ts: a.ts, action: a.action, xp: a.xp, bk: a.bk, collab: !!a.collab }));

// ---------- staff directory (real employees per normalized department) ----------
const staff = {};
for (const e of employees) {
  const d = normDept(e.department);
  if (!isGamified(d)) continue;
  (staff[d] ??= []);
  if (staff[d].length < 12) staff[d].push({ id: e.id, name: e.name || e.id, designation: e.designation || "", loc: locName[e.loc_code] || "" });
}
const departmentsList = GAMIFIED.filter((d) => staff[d]?.length);
const supervisors = employees
  .filter((e) => /manager|lead|supervisor|head|chief/i.test(e.designation || "") && isGamified(normDept(e.department)))
  .slice(0, 16)
  .map((e) => ({ id: e.id, name: e.name || e.id, designation: e.designation, dept: normDept(e.department) }));
const carModels = ["Maruti Suzuki Swift", "Hyundai i20", "Honda City", "Toyota Innova Crysta", "Maruti Suzuki Baleno",
  "Hyundai Creta", "Kia Seltos", "Tata Nexon", "Mahindra XUV700", "Toyota Fortuner", "Honda Amaze",
  "Maruti Suzuki Ertiga", "Hyundai Venue", "Tata Punch", "Volkswagen Polo", "Mahindra Scorpio", "Kia Sonet"];

// ---------- write ----------
const out = {
  staff, departmentsList, gamifiedDepts, supervisors, carModels,
  meta: {
    totalEvents: events.length, bookings: bookings.size, players: players.length,
    collabCount, dateRange: [day(events[0]?.created_date), day(events[events.length - 1]?.created_date)],
    ranks: RANKS, thresholds, gamifiedDepts,
    scoring: { ...MILESTONE_XP, FINANCE_FILE_OPENED: FINANCE_FILE_XP, FINANCE_CLEARED: FINANCE_CLEARED_XP, DOCUMENT_SET_COMPLETED: DOC_SET_XP, TEAM_BONUS: COLLAB_XP },
    noiseTop: [
      { action: "USER_LOGGED_IN", count: 27764 }, { action: "DISCOUNT_UPDATED", count: 9188 },
      { action: "PDI_INFO_UPDATED", count: 8428 }, { action: "PAYMENTS_UPDATED", count: 7816 },
      { action: "FINANCE_INFO_UPDATED", count: 5588 },
    ],
  },
  players, departments, weeklySeries, mostImproved, fastestGrowing, feed,
};
fs.mkdirSync(path.dirname(OUT), { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(out));
const kb = Math.round(fs.statSync(OUT).size / 1024);
console.log(`\n✓ wrote ${OUT} (${kb} KB)`);
console.log(`  players: ${players.length} · gamified depts: ${gamifiedDepts.join(", ")}`);
console.log(`  collab bonuses: ${collabCount} · feed: ${feed.length}`);
for (const d of departments)
  console.log(`  ${d.name.padEnd(18)} ${String(d.members).padStart(3)} players · ${String(d.xp).padStart(8)} xp · thresholds ${thresholds[d.name].join(", ")}`);
console.log(`  top: ${players.slice(0, 3).map((p) => `${p.name}(${p.dept},${p.xp}xp,${p.rank})`).join(" · ")}`);
