/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        base: "#06070A",
        surface: "#0B0D16",
        ink: "#E9EAF2",
        muted: "#A2A8BE",
        faint: "#6A7192",
        violet: { DEFAULT: "#7C5CFF", 400: "#9B7CFF", 600: "#6941E0" },
        blue: { DEFAULT: "#3B82F6", 400: "#60A5FA" },
        gold: "#FFC53D",
        good: "#22C55E",
        bad: "#F43F5E",
        amber: "#F59E0B",
        teal: "#2EE6A6",
        pink: "#FB7185",
        cyan: "#38BDF8",
      },
      fontFamily: {
        display: ['"Space Grotesk"', "system-ui", "sans-serif"],
        sans: ['"Inter"', "system-ui", "sans-serif"],
      },
      boxShadow: {
        glow: "0 0 28px -6px rgba(124,92,255,.55)",
        card: "0 12px 40px -12px rgba(0,0,0,.5)",
        soft: "0 22px 55px -30px rgba(0,0,0,.9)",
        glowgold: "0 0 20px -4px rgba(255,197,61,.4)",
        nav: "0 4px 20px -4px rgba(124,92,255,.35)",
        lift: "0 40px 90px -46px rgba(0,0,0,.9)",
        float: "0 30px 80px -40px rgba(0,0,0,.85)",
      },
      borderRadius: { "4xl": "2rem", "5xl": "2.5rem" },
      backgroundImage: {
        "grad-vb": "linear-gradient(120deg,#7C5CFF,#3B82F6)",
        "grad-gold": "linear-gradient(120deg,#FFC53D,#F59E0B)",
        "grad-teal": "linear-gradient(120deg,#2EE6A6,#38BDF8)",
        "sheen": "linear-gradient(90deg,transparent,rgba(255,255,255,.5),transparent)",
      },
      keyframes: {
        float: { "0%,100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-8px)" } },
        shimmer: { "100%": { transform: "translateX(100%)" } },
        pop: { "0%": { transform: "scale(.8)", opacity: 0 }, "60%": { transform: "scale(1.05)" }, "100%": { transform: "scale(1)", opacity: 1 } },
        "pulse-glow": { "0%,100%": { opacity: 0.55 }, "50%": { opacity: 1 } },
      },
      animation: {
        float: "float 6s ease-in-out infinite",
        pop: "pop .35s ease-out",
        shimmer: "shimmer 2.4s ease-in-out infinite",
        "pulse-glow": "pulse-glow 3s ease-in-out infinite",
        blob: "blob 22s ease-in-out infinite",
        blob2: "blob2 28s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};
