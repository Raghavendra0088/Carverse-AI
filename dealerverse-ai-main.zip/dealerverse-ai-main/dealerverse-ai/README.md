# DealerVerse AI — *Level Up Your Dealership*

A gamification platform that turns real car-dealership activity into an engaging
game. Employees do their normal work and automatically earn **XP, levels, ranks,
badges, missions, and collaboration bonuses** — driving motivation, teamwork and
throughput.

Built for the **CarVerse** hackathon. Targets two departments: **Sales** and **Finance**.

> **Everything runs on the real dataset** — 170,162 events, 3,347 action types,
> 6,037 employees, 41 locations. No fake numbers.

---

## Run it

```bash
npm install
npm run data     # process the CSVs -> src/data/dealerverse.json (run once)
npm run dev      # start the app
```

Or in one step: `npm run setup`. Then open the printed localhost URL and pick a role.

## How it works

1. **`scripts/build-data.mjs`** (PapaParse) reads the three CSVs in `../carverse files/`,
   scores only *meaningful milestones* (once per booking), detects Sales↔Finance
   collaboration handoffs, and emits a compact `dealerverse.json`.
2. The React app loads that JSON instantly and renders 10 screens.

### The XP engine (anti-gaming by design)
| Dept | Milestone | XP |
|---|---|---|
| Sales | Booking created | 20 |
| Sales | Discount approved | 30 |
| Sales | Invoice approved | 25 |
| Finance | Loan file opened | 10 |
| Finance | **Finance cleared** (derived) | 60 |
| Both | **Team bonus** (Sales + Finance move the same booking) | +25 each |
| — | Logins, status *updates*, notes, repeat uploads | **0** |

- Every milestone scores **once per booking** — repeating an action does nothing.
- **77.6%** of all logged events (led by `USER_LOGGED_IN`, the #1 action) earn zero XP.
- Cancelled bookings never score.

## Screens
Login · Employee Dashboard · Live Activity Feed · Missions · Career · Achievements ·
Leaderboard · Department · Manager · AI Coach · Profile.

## Stack
React · Vite · TailwindCSS · Framer Motion · Recharts · PapaParse · Lucide · React Router · Zustand.

## Structure
```
scripts/build-data.mjs   data pipeline (CSV -> JSON)
src/data/                dealerverse.json + db.js access layer
src/lib/                 gamify.js (ranks, missions, coach), confetti.js
src/store/               zustand identity/session store
src/components/ui/       Card, CountUp, XPBar, RankRing, Avatar, Badge, StatTile, PageHead
src/components/layout/   Sidebar, Topbar, Toaster, AppLayout, MobileNav
src/pages/               the 10 screens
```
