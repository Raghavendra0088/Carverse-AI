# DealerVerse AI — Demo Login PINs

Each employee has a unique 4-digit PIN derived from their employee ID. On the login screen, pick the **Department**, choose the **employee**, and enter their **PIN** below. (You can also click *Show demo PIN* on the login card.)

> These are the employees available in the login dropdown (top players per department).

## Sales

| PIN | Name | Employee ID |
|-----|------|-------------|
| 9183 | AJEYA GOWDA | 10688 |
| 3692 | SAMPATH B | SAM814 |
| 2516 | SHANMUGAM | 859 |
| 5740 | NAVEEN KUMAR P | BAA6415 |
| 9801 | PETER K M | BAA6885 |
| 4859 | MOHAMMAD MUBARIS | BNEX134 |
| 5517 | KIRAN P | 1031 |
| 8076 | HALAGASAN A | BAA1281 |
| 3337 | SANTHOSHKUMAR KT | 1761 |
| 4915 | VIKAS GUPTA | COO |
| 9817 | GHANAMATHADAYYA G | 9024 |
| 1626 | RAMAMURTHY | 6080 |

## Finance

| PIN | Name | Employee ID |
|-----|------|-------------|
| 3596 | SANTOSH KUMAR SHETTY | 994 |
| 5424 | ANANTHA MURTHY B K | 1001 |
| 4756 | A SANTHOSH KUMAR | 9456 |
| 5284 | ABHA MISHRA | BAA4006 |
| 9366 | HARI BABU R | 1436 |
| 4900 | YASHAVANTH KUMAR | BA006704 |
| 3033 | HARISH KUMAR K N | 10976 |
| 3869 | K L DILEP | 11764 |
| 8561 | HANUMANTHAPPA | BAA7424 |
| 2578 | PUTTA MADAIAH | 879 |
| 8680 | Vishwa V | BAA6730 |
| 8981 | MAHESH KUMAR N | 8236 |

## Accounts

| PIN | Name | Employee ID |
|-----|------|-------------|
| 6064 | JYOTHILAKSHMI C | BAA1054 |
| 7861 | KARTHIK S | BAA1213 |
| 6099 | SUNIL JANGIR | BAA1068 |
| 2594 | SNEHA RAJKUMAR | BAC7533 |
| 9179 | KRISHAN KUMAR SHARMA | 10684 |
| 8851 | ROHIT SETHI | BAA434 |
| 4543 | LALIT KUMAR VARMA | 5664 |
| 7656 | VENUGOPAL M | 5027 |
| 7781 | KIRAN KUMAR S | 5068 |
| 1359 | RAJESH KUMAR | 1547 |
| 6002 | Jagadeesha M | BAA1034 |
| 9585 | M ANITHA | BAA2745A |

## EDP

| PIN | Name | Employee ID |
|-----|------|-------------|
| 2353 | VIGNESH | BAA3970 |
| 3947 | DHANANJAYAN P | 7945 |
| 1144 | SHAMSHAD A S | 10788 |
| 2846 | SALMA BANU | 10915 |
| 8470 | ROOPA RANI S | 9810 |
| 2203 | BABU M | BAA3925 |
| 7426 | KALPANA A | 6693 |
| 2636 | GANESH SHETTY | 895 |
| 5835 | LOHITH | BAA6447 |
| 3371 | MANJUNATH.M | 6229 |
| 7164 | VANITHA V | 10454 |
| 8658 | G VIJAYAKUMARI | BAA7458 |

## Customer Care

| PIN | Name | Employee ID |
|-----|------|-------------|
| 9657 | ASHWINI RAI MITCHELL | 9989 |
| 1075 | SHRUTHI Y R | 11490 |
| 2801 | RASHMI PRIYA | 8515 |
| 9805 | CHAYA S | BAA6889 |
| 3071 | SUPRABHA RAMDAS NAYAK | BAA4724 |
| 5149 | SAHANA C V | BAA4975 |
| 1208 | DEVIKA R | BAA4541 |
| 2194 | RACHANA N R | BAA9100 |
| 9537 | MERCY KUMUDU | BNEX82 |
| 7921 | DEEPAVALLI C | BAA344 |
| 9706 | DEEPTHI | BAA7582 |
| 6902 | ASHWINI S | BAA1115 |

## PDI

| PIN | Name | Employee ID |
|-----|------|-------------|
| 9774 | MANOJ KUMAR B R | BAA6879 |
| 4998 | MANJUNATHA H R | BAA4929 |
| 6904 | MANJUNATH | NN1023 |

## RTO / Regn

| PIN | Name | Employee ID |
|-----|------|-------------|
| 7967 | S HEMAVATHI | 10501 |

## Supervisors

| PIN | Name | Department | Employee ID |
|-----|------|------------|-------------|
| 1355 | SAMPATH B | Sales | 0814 |
| 5424 | ANANTHA MURTHY B K | Finance | 1001 |
| 5425 | VENKATESH M | Finance | 1002 |
| 3232 | KESHAVA Y | Sales | 10029 |
| 3255 | LAKSHMIPATHY L | Sales | 10031 |
| 3258 | SOWMYA B | Sales | 10034 |
| 3289 | SANTHOSH M | Sales | 10044 |
| 3320 | PRATHAP | Sales | 10054 |
| 3387 | ARUN KUMAR M | Sales | 10079 |
| 3410 | MANIKANDAN E | Sales | 10081 |
| 3416 | JEEVAN R | Sales | 10087 |
| 4406 | MANJUNATH KN | Sales | 10195 |
| 5371 | SATISH B | Sales | 10299 |
| 6046 | KARTHICK M | Sales | 10302 |
| 5517 | KIRAN P | Sales | 1031 |
| 6076 | KOUSHIK PRABHU | Sales | 10311 |

---

_Note: the PIN depends only on the employee ID, so the same person under a different ID has a different PIN. Generated from `src/data/dealerverse.json`; regenerate after `npm run data`._
