// Ambient, calm background: layered mesh gradients + soft drifting blobs +
// floating particles + fine noise texture + gentle vignette. Purely decorative,
// non-interactive, sits behind all content. No business logic.

const NOISE =
  "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='140' height='140'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")";

// deterministic particle field (no Math.random — stable across renders)
const PARTICLES = Array.from({ length: 18 }, (_, i) => {
  const gx = (i * 61.8) % 100;
  const gy = (i * 37.3 + 11) % 100;
  return {
    left: gx,
    top: gy,
    size: 2 + (i % 4),
    delay: -(i * 0.9),
    dur: 7 + (i % 5) * 1.6,
    op: 0.12 + (i % 5) * 0.05,
  };
});

export default function BackgroundFX() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden" aria-hidden="true">
      {/* layered mesh gradient wash */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(1100px 720px at 8% -6%, rgba(124,92,255,.14), transparent 55%)," +
            "radial-gradient(1000px 680px at 100% 4%, rgba(76,125,255,.11), transparent 52%)," +
            "radial-gradient(1200px 900px at 60% 120%, rgba(46,230,166,.06), transparent 60%)",
        }}
      />
      {/* soft drifting blobs */}
      <div className="animate-blob absolute -left-40 -top-40 h-[38rem] w-[38rem] rounded-full"
        style={{ background: "radial-gradient(circle, rgba(124,92,255,.28), transparent 62%)", filter: "blur(90px)" }} />
      <div className="animate-blob2 absolute -right-52 top-1/4 h-[34rem] w-[34rem] rounded-full"
        style={{ background: "radial-gradient(circle, rgba(76,125,255,.22), transparent 62%)", filter: "blur(100px)" }} />
      <div className="animate-blob absolute bottom-[-16rem] left-1/3 h-[32rem] w-[32rem] rounded-full"
        style={{ background: "radial-gradient(circle, rgba(46,230,166,.12), transparent 62%)", filter: "blur(110px)", animationDelay: "-8s" }} />

      {/* floating particles */}
      {PARTICLES.map((p, i) => (
        <span
          key={i}
          className="animate-float absolute rounded-full bg-white"
          style={{
            left: `${p.left}%`, top: `${p.top}%`,
            width: p.size, height: p.size,
            opacity: p.op,
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.dur}s`,
            boxShadow: "0 0 8px rgba(255,255,255,.4)",
          }}
        />
      ))}

      {/* fine noise texture */}
      <div className="absolute inset-0" style={{ backgroundImage: NOISE, opacity: 0.035, mixBlendMode: "overlay" }} />
      {/* gentle vignette */}
      <div className="absolute inset-0"
        style={{ background: "radial-gradient(130% 130% at 50% 30%, transparent 45%, rgba(0,0,0,.55) 100%)" }} />
    </div>
  );
}
