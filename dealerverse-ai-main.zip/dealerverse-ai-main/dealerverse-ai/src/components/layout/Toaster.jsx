import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useStore } from "../../store/useStore";

export default function Toaster() {
  const events = useStore((s) => s.sessionEvents);
  const [visible, setVisible] = useState([]);

  useEffect(() => {
    const latest = events[0];
    if (!latest) return;
    setVisible((v) => (v.find((x) => x.id === latest.id) ? v : [latest, ...v].slice(0, 4)));
    const t = setTimeout(() => setVisible((v) => v.filter((x) => x.id !== latest.id)), 2800);
    return () => clearTimeout(t);
  }, [events]);

  return (
    <div className="pointer-events-none fixed right-5 top-20 z-50 flex flex-col gap-2">
      <AnimatePresence>
        {visible.map((e) => (
          <motion.div
            key={e.id}
            initial={{ opacity: 0, x: 60, scale: 0.9 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 60, scale: 0.9 }}
            transition={{ type: "spring", stiffness: 400, damping: 28 }}
            className="glass flex items-center gap-3 px-4 py-3 shadow-glow"
          >
            <div className="text-2xl">{e.icon}</div>
            <div>
              <div className="text-sm font-semibold text-ink">{e.label}</div>
              <div className="font-display text-lg font-bold" style={{ color: e.color }}>+{e.xp} XP</div>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
