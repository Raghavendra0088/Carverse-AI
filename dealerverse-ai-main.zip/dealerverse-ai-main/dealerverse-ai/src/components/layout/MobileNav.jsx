import { NavLink } from "react-router-dom";
import { LayoutDashboard, Workflow, Gavel, Trophy, User, Car, Store, ShoppingBag } from "lucide-react";
import { useStore, useMe } from "../../store/useStore";
import { gamifiedDepts } from "../../data/db";

function itemsFor(me) {
  if (!me) return [];
  if (me.kind === "customer") return [{ to: "/customer", icon: Car }];
  if (me.kind === "buyer") return [{ to: "/market", icon: Store }, { to: "/purchases", icon: ShoppingBag }];
  if (me.supervisor) return [{ to: "/evaluate", icon: Gavel }, { to: "/pipeline", icon: Workflow }, { to: "/manager", icon: LayoutDashboard }, { to: "/leaderboard", icon: Trophy }, { to: "/profile", icon: User }];
  const gamified = gamifiedDepts.includes(me.dept);
  if (gamified) return [{ to: "/dashboard", icon: LayoutDashboard }, { to: "/pipeline", icon: Workflow }, { to: "/leaderboard", icon: Trophy }, { to: "/profile", icon: User }];
  return [{ to: "/pipeline", icon: Workflow }, { to: "/leaderboard", icon: Trophy }, { to: "/profile", icon: User }];
}

export default function MobileNav() {
  const me = useMe();
  const items = itemsFor(me);
  return (
    <nav className="fixed inset-x-0 bottom-4 z-40 flex justify-center px-4 lg:hidden">
      <div className="glass flex items-center gap-1 rounded-full px-2 py-2 shadow-float">
        {items.map(({ to, icon: Icon }) => (
          <NavLink key={to} to={to}
            className={({ isActive }) =>
              `flex h-11 w-11 items-center justify-center rounded-full transition ${
                isActive ? "bg-gradient-to-br from-violet/30 to-blue/20 text-violet-400" : "text-muted hover:bg-white/[.05] hover:text-ink"}`}>
            <Icon size={20} strokeWidth={1.75} />
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
