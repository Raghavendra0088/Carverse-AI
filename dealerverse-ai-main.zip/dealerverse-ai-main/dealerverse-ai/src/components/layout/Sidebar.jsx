import { NavLink, useNavigate } from "react-router-dom";
import { LayoutDashboard, Activity, Target, TrendingUp, Award, Trophy, Building2, LineChart, Sparkles, User, Workflow, Gavel, Car, Store, ShoppingBag, Settings, LogOut, History as HistoryIcon, Headset, ClipboardList } from "lucide-react";
import { useStore, useMe } from "../../store/useStore";
import { useWorkflow } from "../../store/useWorkflow";
import { gamifiedDepts } from "../../data/db";
import Avatar from "../ui/Avatar";

const N = {
  dashboard: { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  feed: { to: "/feed", label: "Live Feed", icon: Activity },
  pipeline: { to: "/pipeline", label: "Pipeline", icon: Workflow },
  bookings: { to: "/bookings", label: "Bookings", icon: ClipboardList },
  evaluate: { to: "/evaluate", label: "Evaluations", icon: Gavel },
  missions: { to: "/missions", label: "Missions", icon: Target },
  career: { to: "/career", label: "Career", icon: TrendingUp },
  achievements: { to: "/achievements", label: "Achievements", icon: Award },
  leaderboard: { to: "/leaderboard", label: "Leaderboard", icon: Trophy },
  department: { to: "/department", label: "Department", icon: Building2 },
  manager: { to: "/manager", label: "Manager", icon: LineChart },
  coach: { to: "/coach", label: "AI Coach", icon: Sparkles },
  profile: { to: "/profile", label: "Profile", icon: User },
  customer: { to: "/customer", label: "My Deals", icon: Car },
  market: { to: "/market", label: "Marketplace", icon: Store },
  purchases: { to: "/purchases", label: "My Purchases", icon: ShoppingBag },
  history: { to: "/history", label: "History", icon: HistoryIcon },
  support: { to: "/support", label: "Customer Care", icon: Headset },
};

function navFor(me) {
  if (!me) return [];
  if (me.kind === "customer") return [N.customer];
  if (me.kind === "buyer") return [N.market, N.purchases];
  const gamified = gamifiedDepts.includes(me.dept);
  if (me.supervisor) return [N.evaluate, N.bookings, N.pipeline, N.manager, N.department, N.support, N.history, N.leaderboard, N.profile];
  if (gamified) {
    const items = [N.dashboard, N.feed, N.bookings, N.pipeline, N.missions, N.career, N.achievements, N.leaderboard, N.department, N.history, N.coach, N.profile];
    if (me.dept === "CUSTOMER CARE") items.splice(8, 0, N.support); // Customer Care team gets the support desk
    return items;
  }
  return [N.pipeline, N.leaderboard, N.profile];
}

export default function Sidebar() {
  const me = useMe();
  const nav = useNavigate();
  const logout = useStore((s) => s.logout);
  const pending = useWorkflow((s) => s.deals.filter((d) => d.status === "PENDING").length);
  const items = navFor(me);
  const roleLabel = me ? (me.kind === "buyer" ? "Buyer" : me.kind === "customer" ? "Customer" : me.supervisor ? "Supervisor" : me.rank || me.dept) : "";

  return (
    <aside className="hidden shrink-0 p-3 lg:block">
      <div className="glass sticky top-3 flex h-[calc(100vh-1.5rem)] w-64 flex-col rounded-4xl p-4">
        {/* logo */}
        <div className="mb-6 flex items-center gap-3 px-2 pt-1">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-grad-vb font-display text-lg font-bold text-white shadow-[0_10px_24px_-10px_rgba(124,92,255,.8)]">D</div>
          <div>
            <div className="font-display text-[15px] font-bold leading-none tracking-tight text-ink">DealerVerse <span className="grad-text">AI</span></div>
            <div className="mt-1.5 text-[10px] uppercase tracking-[0.18em] text-faint">Performance Platform</div>
          </div>
        </div>

        {/* nav */}
        <nav className="flex flex-1 flex-col gap-1 overflow-y-auto pr-1">
          {items.map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to}
              className={({ isActive }) =>
                `group relative flex items-center gap-3 rounded-2xl px-3.5 py-2.5 text-sm font-medium transition-all duration-200 ${
                  isActive
                    ? "border border-white/10 bg-gradient-to-r from-violet/20 to-blue/10 text-ink"
                    : "border border-transparent text-muted hover:bg-white/[.04] hover:text-ink"}`}>
              {({ isActive }) => (
                <>
                  <Icon size={18} strokeWidth={1.75} className={`transition ${isActive ? "text-violet-400" : "text-faint group-hover:text-ink"}`} />
                  <span className="flex-1">{label}</span>
                  {to === "/evaluate" && pending > 0 && (
                    <span className="rounded-full bg-amber/90 px-1.5 text-[10px] font-bold text-black">{pending}</span>
                  )}
                  {isActive && <span className="h-1.5 w-1.5 rounded-full bg-violet-400 shadow-[0_0_10px_2px_rgba(124,92,255,.6)]" />}
                </>
              )}
            </NavLink>
          ))}
        </nav>

        {/* bottom: profile · settings · logout */}
        <div className="mt-3 border-t border-white/8 pt-3">
          <NavLink to="/profile" className="flex items-center gap-3 rounded-2xl p-2 transition hover:bg-white/[.04]">
            <Avatar name={me?.name || "?"} size={38} ring />
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-semibold text-ink">{me?.name || "Guest"}</div>
              <div className="truncate text-xs text-faint">{roleLabel}</div>
            </div>
          </NavLink>
          <div className="mt-1 flex gap-1">
            <NavLink to="/profile" className="flex flex-1 items-center justify-center gap-2 rounded-2xl px-3 py-2 text-xs font-medium text-muted transition hover:bg-white/[.04] hover:text-ink">
              <Settings size={15} strokeWidth={1.75} /> Settings
            </NavLink>
            <button onClick={() => { logout(); nav("/"); }}
              className="flex items-center justify-center gap-2 rounded-2xl px-3 py-2 text-xs font-medium text-muted transition hover:bg-bad/10 hover:text-bad">
              <LogOut size={15} strokeWidth={1.75} /> Logout
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
}
