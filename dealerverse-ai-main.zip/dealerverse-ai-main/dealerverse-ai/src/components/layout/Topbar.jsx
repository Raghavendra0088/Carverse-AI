import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { Zap, Flame, LogOut, Search, Bell, User, Building2, Target, ArrowRight, CornerDownLeft } from "lucide-react";
import { useStore, useMe } from "../../store/useStore";
import { useWorkflow } from "../../store/useWorkflow";
import { actionMeta, ACTION_META, deptLabel, fmt } from "../../lib/gamify";
import { players, gamifiedDepts } from "../../data/db";
import { confetti } from "../../lib/confetti";
import Avatar from "../ui/Avatar";

let _id = 0;
const POOL = {
  SALES: ["BOOKING_CREATED", "DISCOUNT_APPROVED", "INVOICE_APPROVED_SALES", "RGISTRATION_APPROVED_SALES"],
  FINANCE: ["FINANCE_FILE_OPENED", "FINANCE_CLEARED"],
  ACCOUNTS: ["GATEPASS_ISSUED_BY_ACCOUNTS", "CREDIT_APPROVED"],
  EDP: ["INVOICE_APPROVED_EDP", "RGISTRATION_CREATED_EDP", "REGISTRATION_ADDED"],
  "CUSTOMER CARE": ["INSURANCE_APPROVED_BY_CCM", "DISPATCH_BY_CCM", "GATEPASS_BY_CCM"],
  PDI: ["DISPATCH_BY_PDI", "RTO_REQUEST", "DOCUMENT_SET_COMPLETED"],
  "RTO / REGN TEAM": ["REGISTRATION_ADDED", "RTO_REQUEST"],
};

const PAGES = [
  { label: "Dashboard", to: "/dashboard" }, { label: "Live Feed", to: "/feed" },
  { label: "Pipeline", to: "/pipeline" }, { label: "Missions", to: "/missions" },
  { label: "Career", to: "/career" }, { label: "Achievements", to: "/achievements" },
  { label: "Leaderboard", to: "/leaderboard" }, { label: "Department", to: "/department" },
  { label: "AI Coach", to: "/coach" }, { label: "Profile", to: "/profile" },
];
const TYPE_ICON = { Person: User, Department: Building2, Milestone: Target, Page: ArrowRight };

export default function Topbar() {
  const me = useMe();
  const sessionXp = useStore((s) => s.sessionXp);
  const addSessionXp = useStore((s) => s.addSessionXp);
  const logout = useStore((s) => s.logout);
  const wfXp = useWorkflow((s) => (me ? s.ledger[me.id] || 0 : 0));
  const nav = useNavigate();

  // hide on scroll down, reveal on scroll up
  const [hidden, setHidden] = useState(false);
  const lastY = useRef(0);
  useEffect(() => {
    const onScroll = () => {
      const y = window.scrollY;
      if (y > lastY.current && y > 90) setHidden(true);
      else setHidden(false);
      lastY.current = y;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // functional search
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const blurTimer = useRef(null);
  const results = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return [];
    const r = [];
    players.filter((p) => p.name.toLowerCase().includes(s)).slice(0, 5)
      .forEach((p) => r.push({ type: "Person", label: p.name, sub: `${deptLabel(p.dept)} · ${p.rank} · ${fmt(p.xp)} XP`, to: "/leaderboard" }));
    gamifiedDepts.filter((d) => deptLabel(d).toLowerCase().includes(s)).slice(0, 3)
      .forEach((d) => r.push({ type: "Department", label: deptLabel(d), sub: "Open department dashboard", to: "/department" }));
    Object.entries(ACTION_META).filter(([, m]) => m.label.toLowerCase().includes(s) && m.dept !== "BOTH").slice(0, 4)
      .forEach(([, m]) => r.push({ type: "Milestone", label: m.label, sub: `${m.xp} XP · ${deptLabel(m.dept)} — ${m.purpose}`, to: "/missions" }));
    PAGES.filter((p) => p.label.toLowerCase().includes(s)).slice(0, 3)
      .forEach((p) => r.push({ type: "Page", label: p.label, sub: "Jump to page", to: p.to }));
    return r.slice(0, 10);
  }, [q]);

  const go = (to) => { setQ(""); setOpen(false); nav(to); };

  if (!me) return null;

  const isCustomer = me.kind !== "employee";
  const totalXp = (me.xp || 0) + sessionXp + wfXp;

  const simulate = (e) => {
    const pool = POOL[me.dept];
    const code = pool ? pool[Math.floor(Math.random() * pool.length)] : null;
    const m = code ? actionMeta(code) : { label: "Milestone", icon: "✅", xp: 30, color: "#22C55E" };
    addSessionXp(m.xp, { id: ++_id, icon: m.icon, label: m.label, xp: m.xp, color: m.color, name: me.name, action: code });
    const r = e.currentTarget.getBoundingClientRect(); confetti(r.left + r.width / 2, r.top, 40);
  };

  return (
    <header className={`sticky top-0 z-30 px-4 pt-4 transition-transform duration-300 ${hidden ? "-translate-y-[140%]" : "translate-y-0"}`}>
      <div className="glass mx-auto flex max-w-6xl items-center gap-3 rounded-3xl px-4 py-2.5">
        {/* functional search / command bar */}
        <div className="relative min-w-0 flex-1">
          <div className="flex items-center gap-2.5 rounded-2xl border border-white/8 bg-white/[.03] px-3.5 py-2 text-sm text-faint focus-within:border-violet/50">
            <Search size={16} strokeWidth={1.75} />
            <input
              value={q}
              onChange={(e) => { setQ(e.target.value); setOpen(true); }}
              onFocus={() => setOpen(true)}
              onBlur={() => { blurTimer.current = setTimeout(() => setOpen(false), 160); }}
              onKeyDown={(e) => {
                if (e.key === "Enter" && results[0]) go(results[0].to);
                if (e.key === "Escape") { setQ(""); setOpen(false); e.currentTarget.blur(); }
              }}
              placeholder="Search employees, departments, missions & milestones…"
              className="w-full min-w-0 bg-transparent text-ink outline-none placeholder:text-faint"
            />
            <kbd className="hidden rounded-md border border-white/10 bg-white/5 px-1.5 py-0.5 text-[10px] font-medium text-faint sm:block">⌘K</kbd>
          </div>

          <AnimatePresence>
            {open && q.trim() && (
              <motion.div
                initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 6 }}
                transition={{ duration: 0.15 }}
                onMouseDown={() => clearTimeout(blurTimer.current)}
                className="absolute left-0 right-0 top-[calc(100%+8px)] z-50 max-h-[70vh] overflow-y-auto rounded-2xl border border-white/12 p-2 shadow-lift"
                style={{ background: "rgba(9,11,18,0.98)", backdropFilter: "blur(28px) saturate(1.3)", WebkitBackdropFilter: "blur(28px) saturate(1.3)" }}
              >
                <div className="flex items-center justify-between px-3 py-2">
                  <span className="text-[11px] font-medium uppercase tracking-[0.12em] text-faint">Searching people · departments · missions · milestones</span>
                  {results.length > 0 && <span className="text-[11px] text-faint">{results.length} result{results.length === 1 ? "" : "s"}</span>}
                </div>
                {results.length === 0 ? (
                  <div className="px-3 py-4 text-sm text-muted">No matches for “{q}”.</div>
                ) : results.map((r, i) => {
                  const Icon = TYPE_ICON[r.type] || Search;
                  return (
                    <button key={i} onClick={() => go(r.to)}
                      className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition hover:bg-white/[.05]">
                      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-white/8 bg-white/[.04] text-muted">
                        <Icon size={15} strokeWidth={1.75} />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-medium text-ink">{r.label}</span>
                        <span className="block truncate text-xs text-faint">{r.sub}</span>
                      </span>
                      <span className="shrink-0 rounded-md bg-white/5 px-1.5 py-0.5 text-[10px] text-faint">{r.type}</span>
                    </button>
                  );
                })}
                {results[0] && (
                  <div className="flex items-center gap-1.5 px-3 py-2 text-[11px] text-faint">
                    <CornerDownLeft size={12} /> Enter to open the top result
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="flex items-center gap-2">
          {!isCustomer && (
            <>
              <button onClick={simulate} className="btn btn-primary !px-4 !py-2 text-xs"><Zap size={14} /> <span className="hidden sm:inline">Simulate</span></button>

              {me.streak > 0 && (
                <div className="chip hidden py-1.5 sm:inline-flex">
                  <Flame size={14} className="text-amber" /><span className="font-semibold text-ink">{me.streak}</span>
                </div>
              )}
              <div className="hidden items-center gap-1.5 rounded-full border border-gold/25 bg-gold/10 px-3 py-1.5 text-sm sm:flex">
                <Zap size={14} className="text-gold" /><span className="grad-gold font-display font-bold">{totalXp.toLocaleString()}</span>
              </div>
              <span className="chip hidden md:inline-flex">{me.rank || me.dept}</span>

              <button className="relative flex h-9 w-9 items-center justify-center rounded-full border border-white/8 bg-white/[.03] text-muted transition hover:text-ink" title="Notifications">
                <Bell size={16} strokeWidth={1.75} />
                <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-violet-400" />
              </button>
            </>
          )}
          <Avatar name={me.name} size={36} ring />
          <button onClick={() => { logout(); nav("/"); }} className="flex h-9 w-9 items-center justify-center rounded-full text-muted transition hover:text-bad" title="Log out"><LogOut size={17} strokeWidth={1.75} /></button>
        </div>
      </div>
    </header>
  );
}
