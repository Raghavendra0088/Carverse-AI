import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useStore } from "../../store/useStore";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import Toaster from "./Toaster";
import MobileNav from "./MobileNav";
import BackgroundFX from "./BackgroundFX";

export default function AppLayout() {
  const identity = useStore((s) => s.identity);
  const loc = useLocation();
  if (!identity) return <Navigate to="/" replace />;
  const buyerPaths = ["/market", "/purchases"];
  if (identity.kind === "customer" && loc.pathname !== "/customer") return <Navigate to="/customer" replace />;
  if (identity.kind === "buyer" && !buyerPaths.includes(loc.pathname)) return <Navigate to="/market" replace />;
  if (identity.kind === "employee" && (loc.pathname === "/customer" || buyerPaths.includes(loc.pathname))) return <Navigate to="/pipeline" replace />;

  return (
    <div className="relative flex min-h-screen">
      <BackgroundFX />
      <Sidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar />
        <main key={loc.pathname} className="mx-auto w-full max-w-6xl flex-1 px-4 pb-28 pt-2 sm:px-8 lg:pb-14">
          <Outlet />
        </main>
        <MobileNav />
      </div>
      <Toaster />
    </div>
  );
}
