import { carSvgDataUrl } from "../../lib/carimg";

// Renders a car's photo if the seller uploaded one, else a deterministic
// on-brand illustration. Always shows something — never a broken image.
export default function CarImage({ model, images, className = "", alt }) {
  const src = (images && images.length && images[0]) || carSvgDataUrl(model);
  return <img src={src} alt={alt || model || "car"} className={className} loading="lazy" />;
}
