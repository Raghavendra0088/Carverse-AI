import { avatarGrad, initials } from "../../lib/gamify";

export default function Avatar({ name = "", size = 40, ring = false }) {
  return (
    <div
      className={`flex shrink-0 items-center justify-center rounded-full font-display font-bold text-white ${ring ? "ring-2 ring-white/20" : ""}`}
      style={{ width: size, height: size, background: avatarGrad(name), fontSize: size * 0.36 }}
    >
      {initials(name)}
    </div>
  );
}
