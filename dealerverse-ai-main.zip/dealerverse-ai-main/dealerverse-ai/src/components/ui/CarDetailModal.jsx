import { useState } from "react";
import { motion } from "framer-motion";
import { X, ShieldCheck, Gauge, Calendar, Fuel, Cog, Palette, Users, Wrench, RotateCcw, LifeBuoy, BadgeCheck, Armchair } from "lucide-react";
import { inr } from "../../lib/workflow";
import { fullSpecs, carSvgDataUrl } from "../../lib/carimg";
import CarImage from "./CarImage";

export default function CarDetailModal({ item, onClose, onReserve }) {
  const [active, setActive] = useState(0);
  if (!item) return null;
  const specs = fullSpecs(item.model, item.specs, item.year);
  const gallery = item.images && item.images.length ? item.images : [carSvgDataUrl(item.model)];
  const emi = Math.round(item.retailPrice / 60);
  const listed = item.status === "LISTED";

  const specRows = [
    { icon: Calendar, k: "Year", v: item.year || "—" },
    { icon: Gauge, k: "Odometer", v: item.km ? `${Number(item.km).toLocaleString()} km` : "—" },
    { icon: Cog, k: "Engine", v: specs.engine },
    { icon: Fuel, k: "Fuel", v: specs.fuel },
    { icon: Wrench, k: "Transmission", v: specs.transmission },
    { icon: BadgeCheck, k: "Variant", v: specs.variant },
    { icon: Palette, k: "Colour", v: specs.color },
    { icon: Users, k: "Owners", v: `${specs.owners} owner${specs.owners > 1 ? "s" : ""}` },
    { icon: Armchair, k: "Seating", v: `${specs.seats} seats` },
    { icon: Gauge, k: "Mileage", v: specs.mileage },
  ];
  const features = [
    `${item.points}-point certified inspection`,
    "7-day money-back return",
    "1-year comprehensive warranty",
    "Free RC / ownership transfer",
    "24×7 roadside assistance",
    "1 free service included",
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] flex items-end justify-center p-0 sm:items-center sm:p-6"
      onMouseDown={onClose}
    >
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <motion.div
        initial={{ opacity: 0, y: 40, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 40 }}
        transition={{ type: "spring", stiffness: 260, damping: 26 }}
        onMouseDown={(e) => e.stopPropagation()}
        className="relative max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-t-4xl border border-white/10 sm:rounded-4xl"
        style={{ background: "rgba(9,11,18,0.99)", backdropFilter: "blur(28px)" }}
      >
        <button onClick={onClose} className="absolute right-4 top-4 z-10 flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-black/40 text-muted transition hover:text-ink">
          <X size={18} strokeWidth={1.75} />
        </button>

        {/* gallery */}
        <div className="relative h-56 w-full overflow-hidden sm:h-72">
          <img src={gallery[active]} alt={item.model} className="h-full w-full object-cover" />
          <span className="absolute left-4 top-4 inline-flex items-center gap-1 rounded-full bg-good/15 px-2.5 py-1 text-xs font-semibold text-good ring-1 ring-good/30"><BadgeCheck size={12} /> Certified</span>
        </div>
        {gallery.length > 1 && (
          <div className="flex gap-2 px-6 pt-3">
            {gallery.map((g, i) => (
              <button key={i} onClick={() => setActive(i)} className={`h-12 w-16 overflow-hidden rounded-lg ring-1 ${i === active ? "ring-violet" : "ring-white/10"}`}>
                <img src={g} alt="" className="h-full w-full object-cover" />
              </button>
            ))}
          </div>
        )}

        <div className="p-6">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <h2 className="font-display text-2xl font-semibold tracking-tight text-ink sm:text-3xl">{item.model}</h2>
              <div className="mt-1 text-sm text-muted">{specs.variant} · {item.year || "—"} · {specs.fuel} · {specs.transmission}</div>
            </div>
            <div className="text-right">
              <div className="num-grad font-display text-3xl font-semibold tracking-tight">{inr(item.retailPrice)}</div>
              <div className="text-xs text-faint">est. EMI {inr(emi)}/mo · 60 mo</div>
            </div>
          </div>

          {/* specs grid */}
          <div className="mt-6 text-xs font-semibold uppercase tracking-[0.14em] text-faint">Specifications</div>
          <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {specRows.map((r) => (
              <div key={r.k} className="rounded-2xl border border-white/8 bg-white/[.03] p-3">
                <div className="flex items-center gap-1.5 text-[11px] text-faint"><r.icon size={13} strokeWidth={1.75} /> {r.k}</div>
                <div className="mt-1 text-sm font-medium text-ink">{r.v}</div>
              </div>
            ))}
          </div>

          {/* features */}
          <div className="mt-6 text-xs font-semibold uppercase tracking-[0.14em] text-faint">What's included</div>
          <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
            {features.map((f, i) => {
              const Icon = [ShieldCheck, RotateCcw, ShieldCheck, BadgeCheck, LifeBuoy, Wrench][i] || ShieldCheck;
              return (
                <div key={i} className="flex items-center gap-2.5 text-sm text-muted">
                  <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-good/10 text-good"><Icon size={14} strokeWidth={1.75} /></span>
                  {f}
                </div>
              );
            })}
          </div>

          {/* price breakdown */}
          <div className="mt-6 rounded-2xl border border-white/8 bg-white/[.02] p-4 text-sm">
            <div className="flex items-center justify-between py-1"><span className="text-muted">Acquisition</span><span className="text-ink">{inr(item.acquisitionPrice)}</span></div>
            <div className="flex items-center justify-between py-1"><span className="text-muted">Reconditioning</span><span className="text-ink">{inr(item.reconditioning)}</span></div>
            <div className="mt-1 flex items-center justify-between border-t border-white/8 pt-2"><span className="font-medium text-ink">Retail price</span><span className="grad-text font-display text-lg font-bold">{inr(item.retailPrice)}</span></div>
          </div>

          <button onClick={() => onReserve(item)} disabled={!listed}
            className={`btn mt-6 w-full ${listed ? "btn-primary" : "btn-ghost cursor-not-allowed opacity-60"}`}>
            {listed ? "Reserve this car" : item.status === "RESERVED" ? "Already reserved" : "Sold"}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}
