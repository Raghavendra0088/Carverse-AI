import Card from "./Card";
import CountUp from "./CountUp";

export default function StatTile({ icon: Icon, label, value, suffix = "", accent = "#7C5CFF", delay = 0, sub }) {
  return (
    <Card hover delay={delay} className="relative overflow-hidden">
      {/* soft accent wash, calm and non-distracting */}
      <div
        className="pointer-events-none absolute -right-10 -top-10 h-28 w-28 rounded-full opacity-[.18] blur-3xl"
        style={{ background: accent }}
      />
      {Icon && (
        <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-2xl border border-white/8"
          style={{ background: `${accent}16`, color: accent }}>
          <Icon size={19} strokeWidth={1.75} />
        </div>
      )}
      <div className="num-grad font-display text-[2rem] font-semibold leading-none tracking-tight">
        <CountUp value={value} suffix={suffix} />
      </div>
      <div className="mt-2 text-[11px] font-medium uppercase tracking-[0.14em] text-muted">{label}</div>
      {sub && <div className="mt-1 text-xs text-faint">{sub}</div>}
    </Card>
  );
}
