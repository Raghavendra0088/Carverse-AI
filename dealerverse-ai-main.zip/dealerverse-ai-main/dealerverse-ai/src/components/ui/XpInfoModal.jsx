import { motion } from "framer-motion";
import { X, Info, ShieldCheck, Repeat, Users2, Zap } from "lucide-react";
import { ACTION_META, deptLabel } from "../../lib/gamify";

export default function XpInfoModal({ onClose }) {
  const rows = Object.entries(ACTION_META)
    .filter(([, m]) => m.xp > 0)
    .sort((a, b) => b[1].xp - a[1].xp);

  const rules = [
    { icon: Repeat, title: "Once per booking", body: "Every milestone scores exactly once per car. Repeating the same action does nothing — no farming." },
    { icon: ShieldCheck, title: "Signal over noise", body: "Logins, status edits and notes earn 0 XP. Around 78% of all logged events score nothing." },
    { icon: Zap, title: "Weighted by impact", body: "Higher-value outcomes pay more — a Gatepass (100) or Finance Cleared (60) dwarfs a routine update." },
    { icon: Users2, title: "Teamwork pays", body: "When ≥2 departments help deliver a car, every contributor earns a +25 XP Team Bonus." },
  ];

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] flex items-end justify-center p-0 sm:items-center sm:p-6" onMouseDown={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <motion.div
        initial={{ opacity: 0, y: 40, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 40 }}
        transition={{ type: "spring", stiffness: 260, damping: 26 }}
        onMouseDown={(e) => e.stopPropagation()}
        className="relative max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-t-4xl border border-white/10 p-6 sm:rounded-4xl sm:p-8"
        style={{ background: "rgba(9,11,18,0.99)", backdropFilter: "blur(28px)" }}>
        <button onClick={onClose} className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full border border-white/10 text-muted transition hover:text-ink"><X size={18} strokeWidth={1.75} /></button>

        <div className="flex items-center gap-2 text-violet-400"><Info size={18} strokeWidth={1.75} /><span className="text-xs font-semibold uppercase tracking-[0.14em]">How XP works</span></div>
        <h2 className="mt-2 font-display text-2xl font-semibold tracking-tight text-ink sm:text-3xl">How your XP is evaluated</h2>
        <p className="mt-2 text-sm leading-relaxed text-muted">Your XP comes only from meaningful milestones that move a car forward — computed from the real dealership event log, not activity volume.</p>

        <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
          {rules.map((r) => (
            <div key={r.title} className="rounded-2xl border border-white/8 bg-white/[.03] p-4">
              <div className="flex items-center gap-2 text-sm font-semibold text-ink"><r.icon size={15} strokeWidth={1.75} className="text-violet-400" /> {r.title}</div>
              <p className="mt-1.5 text-xs leading-relaxed text-muted">{r.body}</p>
            </div>
          ))}
        </div>

        <div className="mt-6 text-xs font-semibold uppercase tracking-[0.14em] text-faint">Every scoring milestone</div>
        <div className="mt-3 space-y-1.5">
          {rows.map(([code, m]) => (
            <div key={code} className="flex items-center gap-3 rounded-xl border border-white/6 bg-white/[.02] px-3 py-2">
              <span className="text-lg">{m.icon}</span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="truncate text-sm font-medium text-ink">{m.label}</span>
                  <span className="shrink-0 rounded-md px-1.5 py-0.5 text-[10px] font-semibold" style={{ color: m.color, background: `${m.color}1a` }}>{deptLabel(m.dept) || "Team"}</span>
                </div>
                <div className="truncate text-[11px] text-faint">{m.purpose}</div>
              </div>
              <span className="shrink-0 font-display text-sm font-bold text-gold">+{m.xp}</span>
            </div>
          ))}
        </div>

        <p className="mt-5 rounded-2xl border border-white/8 bg-white/[.02] p-3 text-xs leading-relaxed text-muted">
          <b className="text-ink">Ranks</b> are per-department ladders (Rookie → Legend). Their thresholds are computed from each department's real XP distribution, so promotions are always earned — never handed out.
        </p>
      </motion.div>
    </motion.div>
  );
}
