import { useEffect, useRef, useState } from "react";

export default function CountUp({ value = 0, dur = 1000, suffix = "", prefix = "", className = "" }) {
  const [n, setN] = useState(0);
  const ref = useRef();
  useEffect(() => {
    let raf, start;
    const from = 0, to = Number(value) || 0;
    const step = (t) => {
      if (!start) start = t;
      const p = Math.min(1, (t - start) / dur);
      const e = 1 - Math.pow(1 - p, 3);
      setN(Math.round(from + (to - from) * e));
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [value, dur]);
  return (
    <span ref={ref} className={className}>
      {prefix}{n.toLocaleString("en-US")}{suffix}
    </span>
  );
}
