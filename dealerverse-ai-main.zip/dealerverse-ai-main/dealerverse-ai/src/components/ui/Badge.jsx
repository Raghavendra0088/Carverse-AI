import { motion } from "framer-motion";

export function BadgePill({ badge, locked = false }) {
  return (
    <motion.div
      whileHover={locked ? {} : { y: -4 }}
      transition={{ type: "spring", stiffness: 300, damping: 22 }}
      className={`relative flex flex-col items-center gap-2 overflow-hidden rounded-3xl p-4 text-center transition ${
        locked
          ? "border border-white/5 bg-white/[.015] opacity-40 grayscale"
          : "border border-white/10 bg-gradient-to-b from-white/[.06] to-white/[.02]"
      }`}
    >
      {!locked && (
        <div className="pointer-events-none absolute -top-8 left-1/2 h-16 w-16 -translate-x-1/2 rounded-full bg-violet/25 opacity-40 blur-2xl" />
      )}
      <div className="relative text-[2rem] leading-none" style={{ filter: locked ? "none" : "drop-shadow(0 6px 14px rgba(124,92,255,.35))" }}>
        {badge.icon}
      </div>
      <div className="relative text-xs font-semibold leading-tight text-ink">{badge.name}</div>
    </motion.div>
  );
}

export function Tag({ children, color = "#7C5CFF" }) {
  return (
    <span className="chip" style={{ color, borderColor: `${color}55`, background: `${color}18` }}>
      {children}
    </span>
  );
}
