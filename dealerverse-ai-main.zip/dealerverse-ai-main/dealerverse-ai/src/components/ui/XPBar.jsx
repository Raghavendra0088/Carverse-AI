import { motion } from "framer-motion";

export default function XPBar({ pct = 0, label, className = "" }) {
  return (
    <div className={className}>
      {label && <div className="mb-1.5 flex justify-between text-xs text-muted">{label}</div>}
      <div className="h-2 w-full overflow-hidden rounded-full bg-white/[.06]">
        <motion.div
          initial={{ width: 0 }}
          whileInView={{ width: `${pct}%` }}
          viewport={{ once: true }}
          transition={{ duration: 1.2, ease: [0.2, 0.85, 0.25, 1] }}
          className="relative h-full overflow-hidden rounded-full"
          style={{ background: "linear-gradient(90deg,#7C5CFF,#4C7DFF)", boxShadow: "0 0 12px -2px rgba(124,92,255,.45)" }}
        >
          <span className="absolute inset-y-0 -left-1/3 w-1/3 animate-shimmer bg-sheen opacity-50" />
        </motion.div>
      </div>
    </div>
  );
}
