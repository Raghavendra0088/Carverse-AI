import { motion } from "framer-motion";

export default function Card({ children, className = "", hover = false, delay = 0, ...rest }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.45, delay, ease: [0.2, 0.8, 0.2, 1] }}
      className={`glass ${hover ? "glass-hover" : ""} p-6 ${className}`}
      {...rest}
    >
      {children}
    </motion.div>
  );
}
