import { motion } from "framer-motion";

export default function PageHead({ title, subtitle, right }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: [0.2, 0.8, 0.2, 1] }}
      className="mb-8 mt-2 flex flex-wrap items-end justify-between gap-4"
    >
      <div>
        <h1 className="font-display text-3xl font-semibold tracking-tight text-ink sm:text-[2.5rem] sm:leading-[1.05]">{title}</h1>
        {subtitle && <p className="mt-3 max-w-2xl text-[15px] font-normal leading-relaxed text-muted">{subtitle}</p>}
      </div>
      {right}
    </motion.div>
  );
}
