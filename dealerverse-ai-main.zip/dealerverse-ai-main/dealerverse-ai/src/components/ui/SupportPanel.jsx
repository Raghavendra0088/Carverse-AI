import { useState } from "react";
import { LifeBuoy, Send, MessageSquare, CheckCircle2, Clock, Loader } from "lucide-react";
import { useStore } from "../../store/useStore";
import { useWorkflow } from "../../store/useWorkflow";
import Card from "./Card";

const shortTime = (iso) => { try { return new Date(iso).toLocaleString([], { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }); } catch { return ""; } };
const STATUS = {
  open:        { c: "#F59E0B", label: "Open",        icon: Clock },
  in_progress: { c: "#38BDF8", label: "In progress", icon: Loader },
  closed:      { c: "#22C55E", label: "Resolved",    icon: CheckCircle2 },
};

// Reusable Customer Care panel for buyers & sellers: post a query, see replies.
export default function SupportPanel({ me }) {
  const tickets = useWorkflow((s) => s.tickets);
  const postTicket = useWorkflow((s) => s.postTicket);
  const pushToast = useStore((s) => s.pushToast);
  const [subject, setSubject] = useState("");
  const [msg, setMsg] = useState("");

  if (!me) return null;
  const mine = tickets.filter((t) => t.fromId === me.id);

  const submit = () => {
    if (!msg.trim()) return;
    postTicket({ fromId: me.id, fromName: me.name, fromKind: me.kind === "buyer" ? "buyer" : "seller", subject: subject.trim() || "General query", message: msg.trim() });
    pushToast({ id: Date.now(), icon: "🎧", label: "Query sent to Customer Care", xp: 0, color: "#2EE6A6", name: me.name });
    setSubject(""); setMsg("");
  };

  return (
    <Card>
      <div className="mb-4 flex items-center gap-2">
        <LifeBuoy size={18} strokeWidth={1.75} className="text-teal" />
        <h3 className="font-display text-base font-semibold text-ink">Customer Care</h3>
      </div>
      <p className="mb-4 text-sm text-muted">Have a question about your {me.kind === "buyer" ? "purchase" : "sale"}? Send it here — our Customer Care team will reply and you'll get an email.</p>

      <input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Subject (optional)" className="field mb-2" />
      <textarea value={msg} onChange={(e) => setMsg(e.target.value)} rows={3} placeholder="Type your query…" className="field mb-3 resize-none" />
      <button onClick={submit} disabled={!msg.trim()} className={`btn w-full ${msg.trim() ? "btn-primary" : "btn-ghost cursor-not-allowed opacity-60"}`}><Send size={15} /> Send query</button>

      {mine.length > 0 && (
        <div className="mt-5 space-y-3">
          <div className="text-xs font-semibold uppercase tracking-[0.14em] text-faint">Your queries</div>
          {mine.map((t) => (
            <div key={t.id} className="rounded-2xl border border-white/8 bg-white/[.02] p-3.5">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5 text-sm font-semibold text-ink"><MessageSquare size={14} strokeWidth={1.75} className="text-teal" /> {t.subject}</div>
                {(() => { const sm = STATUS[t.status] || STATUS.open; return (
                  <span className="chip shrink-0" style={{ color: sm.c, borderColor: `${sm.c}55` }}><sm.icon size={11} /> {sm.label}</span>
                ); })()}
              </div>
              <p className="mt-1.5 text-sm text-muted">{t.message}</p>
              <div className="mt-1 text-[11px] text-faint">{shortTime(t.at)}</div>
              {t.replies.map((r, i) => (
                <div key={i} className="mt-2 rounded-xl border border-teal/20 bg-teal/[.06] p-2.5">
                  <div className="text-[11px] font-semibold text-teal">🎧 {r.by} · Customer Care</div>
                  <p className="mt-1 text-sm text-ink">{r.text}</p>
                  <div className="mt-1 text-[11px] text-faint">{shortTime(r.at)}</div>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}
