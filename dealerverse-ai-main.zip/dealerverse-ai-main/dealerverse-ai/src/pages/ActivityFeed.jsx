import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Play, Pause, RotateCcw } from "lucide-react";
import { feed } from "../data/db";
import { actionMeta, DEPT_COLOR, fmt } from "../lib/gamify";
import { confetti } from "../lib/confetti";
import Card from "../components/ui/Card";
import PageHead from "../components/ui/PageHead";
import Avatar from "../components/ui/Avatar";

export default function ActivityFeed() {
  const [i, setI] = useState(0);
  const [playing, setPlaying] = useState(true);
  const xpRef = useRef(0);
  const [xpSum, setXpSum] = useState(0);

  useEffect(() => {
    if (!playing) return;
    const t = setInterval(() => {
      setI((x) => {
        if (x >= feed.length) { setPlaying(false); return x; }
        const ev = feed[x];
        xpRef.current += ev.xp; setXpSum(xpRef.current);
        if (ev.collab || ev.xp >= 60) confetti(innerWidth * 0.35, 220, 26);
        return x + 1;
      });
    }, 550);
    return () => clearInterval(t);
  }, [playing]);

  const reset = () => { setI(0); xpRef.current = 0; setXpSum(0); setPlaying(true); };
  const visible = feed.slice(Math.max(0, i - 24), i).reverse();

  return (
    <>
      <PageHead
        title="Live Activity Feed"
        subtitle="Real milestones from the event log, replayed as XP — this is what employees see all day."
        right={
          <div className="flex items-center gap-2">
            <button onClick={() => setPlaying((p) => !p)} className="btn btn-primary !py-2">
              {playing ? <Pause size={15} /> : <Play size={15} />} {playing ? "Pause" : "Play"}
            </button>
            <button onClick={reset} className="btn btn-ghost !py-2"><RotateCcw size={15} /> Restart</button>
          </div>
        }
      />

      <div className="mb-5 grid grid-cols-3 gap-4">
        <Card className="text-center"><div className="font-display text-2xl font-bold grad-text">{fmt(i)}</div><div className="text-xs uppercase tracking-wider text-muted">events replayed</div></Card>
        <Card className="text-center"><div className="font-display text-2xl font-bold grad-gold">{fmt(xpSum)}</div><div className="text-xs uppercase tracking-wider text-muted">XP awarded</div></Card>
        <Card className="text-center"><div className="font-display text-2xl font-bold text-good">{fmt(feed.length)}</div><div className="text-xs uppercase tracking-wider text-muted">in this stream</div></Card>
      </div>

      <div className="space-y-2">
        <AnimatePresence initial={false}>
          {visible.map((ev, idx) => {
            const m = actionMeta(ev.action);
            const top = idx === 0;
            return (
              <motion.div
                key={`${ev.ts}-${ev.bk}-${ev.action}`}
                layout
                initial={{ opacity: 0, y: -14, scale: 0.98 }}
                animate={{ opacity: top ? 1 : 0.72, y: 0, scale: 1 }}
                exit={{ opacity: 0 }}
                transition={{ type: "spring", stiffness: 380, damping: 30 }}
                className={`glass flex items-center gap-3 px-4 py-3 ${top ? "ring-1 ring-violet/40 shadow-glow" : ""}`}
              >
                <Avatar name={ev.name} size={38} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm text-ink">
                    <span className="font-semibold">{ev.name}</span>{" "}
                    <span className="text-muted">{ev.collab ? `teamed up with ${ev.with}` : m.label.toLowerCase()}</span>
                  </div>
                  <div className="text-xs text-faint">{ev.ts.slice(0, 16).replace("T", " ")} · {ev.bk}</div>
                </div>
                <span className="chip" style={{ color: DEPT_COLOR[ev.dept] || "#969CB6", borderColor: `${DEPT_COLOR[ev.dept] || "#969CB6"}55` }}>{ev.dept}</span>
                <div className="text-xl">{m.icon}</div>
                <div className="w-14 text-right font-display font-bold" style={{ color: m.color }}>+{ev.xp}</div>
              </motion.div>
            );
          })}
        </AnimatePresence>
        {i === 0 && <Card className="text-center text-muted">Press play to replay the dealership's real activity as XP ▶</Card>}
      </div>
    </>
  );
}
