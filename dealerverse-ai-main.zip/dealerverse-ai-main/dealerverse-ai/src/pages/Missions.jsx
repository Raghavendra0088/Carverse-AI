import { motion } from "framer-motion";
import { CheckCircle2, Circle, Gift, Info, Radio, Crown, Lock, ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useStore, useMe } from "../store/useStore";
import { missionsFor, bonusMissionsFor, isMaxRank, deptLabel } from "../lib/gamify";
import Card from "../components/ui/Card";
import PageHead from "../components/ui/PageHead";

// where each mission is actually accomplished — doing the real work there auto-updates it
const MISSION_ROUTE = { DISPATCH_BY_PDI: "/pipeline" };
const missionRoute = (action) => MISSION_ROUTE[action] || "/bookings";
const routeName = (to) => (to === "/pipeline" ? "Pipeline" : "Bookings");

function Mission({ m, delay, gold = false, onDo }) {
  const pct = Math.min(100, (m.progress / m.target) * 100);
  const done = m.progress >= m.target;
  const fill = done ? "#22C55E" : gold ? "linear-gradient(90deg,#FFC53D,#F59E0B)" : "linear-gradient(90deg,#7C5CFF,#4C7DFF)";
  return (
    <Card hover delay={delay}
      className={done ? "ring-1 ring-good/40" : gold ? "ring-1 ring-gold/30" : ""}
      style={gold ? { background: "linear-gradient(180deg, rgba(255,197,61,.07), rgba(255,255,255,.015))" } : undefined}>
      <div className="flex items-start gap-3">
        <div className="text-3xl">{m.icon}</div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <h3 className="font-display font-semibold text-ink">{m.title}</h3>
            {done && <CheckCircle2 size={16} className="text-good" />}
          </div>
          <p className="text-sm text-muted">{m.desc}</p>
        </div>
        <span className="chip shrink-0" style={{ color: "#FFC53D", borderColor: "#FFC53D55" }}><Gift size={12} /> {m.reward}</span>
      </div>
      {m.purpose && (
        <div className="mt-3 flex items-start gap-2 rounded-2xl border border-white/6 bg-white/[.02] px-3 py-2 text-xs leading-relaxed text-faint">
          <Info size={13} strokeWidth={1.75} className={`mt-0.5 shrink-0 ${gold ? "text-gold" : "text-violet-400"}`} />
          <span><span className="font-medium text-muted">Why this matters:</span> {m.purpose}</span>
        </div>
      )}
      <div className="mt-4">
        <div className="mb-1.5 flex justify-between text-xs text-muted">
          <span>{m.progress} / {m.target}</span><span>{Math.round(pct)}%</span>
        </div>
        <div className="h-2 overflow-hidden rounded-full bg-white/[.06]">
          <motion.div initial={false} animate={{ width: `${pct}%` }} transition={{ type: "spring", stiffness: 120, damping: 20 }}
            className="h-full rounded-full" style={{ background: fill }} />
        </div>
      </div>
      {done ? (
        <div className="mt-3 flex items-center justify-center gap-1.5 rounded-2xl border border-good/20 bg-good/5 py-2 text-sm font-semibold text-good">
          <CheckCircle2 size={15} /> Completed{m.reward ? ` · ${m.reward}` : ""}
        </div>
      ) : (
        <button onClick={() => onDo(m)}
          className={`btn mt-3 w-full !py-2 ${gold ? "" : "btn-primary"}`}
          style={gold ? { background: "linear-gradient(120deg,#FFC53D,#F59E0B)", color: "#1a1206", boxShadow: "0 8px 22px -12px rgba(245,158,11,.7)" } : undefined}>
          Do it in {routeName(missionRoute(m.action))} <ArrowRight size={15} />
        </button>
      )}
    </Card>
  );
}

export default function Missions() {
  const me = useMe();
  const liveCounts = useStore((s) => s.liveCounts);
  const nav = useNavigate();
  if (!me) return null;
  const missions = missionsFor(me, liveCounts);
  const done = missions.filter((m) => m.progress >= m.target).length;
  const maxed = isMaxRank(me);
  const bonus = bonusMissionsFor(me, liveCounts);

  // redirect to where the mission is actually accomplished — doing the real work
  // there (opening bookings, approving loans, inspecting, etc.) auto-updates it
  const handleDo = (m) => nav(missionRoute(m.action));

  return (
    <>
      <PageHead title="Daily Missions"
        subtitle={`${done} of ${missions.length} complete today · they update automatically as you do the real work`}
        right={<span className="chip"><Radio size={13} className="animate-pulse-glow text-good" /> Live progress</span>} />
      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
        {["🎯 Daily reset", "🔥 Streak x" + me.streak, "🏆 " + me.rank, "🤝 " + me.collab + " team-ups"].map((t, i) => (
          <Card key={i} delay={i * 0.05} className="text-center text-sm font-semibold text-ink">{t}</Card>
        ))}
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        {missions.map((m, i) => <Mission key={m.id} m={m} delay={i * 0.06} onDo={handleDo} />)}
      </div>

      {/* Legend Challenges — unlocked at max rank */}
      {maxed ? (
        <div className="mt-8">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <Crown size={18} strokeWidth={1.75} className="text-gold" />
            <h3 className="font-display text-lg font-semibold"><span className="grad-gold">Legend Challenges</span></h3>
            <span className="chip" style={{ color: "#FFC53D", borderColor: "#FFC53D55" }}>Unlocked · Bonus XP</span>
          </div>
          <p className="mb-4 text-sm text-muted">You've topped your ladder — prestige tasks with <b className="text-gold">bonus XP</b> to keep you ahead this season. The live ones fill as you log milestones.</p>
          <div className="grid gap-4 sm:grid-cols-2">
            {bonus.map((m, i) => <Mission key={m.id} m={m} delay={i * 0.06} gold onDo={handleDo} />)}
          </div>
        </div>
      ) : (
        <Card delay={0.15} className="mt-8 flex items-center gap-3 text-sm text-muted">
          <Lock size={16} className="shrink-0 text-gold" />
          <span><b className="text-ink">Legend Challenges</b> — reach the top rank in {deptLabel(me.dept)} to unlock prestige tasks worth <b className="text-gold">bonus XP</b>.</span>
        </Card>
      )}

      <Card delay={0.2} className="mt-4 flex items-center gap-3 text-sm text-muted">
        <Circle size={16} className="text-violet-400" />
        Missions regenerate daily and scale with your rank. Tap <b className="text-ink">Do it in Bookings</b> to jump to the work — advancing a booking as your department auto-completes the matching mission here.
      </Card>
    </>
  );
}
