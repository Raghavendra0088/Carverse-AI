import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Zap, ArrowRight, Briefcase, User, Lock, Eye, ShoppingCart, Sparkles, ShieldCheck } from "lucide-react";
import { useStore } from "../store/useStore";
import { useWorkflow } from "../store/useWorkflow";
import { departmentsList, supervisors, staffFor, pinFor, meta } from "../data/db";
import { deptLabel } from "../lib/gamify";
import BackgroundFX from "../components/layout/BackgroundFX";

const label = (d) => (d === "SUPERVISOR" ? "⭐ Supervisor" : deptLabel(d));
const routeFor = (sup) => (sup ? "/evaluate" : "/dashboard");
const MAX_ATTEMPTS = 3;
const LOCK_MS = 30000;
const genOtp = () => String(Math.floor(100000 + Math.random() * 900000));

export default function Login() {
  const nav = useNavigate();
  const loginEmployee = useStore((s) => s.loginEmployee);
  const loginCustomer = useStore((s) => s.loginCustomer);
  const loginBuyer = useStore((s) => s.loginBuyer);
  const ensureCustomer = useWorkflow((s) => s.ensureCustomer);
  const ensureBuyer = useWorkflow((s) => s.ensureBuyer);

  const [mode, setMode] = useState("employee");
  const cats = [...departmentsList, "SUPERVISOR"];
  const [cat, setCat] = useState(departmentsList[0] || "SALES");
  const people = cat === "SUPERVISOR" ? supervisors : staffFor(cat);
  const [empId, setEmpId] = useState(people[0]?.id);
  const [pin, setPin] = useState("");
  const [err, setErr] = useState("");
  const [showHint, setShowHint] = useState(false);
  const [cust, setCust] = useState({ name: "", phone: "" });
  const [buyer, setBuyer] = useState({ name: "", phone: "" });

  // --- employee attempt lockout ---
  const [attempts, setAttempts] = useState(0);
  const [lockUntil, setLockUntil] = useState(0);
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (!lockUntil) return;
    const t = setInterval(() => setNow(Date.now()), 400);
    return () => clearInterval(t);
  }, [lockUntil]);
  const locked = lockUntil > now;
  const lockLeft = Math.max(0, Math.ceil((lockUntil - now) / 1000));

  // --- OTP verification for seller / buyer ---
  const [otp, setOtp] = useState({ sent: false, code: "", entry: "" });
  const [otpErr, setOtpErr] = useState("");

  const expectedPin = empId ? pinFor(empId) : "";

  const switchMode = (k) => { setMode(k); setOtp({ sent: false, code: "", entry: "" }); setOtpErr(""); setErr(""); };

  const pickCat = (c) => {
    setCat(c);
    const list = c === "SUPERVISOR" ? supervisors : staffFor(c);
    setEmpId(list[0]?.id); setPin(""); setErr("");
  };
  const pickEmp = (id) => { setEmpId(id); setPin(""); setErr(""); };

  const enterEmployee = () => {
    if (locked) return;
    if (pin !== expectedPin) {
      const a = attempts + 1;
      setPin("");
      if (a >= MAX_ATTEMPTS) { setLockUntil(Date.now() + LOCK_MS); setNow(Date.now()); setAttempts(0); setErr(`Too many attempts — locked for ${LOCK_MS / 1000}s.`); }
      else { setAttempts(a); setErr(`Incorrect PIN — ${MAX_ATTEMPTS - a} attempt${MAX_ATTEMPTS - a === 1 ? "" : "s"} left.`); }
      return;
    }
    setAttempts(0); setLockUntil(0);
    const sup = cat === "SUPERVISOR";
    const person = people.find((p) => p.id === empId) || people[0];
    loginEmployee(person.id, { supervisor: sup, dept: sup ? person.dept : cat });
    nav(routeFor(sup));
  };

  const sendOtp = () => { setOtp({ sent: true, code: genOtp(), entry: "" }); setOtpErr(""); };
  const verifyOtp = (onOk) => { if (otp.entry === otp.code) onOk(); else setOtpErr("Incorrect code — please re-enter."); };

  const enterCustomer = () => {
    const name = cust.name.trim() || "Guest Customer";
    loginCustomer(ensureCustomer(name, cust.phone), name);
    nav("/customer");
  };
  const enterBuyer = () => {
    const name = buyer.name.trim() || "Guest Buyer";
    loginBuyer(ensureBuyer(name, buyer.phone), name);
    nav("/market");
  };

  // shared OTP verification panel for seller/buyer (function, not a component, to preserve input focus)
  const renderOtp = (phone, onVerify) => (
    <>
      <label className="mb-2 block text-xs font-semibold uppercase tracking-[0.12em] text-muted">Verification code</label>
      <input value={otp.entry} onChange={(e) => { setOtp({ ...otp, entry: e.target.value.replace(/\D/g, "").slice(0, 6) }); setOtpErr(""); }}
        onKeyDown={(e) => e.key === "Enter" && verifyOtp(onVerify)} inputMode="numeric" placeholder="6-digit code"
        className={`field tracking-[0.4em] ${otpErr ? "!border-bad/70" : ""}`} />
      <div className="mb-4 mt-2 flex items-center justify-between text-xs">
        {otpErr ? <span className="text-bad">{otpErr}</span> : <span className="text-faint">Code sent to {phone || "your phone"}.</span>}
        <span className="text-muted">Demo code: <b className="text-ink">{otp.code}</b></span>
      </div>
      <button onClick={() => verifyOtp(onVerify)} disabled={otp.entry.length !== 6}
        className={`btn w-full ${otp.entry.length === 6 ? "btn-primary" : "btn-ghost cursor-not-allowed opacity-60"}`}>
        <ShieldCheck size={16} /> Verify & continue
      </button>
      <button onClick={() => setOtp({ sent: false, code: "", entry: "" })} className="mt-3 w-full text-center text-xs text-muted transition hover:text-ink">Use a different number</button>
    </>
  );

  return (
    <div className="relative flex min-h-screen">
      <BackgroundFX />

      {/* LEFT — brand */}
      <div className="relative hidden w-1/2 flex-col justify-between overflow-hidden p-12 lg:flex xl:p-16">
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
          className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-grad-vb font-display text-xl font-bold text-white shadow-[0_12px_30px_-10px_rgba(124,92,255,.8)]">D</div>
          <span className="font-display text-lg font-semibold tracking-tight text-ink">DealerVerse <span className="grad-text">AI</span></span>
        </motion.div>

        <div className="max-w-xl">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.1 }}
            className="chip mb-6 !px-4 !py-1.5">
            <Sparkles size={13} className="text-violet-400" /> Enterprise performance intelligence
          </motion.div>
          <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.15 }}
            className="font-display text-6xl font-semibold leading-[1.02] tracking-tight text-ink xl:text-7xl">
            DealerVerse <span className="grad-text">AI</span>
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.25 }}
            className="mt-6 max-w-md text-lg font-normal leading-relaxed text-muted">
            The Intelligent Dealership Performance Platform — turning real work into measurable momentum across every team.
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.35 }}
            className="mt-8 flex flex-wrap gap-2.5">
            {[["7 Departments", "text-violet-400"], ["Anti-gaming XP", "text-good"], ["Full C2B2C loop", "text-cyan"]].map(([t, c]) => (
              <span key={t} className="chip !py-1.5"><span className={`h-1.5 w-1.5 rounded-full bg-current ${c}`} /> {t}</span>
            ))}
          </motion.div>
        </div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}
          className="flex items-center gap-2 text-sm text-faint">
          <Zap size={14} className="text-gold" /> Powered by <span className="text-muted">{meta.totalEvents.toLocaleString()}</span> real dealership events
        </motion.div>
      </div>

      {/* RIGHT — auth */}
      <div className="flex flex-1 items-center justify-center px-6 py-10 lg:w-1/2">
        <div className="w-full max-w-md">
          <div className="mb-8 text-center lg:hidden">
            <h1 className="font-display text-4xl font-semibold tracking-tight text-ink">DealerVerse <span className="grad-text">AI</span></h1>
            <p className="mt-2 text-sm text-muted">The Intelligent Dealership Performance Platform</p>
          </div>

          <motion.div initial={{ opacity: 0, y: 18, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.55, ease: [0.2, 0.8, 0.2, 1] }} className="glass rounded-4xl p-7 sm:p-8">
            <div className="mb-1 flex items-center gap-2 font-display text-2xl font-semibold tracking-tight text-ink">Welcome back</div>
            <p className="mb-6 flex items-center gap-1.5 text-sm text-muted"><ShieldCheck size={14} className="text-good" /> Secure sign-in to your workspace.</p>

            <div className="mb-6 flex gap-1 rounded-full border border-white/8 bg-white/[.03] p-1">
              {[["employee", "Employee", Briefcase], ["customer", "Sell", User], ["buyer", "Buy", ShoppingCart]].map(([k, l, Icon]) => (
                <button key={k} onClick={() => switchMode(k)}
                  className={`flex flex-1 items-center justify-center gap-2 rounded-full px-3 py-2 text-sm font-semibold transition ${mode === k ? "bg-grad-vb text-white shadow-[0_10px_24px_-12px_rgba(124,92,255,.8)]" : "text-muted hover:text-ink"}`}>
                  <Icon size={15} strokeWidth={1.9} /> {l}
                </button>
              ))}
            </div>

            {mode === "employee" && (
              <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
                <label className="mb-2 block text-xs font-semibold uppercase tracking-[0.12em] text-muted">Department</label>
                <select value={cat} onChange={(e) => pickCat(e.target.value)} className="field mb-4 appearance-none">
                  {cats.map((c) => <option key={c} value={c} className="bg-surface">{label(c)}</option>)}
                </select>

                <label className="mb-2 block text-xs font-semibold uppercase tracking-[0.12em] text-muted">Sign in as</label>
                <select value={empId} onChange={(e) => pickEmp(e.target.value)} className="field mb-4 appearance-none">
                  {people.map((p) => <option key={p.id} value={p.id} className="bg-surface">{p.name}{p.designation ? ` — ${p.designation}` : ""}</option>)}
                </select>

                <label className="mb-2 block text-xs font-semibold uppercase tracking-[0.12em] text-muted">4-digit PIN</label>
                <div className="relative">
                  <Lock size={15} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-faint" />
                  <input value={pin} onChange={(e) => { setPin(e.target.value.replace(/\D/g, "").slice(0, 4)); setErr(""); }}
                    onKeyDown={(e) => e.key === "Enter" && enterEmployee()} inputMode="numeric" placeholder="••••" autoComplete="off" disabled={locked}
                    className={`field pl-11 tracking-[0.5em] ${err ? "!border-bad/70" : ""} ${locked ? "opacity-60" : ""}`} />
                </div>
                <div className="mb-5 mt-2 flex items-center justify-between text-xs">
                  {locked ? <span className="text-bad">🔒 Locked — try again in {lockLeft}s</span>
                    : err ? <span className="text-bad">{err}</span>
                    : <span className="text-faint">3 attempts, then a 30s lockout.</span>}
                  <button type="button" onClick={() => setShowHint((v) => !v)} className="flex items-center gap-1 text-muted transition hover:text-ink">
                    <Eye size={12} /> {showHint ? `Demo PIN: ${expectedPin}` : "Show demo PIN"}
                  </button>
                </div>
                <button onClick={enterEmployee} disabled={pin.length !== 4 || locked}
                  className={`btn w-full ${pin.length === 4 && !locked ? "btn-primary" : "btn-ghost cursor-not-allowed opacity-60"}`}>
                  {locked ? `Locked (${lockLeft}s)` : <>Enter as {label(cat)} <ArrowRight size={16} /></>}
                </button>
              </motion.div>
            )}

            {mode === "customer" && (
              <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
                <p className="mb-5 text-sm leading-relaxed text-muted">Sell or trade your car — post it and our team will evaluate & quote a price.</p>
                {!otp.sent ? (
                  <>
                    <input value={cust.name} onChange={(e) => setCust({ ...cust, name: e.target.value })} placeholder="Your name" className="field mb-3" />
                    <input value={cust.phone} onChange={(e) => setCust({ ...cust, phone: e.target.value.replace(/\D/g, "").slice(0, 10) })} inputMode="numeric" placeholder="Phone number" className="field mb-5" />
                    <button onClick={sendOtp} className="btn btn-primary w-full">Send verification code <ArrowRight size={16} /></button>
                    <p className="mt-3 flex items-center justify-center gap-1.5 text-xs text-faint"><ShieldCheck size={12} className="text-good" /> We verify sellers with a one-time code before listing.</p>
                  </>
                ) : renderOtp(cust.phone, enterCustomer)}
              </motion.div>
            )}

            {mode === "buyer" && (
              <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
                <p className="mb-5 text-sm leading-relaxed text-muted">Browse certified, dealer-owned cars and reserve one — we handle finance, paperwork and delivery.</p>
                {!otp.sent ? (
                  <>
                    <input value={buyer.name} onChange={(e) => setBuyer({ ...buyer, name: e.target.value })} placeholder="Your name" className="field mb-3" />
                    <input value={buyer.phone} onChange={(e) => setBuyer({ ...buyer, phone: e.target.value.replace(/\D/g, "").slice(0, 10) })} inputMode="numeric" placeholder="Phone number" className="field mb-5" />
                    <button onClick={sendOtp} className="btn btn-primary w-full"><ShoppingCart size={16} /> Send verification code <ArrowRight size={16} /></button>
                    <p className="mt-3 flex items-center justify-center gap-1.5 text-xs text-faint"><ShieldCheck size={12} className="text-good" /> Verified buyers only — we send a one-time code before you reserve.</p>
                  </>
                ) : renderOtp(buyer.phone, enterBuyer)}
              </motion.div>
            )}
          </motion.div>

          <p className="mt-6 text-center text-xs text-faint lg:hidden">Powered by {meta.totalEvents.toLocaleString()} real dealership events</p>
        </div>
      </div>
    </div>
  );
}
