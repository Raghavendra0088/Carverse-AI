import { useState } from "react";
import { motion } from "framer-motion";
import { TrendingUp, Rocket, Crown, Swords, ChevronUp, Trophy } from "lucide-react";
import { players, playersByDept, departments, gamifiedDepts } from "../data/db";
import { mostImproved, fastestGrowing } from "../data/db";
import { useStore, useMe } from "../store/useStore";
import { DEPT_COLOR, deptLabel, fmt } from "../lib/gamify";
import Card from "../components/ui/Card";
import PageHead from "../components/ui/PageHead";
import Avatar from "../components/ui/Avatar";

const medal = (i) => ["🥇", "🥈", "🥉"][i] || null;

export default function Leaderboard() {
  const me = useMe();
  const [tab, setTab] = useState("emp");
  const [dept, setDept] = useState("ALL");
  const list = (dept === "ALL" ? players : playersByDept(dept)).slice(0, 50);

  const top3 = list.slice(0, 3);
  const rest = list.slice(3);

  // ---- competitive standings (read-only, computed from existing data) ----
  const myOverall = me ? players.findIndex((p) => p.id === me.id) : -1;
  const meRow = myOverall >= 0 ? players[myOverall] : null;
  const above = myOverall > 0 ? players[myOverall - 1] : null;
  const myDeptList = meRow ? playersByDept(meRow.dept) : [];
  const myDeptIdx = meRow ? myDeptList.findIndex((p) => p.id === meRow.id) : -1;
  const deptLeader = myDeptList[0];

  // ---- department battle (top 2 by XP) ----
  const battle = [...departments].sort((a, b) => b.xp - a.xp).slice(0, 2);
  const [dA, dB] = battle;
  const battleTotal = battle.length === 2 ? dA.xp + dB.xp : 1;

  return (
    <>
      <PageHead title="Leaderboards" subtitle="Ranked on real, milestone-only XP — activity can't be farmed. Climb the board." />

      {/* your standing */}
      {meRow && (
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: [0.2, 0.8, 0.2, 1] }}
          className="glass mb-6 overflow-hidden rounded-4xl p-6">
          <div className="mb-5 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.14em] text-faint">
            <Trophy size={14} strokeWidth={1.75} className="text-gold" /> Your standing
          </div>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <div className="text-xs text-muted">Overall rank</div>
              <div className="mt-1 font-display text-3xl font-semibold"><span className="num-grad">#{myOverall + 1}</span> <span className="text-sm font-medium text-faint">of {fmt(players.length)}</span></div>
            </div>
            <div>
              <div className="text-xs text-muted">Rank in {deptLabel(meRow.dept)}</div>
              <div className="mt-1 font-display text-3xl font-semibold" style={{ color: DEPT_COLOR[meRow.dept] }}>#{myDeptIdx + 1}</div>
            </div>
            <div>
              <div className="text-xs text-muted">To overtake next</div>
              {above ? (
                <div className="mt-1"><span className="font-display text-2xl font-semibold text-gold">{fmt(above.xp - meRow.xp)}</span> <span className="text-sm text-muted">XP</span>
                  <div className="truncate text-xs text-faint">catch {above.name}</div></div>
              ) : <div className="mt-1 font-display text-xl font-semibold text-gold">#1 overall 👑</div>}
            </div>
            <div>
              <div className="text-xs text-muted">{deptLabel(meRow.dept)} lead</div>
              {myDeptIdx === 0
                ? <div className="mt-1 font-display text-xl font-semibold text-good">You're leading 👑</div>
                : <div className="mt-1"><span className="font-display text-2xl font-semibold text-ink">{fmt(deptLeader.xp - meRow.xp)}</span> <span className="text-sm text-muted">XP behind</span>
                    <div className="truncate text-xs text-faint">{deptLeader.name}</div></div>}
            </div>
          </div>
        </motion.div>
      )}

      {/* department battle */}
      {battle.length === 2 && (
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.05 }}
          className="glass mb-6 rounded-4xl p-6">
          <div className="mb-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.14em] text-faint">
            <Swords size={14} strokeWidth={1.75} className="text-violet-400" /> Department battle · this season
          </div>
          <div className="mb-3 flex items-center justify-between">
            <div className="font-display font-semibold" style={{ color: DEPT_COLOR[dA.name] }}>{dA.name} <span className="text-gold">{fmt(dA.xp)}</span></div>
            <div className="font-display font-semibold" style={{ color: DEPT_COLOR[dB.name] }}><span className="text-gold">{fmt(dB.xp)}</span> {dB.name}</div>
          </div>
          <div className="flex h-3 overflow-hidden rounded-full">
            <motion.div initial={{ width: 0 }} animate={{ width: `${(dA.xp / battleTotal) * 100}%` }} transition={{ duration: 1, ease: [0.2, 0.85, 0.25, 1] }}
              style={{ background: DEPT_COLOR[dA.name] }} />
            <motion.div initial={{ width: 0 }} animate={{ width: `${(dB.xp / battleTotal) * 100}%` }} transition={{ duration: 1, ease: [0.2, 0.85, 0.25, 1] }}
              style={{ background: DEPT_COLOR[dB.name] }} />
          </div>
          <div className="mt-3 text-center text-xs text-muted">
            <span className="font-semibold text-ink">{dA.name}</span> leads by <span className="font-semibold text-gold">{fmt(dA.xp - dB.xp)} XP</span>
          </div>
        </motion.div>
      )}

      <div className="mb-6 flex flex-wrap items-center gap-3">
        <div className="glass flex gap-1 rounded-full p-1">
          {[["emp", "Employees"], ["dept", "Departments"]].map(([k, l]) => (
            <button key={k} onClick={() => setTab(k)}
              className={`rounded-full px-5 py-2 text-sm font-semibold transition-all duration-200 ${tab === k ? "bg-gradient-to-r from-violet to-blue text-white shadow-[0_8px_20px_-10px_rgba(124,92,255,.7)]" : "text-muted hover:text-ink"}`}>{l}</button>
          ))}
        </div>
        {tab === "emp" && (
          <div className="flex flex-wrap gap-2">
            {["ALL", ...gamifiedDepts].map((d) => (
              <button key={d} onClick={() => setDept(d)}
                className={`chip transition ${dept === d ? "!border-violet/50 !bg-violet/12 !text-ink" : "hover:!text-ink"}`}>{d === "ALL" ? "All" : deptLabel(d)}</button>
            ))}
          </div>
        )}
      </div>

      {tab === "emp" ? (
        <>
          {/* podium — top 3 */}
          <div className="mb-8 grid gap-4 sm:grid-cols-3">
            {top3.map((p, i) => {
              const mine = me && p.id === me.id;
              const c = DEPT_COLOR[p.dept];
              return (
                <motion.div key={p.id}
                  initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }}
                  transition={{ type: "spring", stiffness: 120, damping: 18, delay: i * 0.08 }}
                  className={`glass glass-hover relative flex flex-col items-center rounded-4xl px-6 py-7 text-center ${i === 0 ? "sm:-translate-y-3 ring-1 ring-violet/40" : ""} ${mine ? "ring-1 ring-violet/60" : ""}`}>
                  <div className="absolute left-5 top-5 text-2xl">{medal(i)}</div>
                  {i === 0 && <Crown size={18} strokeWidth={1.75} className="absolute right-5 top-5 text-gold" />}
                  <div className="rounded-full p-[3px]" style={{ background: `linear-gradient(140deg, ${c}, transparent)` }}>
                    <Avatar name={p.name} size={i === 0 ? 78 : 64} />
                  </div>
                  <div className="mt-4 font-display text-base font-semibold text-ink">
                    {p.name} {mine && <span className="text-xs text-violet-400">(you)</span>}
                  </div>
                  <div className="mt-0.5 text-xs text-muted">{p.rank}</div>
                  <span className="chip mt-3" style={{ color: c, borderColor: `${c}55`, background: `${c}14` }}>{deptLabel(p.dept)}</span>
                  <div className="mt-4 font-display text-2xl font-bold text-gold">{fmt(p.xp)} <span className="text-sm font-medium text-muted">XP</span></div>
                </motion.div>
              );
            })}
          </div>

          {/* ranks 4+ */}
          <div className="space-y-2.5">
            {rest.map((p, i) => {
              const mine = me && p.id === me.id;
              const c = DEPT_COLOR[p.dept];
              const gi = i + 3;                 // index into `list`
              const ahead = list[gi - 1];       // the person one place above
              const gap = ahead ? ahead.xp - p.xp : 0;
              return (
                <motion.div key={p.id}
                  initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: Math.min(i, 15) * 0.02 }}
                  className={`glass glass-hover flex items-center gap-4 rounded-2xl px-5 py-3 ${mine ? "ring-1 ring-violet/60" : ""}`}>
                  <div className="w-7 text-center font-display text-base font-semibold text-faint">{i + 4}</div>
                  <Avatar name={p.name} size={40} />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-semibold text-ink">{p.name} {mine && <span className="text-xs text-violet-400">(you)</span>}</div>
                    <div className="text-xs text-muted">{p.rank}</div>
                  </div>
                  <div className="hidden items-center gap-1 text-[11px] text-faint md:flex" title={ahead ? `${fmt(gap)} XP behind ${ahead.name}` : ""}>
                    <ChevronUp size={12} className="text-good" /> {fmt(gap)} behind
                  </div>
                  <span className="chip hidden sm:inline-flex" style={{ color: c, borderColor: `${c}55`, background: `${c}12` }}>{deptLabel(p.dept)}</span>
                  <div className="w-24 text-right font-display font-bold text-gold">{fmt(p.xp)} <span className="text-xs font-medium text-muted">XP</span></div>
                </motion.div>
              );
            })}
          </div>
        </>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {departments.map((d, i) => {
            const max = Math.max(...departments.map((x) => x.xp));
            const c = DEPT_COLOR[d.name];
            return (
              <Card key={d.name} hover delay={i * 0.06}>
                <div className="flex items-center justify-between">
                  <div className="font-display text-lg font-semibold text-ink">{d.name}</div>
                  <div className="font-display text-2xl font-bold" style={{ color: c }}>{fmt(d.xp)}</div>
                </div>
                <div className="mt-4 h-2.5 overflow-hidden rounded-full bg-white/[.06]">
                  <motion.div initial={{ width: 0 }} animate={{ width: `${(d.xp / max) * 100}%` }} transition={{ duration: 1, ease: [0.2, 0.85, 0.25, 1] }}
                    className="h-full rounded-full" style={{ background: `linear-gradient(90deg, ${c}, ${c}99)` }} />
                </div>
                <div className="mt-4 flex gap-4 text-sm text-muted">
                  <span>{d.members} players</span><span>{fmt(d.milestones)} milestones</span><span>{fmt(d.collab)} team-ups</span>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        <Card>
          <div className="mb-4 flex items-center gap-2"><TrendingUp size={17} strokeWidth={1.75} className="text-good" /><h3 className="font-display font-semibold text-ink">Most Improved</h3></div>
          <div className="space-y-1">
            {mostImproved.map((p, i) => (
              <div key={p.id} className="flex items-center justify-between rounded-xl px-3 py-2 text-sm transition hover:bg-white/[.03]">
                <span className="text-ink"><span className="mr-2 text-faint">{i + 1}</span>{p.name}</span>
                <span className="font-semibold text-good">+{fmt(p.delta)} XP</span>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <div className="mb-4 flex items-center gap-2"><Rocket size={17} strokeWidth={1.75} className="text-violet-400" /><h3 className="font-display font-semibold text-ink">Fastest Growing</h3></div>
          <div className="space-y-1">
            {fastestGrowing.map((p, i) => (
              <div key={p.id} className="flex items-center justify-between rounded-xl px-3 py-2 text-sm transition hover:bg-white/[.03]">
                <span className="text-ink"><span className="mr-2 text-faint">{i + 1}</span>{p.name}</span>
                <span className="font-semibold text-violet-400">{fmt(p.lastWeek)} XP / wk</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </>
  );
}
