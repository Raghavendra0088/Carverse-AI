import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { ShieldCheck, Gauge, Calendar, RotateCcw, BadgeCheck, Search, Fuel, ChevronRight } from "lucide-react";
import { useStore, useMe } from "../store/useStore";
import { useWorkflow } from "../store/useWorkflow";
import { inr } from "../lib/workflow";
import { fullSpecs } from "../lib/carimg";
import { confetti } from "../lib/confetti";
import Card from "../components/ui/Card";
import PageHead from "../components/ui/PageHead";
import CarImage from "../components/ui/CarImage";
import CarDetailModal from "../components/ui/CarDetailModal";

let _tid = 0;

export default function Marketplace() {
  const me = useMe();
  const nav = useNavigate();
  const pushToast = useStore((s) => s.pushToast);
  const inventory = useWorkflow((s) => s.inventory);
  const bookings = useWorkflow((s) => s.bookings);
  const reserveInventory = useWorkflow((s) => s.reserveInventory);

  const [q, setQ] = useState("");
  const [selected, setSelected] = useState(null);
  const listed = inventory.filter((it) => it.status === "LISTED" && it.model.toLowerCase().includes(q.toLowerCase()));
  const myReserved = bookings.filter((b) => b.buyerId === me?.id && !b.closed).length;

  const reserve = (it) => {
    const b = reserveInventory(it.id, me);
    if (b) {
      pushToast({ id: ++_tid, icon: "🅿️", label: `Reserved ${it.model} — check your email`, xp: 0, color: "#7C5CFF", name: me.name });
      confetti(innerWidth / 2, 240, 48);
      setSelected(null);
      nav("/purchases");
    }
  };

  return (
    <>
      <PageHead title="Marketplace" subtitle="Certified, dealership-owned cars — tap any car for full specs & features, then reserve. We handle finance, paperwork & delivery."
        right={myReserved > 0 ? <span className="chip" onClick={() => nav("/purchases")} style={{ cursor: "pointer" }}>🅿️ {myReserved} reserved</span> : null} />

      <div className="mb-6 flex items-center gap-2.5 rounded-2xl border border-white/8 bg-white/[.03] px-4 py-3 focus-within:border-violet/50">
        <Search size={16} className="text-faint" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by model…"
          className="w-full bg-transparent text-ink outline-none placeholder:text-faint" />
      </div>

      {listed.length === 0 ? (
        <Card className="text-muted">No cars listed right now. Check back soon — trade-ins are being reconditioned. 🔧</Card>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {listed.map((it, i) => {
            const specs = fullSpecs(it.model, it.specs, it.year);
            return (
              <motion.button
                key={it.id} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i, 9) * 0.05 }}
                onClick={() => setSelected(it)}
                className="glass glass-hover group flex flex-col overflow-hidden text-left"
              >
                <div className="relative h-40 w-full overflow-hidden">
                  <CarImage model={it.model} images={it.images} className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.04]" />
                  <span className="absolute left-3 top-3 inline-flex items-center gap-1 rounded-full bg-good/15 px-2.5 py-1 text-xs font-semibold text-good ring-1 ring-good/30"><BadgeCheck size={12} /> Certified</span>
                </div>
                <div className="flex flex-1 flex-col p-5">
                  <div className="font-display text-lg font-semibold text-ink">{it.model}</div>
                  <div className="mt-1.5 flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted">
                    <span className="inline-flex items-center gap-1"><Calendar size={12} /> {it.year || "—"}</span>
                    <span className="inline-flex items-center gap-1"><Gauge size={12} /> {it.km ? `${Number(it.km).toLocaleString()} km` : "—"}</span>
                    <span className="inline-flex items-center gap-1"><Fuel size={12} /> {specs.fuel}</span>
                    <span className="inline-flex items-center gap-1"><ShieldCheck size={12} /> {it.points}-pt</span>
                  </div>
                  <div className="mt-auto flex items-end justify-between pt-4">
                    <div>
                      <div className="num-grad font-display text-2xl font-semibold tracking-tight">{inr(it.retailPrice)}</div>
                      <div className="text-[11px] text-faint">est. EMI {inr(Math.round(it.retailPrice / 60))}/mo</div>
                    </div>
                    <span className="inline-flex items-center gap-1 text-sm font-medium text-violet-400">Details <ChevronRight size={15} /></span>
                  </div>
                </div>
              </motion.button>
            );
          })}
        </div>
      )}

      <AnimatePresence>
        {selected && <CarDetailModal item={selected} onClose={() => setSelected(null)} onReserve={reserve} />}
      </AnimatePresence>
    </>
  );
}
