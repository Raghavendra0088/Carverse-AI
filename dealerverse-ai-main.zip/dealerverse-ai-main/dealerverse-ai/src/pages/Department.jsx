import { useState } from "react";
import { LineChart, Line, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { Users2, Zap, Trophy, HeartHandshake } from "lucide-react";
import { useStore, useMe } from "../store/useStore";
import { playersByDept, departments, weeklySeries, gamifiedDepts } from "../data/db";
import { DEPT_COLOR, deptLabel, fmt } from "../lib/gamify";
import Card from "../components/ui/Card";
import StatTile from "../components/ui/StatTile";
import PageHead from "../components/ui/PageHead";
import Avatar from "../components/ui/Avatar";

export default function Department() {
  const me = useMe();
  const [dept, setDept] = useState(gamifiedDepts.includes(me?.dept) ? me.dept : gamifiedDepts[0]);
  const d = departments.find((x) => x.name === dept) || departments[0];
  const members = playersByDept(dept).slice(0, 10);
  const color = DEPT_COLOR[dept];
  const series = weeklySeries.map((w) => ({ week: w.week.slice(5), xp: w[dept] || 0 }));

  return (
    <>
      <PageHead title="Department Dashboard" subtitle="Squad performance, contributors and momentum"
        right={
          <select value={dept} onChange={(e) => setDept(e.target.value)}
            className="rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm text-ink outline-none focus:border-violet/60">
            {gamifiedDepts.map((x) => <option key={x} value={x} className="bg-surface">{deptLabel(x)}</option>)}
          </select>
        } />

      <div className="mb-5 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatTile icon={Zap} label="Department XP" value={d.xp} accent={color} />
        <StatTile icon={Users2} label="Players" value={d.members} accent="#3B82F6" delay={0.05} />
        <StatTile icon={Trophy} label="Milestones" value={d.milestones} accent="#FFC53D" delay={0.1} />
        <StatTile icon={HeartHandshake} label="Team bonuses" value={d.collab} accent="#22C55E" delay={0.15} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <h3 className="mb-3 font-display font-semibold text-ink">Weekly XP momentum</h3>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={series} margin={{ left: 0, right: 8, top: 8 }}>
                <XAxis dataKey="week" tick={{ fill: "#5B6080", fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: "#12131F", border: "1px solid rgba(255,255,255,.1)", borderRadius: 12, color: "#E8EAF6" }} />
                <Line type="monotone" dataKey="xp" stroke={color} strokeWidth={3} dot={{ r: 3, fill: color }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card>
          <h3 className="mb-3 font-display font-semibold text-ink">Top contributors</h3>
          <div className="space-y-2">
            {members.map((p, i) => (
              <div key={p.id} className="flex items-center gap-2.5">
                <span className="w-5 text-center text-sm font-bold text-muted">{i + 1}</span>
                <Avatar name={p.name} size={30} />
                <span className="min-w-0 flex-1 truncate text-sm text-ink">{p.name}</span>
                <span className="text-sm font-semibold text-gold">{fmt(p.xp)}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </>
  );
}
