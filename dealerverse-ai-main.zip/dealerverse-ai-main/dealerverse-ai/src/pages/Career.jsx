import { motion } from "framer-motion";
import { Lock, Check } from "lucide-react";
import { useStore, useMe } from "../store/useStore";
import { rankLadder, players } from "../data/db";
import { rankProgress, fmt, deptLabel } from "../lib/gamify";
import Card from "../components/ui/Card";
import PageHead from "../components/ui/PageHead";
import XPBar from "../components/ui/XPBar";

export default function Career() {
  const me = useMe();
  if (!me) return null;
  const ladder = rankLadder(me.dept);
  const rp = rankProgress(me);
  const peersAt = (idx) => players.filter((p) => p.dept === me.dept && p.rankIdx === idx).length;

  return (
    <>
      <PageHead title="Career Progression" subtitle={`Your path up the ${deptLabel(me.dept)} ladder`} />

      <Card className="mb-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="text-xs uppercase tracking-widest text-muted">Current rank</div>
            <div className="font-display text-2xl font-bold grad-text">{me.rank}</div>
          </div>
          <div className="text-right">
            <div className="text-xs text-muted">{rp.next != null ? `Next: ${me.rankNextName}` : "Top rank reached 👑"}</div>
            <div className="font-display text-lg font-bold text-gold">{rp.next != null ? `${fmt(rp.toNext)} XP to go` : `${fmt(me.xp)} XP`}</div>
          </div>
        </div>
        <div className="mt-4"><XPBar pct={rp.pct} /></div>
      </Card>

      <div className="relative pl-8">
        <div className="absolute bottom-4 left-3 top-4 w-0.5 bg-white/10" />
        {ladder.slice().reverse().map((r, ri) => {
          const idx = r.idx;
          const state = idx < me.rankIdx ? "done" : idx === me.rankIdx ? "current" : "locked";
          return (
            <motion.div key={idx} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: ri * 0.06 }}
              className="relative mb-4">
              <div className={`absolute -left-[22px] top-4 flex h-5 w-5 items-center justify-center rounded-full ring-4 ring-base ${
                state === "done" ? "bg-good" : state === "current" ? "bg-grad-vb" : "bg-white/10"}`}>
                {state === "done" && <Check size={12} className="text-white" />}
                {state === "locked" && <Lock size={10} className="text-faint" />}
              </div>
              <Card className={`${state === "current" ? "ring-1 ring-violet/50 shadow-glow" : state === "locked" ? "opacity-60" : ""}`}>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-display text-lg font-bold text-ink">{r.name}</span>
                      {state === "current" && <span className="chip" style={{ color: "#9B7CFF", borderColor: "#9B7CFF55" }}>You are here</span>}
                    </div>
                    <div className="text-xs text-muted">Unlocks at {fmt(r.xp)} XP · {peersAt(idx)} employees at this rank</div>
                  </div>
                  <div className="font-display text-2xl font-bold text-faint">Lvl {idx + 1}</div>
                </div>
              </Card>
            </motion.div>
          );
        })}
      </div>
    </>
  );
}
