import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, Target, TrendingUp, TrendingDown, ArrowRight, Rocket, MessageSquare, Send } from "lucide-react";
import { useStore, useMe } from "../store/useStore";
import { coachInsights, coachDevelopments, missionsFor, weeklyDelta, TONE, fmt, rankProgress, coachReply } from "../lib/gamify";
import Card from "../components/ui/Card";
import PageHead from "../components/ui/PageHead";

export default function Coach() {
  const me = useMe();
  const liveCounts = useStore((s) => s.liveCounts);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const endRef = useRef(null);
  useEffect(() => { if (me && messages.length === 0) setMessages([{ role: "coach", text: coachReply(me, "", liveCounts) }]); /* eslint-disable-next-line */ }, [me]);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);
  const send = (text) => {
    const t = (text ?? input).trim();
    if (!t || !me) return;
    setMessages((m) => [...m, { role: "user", text: t }, { role: "coach", text: coachReply(me, t, liveCounts) }]);
    setInput("");
  };
  if (!me) return null;
  const insights = coachInsights(me, liveCounts);
  const wd = weeklyDelta(me);
  const rp = rankProgress(me);
  const developments = coachDevelopments(me, liveCounts);
  const nextActions = missionsFor(me, liveCounts).filter((m) => m.progress < m.target).slice(0, 3);
  const up = wd.pct >= 0;

  return (
    <>
      <PageHead title="AI Coach" subtitle="Personalised, data-driven nudges — computed from your real activity, not guesswork." />

      {/* hero */}
      <motion.div
        initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: [0.2, 0.8, 0.2, 1] }}
        className="glass relative mb-6 overflow-hidden rounded-4xl p-8"
      >
        <div className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full bg-violet/20 opacity-40 blur-3xl" />
        <div className="relative flex flex-col gap-6 sm:flex-row sm:items-center">
          <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-3xl bg-grad-vb text-white shadow-[0_16px_40px_-16px_rgba(124,92,255,.9)]">
            <Sparkles size={30} strokeWidth={1.75} />
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="font-display text-2xl font-semibold tracking-tight text-ink sm:text-3xl">
              Hey {me.name.split(" ")[0]}, here's your game plan.
            </h2>
            <div className="mt-3 flex flex-wrap items-center gap-2.5">
              <span className="chip">
                <Target size={13} className="text-violet-400" />
                {rp.next != null ? `${fmt(rp.toNext)} XP from ${me.rankNextName}` : "You're at max rank"}
              </span>
              <span className="chip">
                {up ? <TrendingUp size={13} className="text-good" /> : <TrendingDown size={13} className="text-bad" />}
                XP {up ? "up" : "down"} {Math.abs(wd.pct)}% this week
              </span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* interactive chat */}
      <Card className="mb-6">
        <div className="mb-4 flex items-center gap-2">
          <MessageSquare size={18} strokeWidth={1.75} className="text-violet-400" />
          <h3 className="font-display text-base font-semibold text-ink">Chat with your coach</h3>
          <span className="chip ml-auto">Reads your real data</span>
        </div>
        <div className="max-h-[22rem] space-y-3 overflow-y-auto pr-1">
          <AnimatePresence initial={false}>
            {messages.map((m, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                className={m.role === "user" ? "flex justify-end" : "flex items-start gap-2.5"}>
                {m.role === "coach" && (
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-grad-vb text-white"><Sparkles size={15} strokeWidth={1.75} /></div>
                )}
                <div className={m.role === "user"
                  ? "max-w-[80%] whitespace-pre-line rounded-2xl rounded-br-md bg-grad-vb px-4 py-2.5 text-sm text-white"
                  : "max-w-[85%] whitespace-pre-line rounded-2xl rounded-tl-md border border-white/8 bg-white/[.04] px-4 py-2.5 text-sm leading-relaxed text-ink"}>
                  {m.text}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          <div ref={endRef} />
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {["Boost XP fast", "My next rank", "Which missions are left?", "How do I improve?"].map((s) => (
            <button key={s} onClick={() => send(s)} className="chip transition hover:text-ink">{s}</button>
          ))}
        </div>
        <div className="mt-3 flex items-center gap-2">
          <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder="Ask your coach anything…" className="field" />
          <button onClick={() => send()} disabled={!input.trim()} className={`btn !px-4 ${input.trim() ? "btn-primary" : "btn-ghost cursor-not-allowed opacity-60"}`}><Send size={15} /></button>
        </div>
      </Card>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* insight feed */}
        <div className="space-y-3 lg:col-span-2">
          <div className="px-1 text-xs font-semibold uppercase tracking-[0.14em] text-faint">Insights for you</div>
          {insights.map((it, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }}
              transition={{ type: "spring", stiffness: 260, damping: 24, delay: i * 0.06 }}
              className="glass glass-hover flex items-start gap-4 rounded-3xl p-5"
            >
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border border-white/8 bg-white/[.04] text-xl">
                {it.icon}
              </div>
              <div className="min-w-0 flex-1 pt-1">
                <p className="text-[15px] leading-relaxed text-ink">
                  <span className={`mr-1.5 ${TONE[it.tone]}`}>●</span>{it.text}
                </p>
              </div>
            </motion.div>
          ))}

          {/* how to improve — recommended developments */}
          <div className="flex items-center gap-2 px-1 pt-4 text-xs font-semibold uppercase tracking-[0.14em] text-faint">
            <Rocket size={13} strokeWidth={1.75} className="text-violet-400" /> How to improve — recommended developments
          </div>
          {developments.map((d, i) => (
            <motion.div
              key={`dev-${i}`}
              initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }}
              transition={{ type: "spring", stiffness: 260, damping: 24, delay: 0.05 + i * 0.06 }}
              className="glass glass-hover flex items-start gap-4 rounded-3xl p-5"
            >
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl border border-violet/20 bg-violet/10 text-xl">{d.icon}</div>
              <div className="min-w-0 flex-1">
                <div className="font-display font-semibold text-ink">{d.title}</div>
                <p className="mt-1 text-sm leading-relaxed text-muted">{d.detail}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* actions + summary */}
        <div className="space-y-6">
          <Card>
            <div className="mb-4 flex items-center gap-2">
              <Target size={16} strokeWidth={1.75} className="text-violet-400" />
              <h3 className="font-display text-base font-semibold text-ink">Next best actions</h3>
            </div>
            <div className="space-y-3">
              {nextActions.length === 0 && (
                <p className="rounded-2xl border border-good/20 bg-good/5 p-4 text-sm text-good">All missions done — you're on fire! 🔥</p>
              )}
              {nextActions.map((m) => (
                <div key={m.id} className="group rounded-2xl border border-white/8 bg-white/[.03] p-4 transition hover:border-white/15 hover:bg-white/[.05]">
                  <div className="flex items-center gap-2 text-sm font-semibold text-ink">
                    <span className="text-base">{m.icon}</span> {m.title}
                  </div>
                  <div className="mt-2 flex items-center gap-1.5 text-xs text-muted">
                    <span className="font-semibold text-ink">{m.target - m.progress}</span> to go
                    <ArrowRight size={12} className="text-faint" />
                    <span className="text-violet-400">{m.reward}</span>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="relative overflow-hidden">
            <div className="pointer-events-none absolute -right-8 -top-8 h-24 w-24 rounded-full bg-good/20 opacity-30 blur-3xl" />
            <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.14em] text-muted">
              <TrendingUp size={14} strokeWidth={1.75} className="text-good" /> Last 7 active days
            </div>
            <div className="num-grad font-display text-4xl font-semibold tracking-tight">{fmt(wd.last7)}</div>
            <div className="mt-1 text-xs text-faint">XP earned · {up ? "trending up" : "trending down"} {Math.abs(wd.pct)}% vs prior week</div>
          </Card>
        </div>
      </div>
    </>
  );
}
