import { LineChart, Line, ResponsiveContainer, Tooltip, XAxis, Legend } from "recharts";
import { Building2, Users2, Zap, HeartHandshake } from "lucide-react";
import { players, departments, weeklySeries, gamifiedDepts, meta } from "../data/db";
import { DEPT_COLOR, deptLabel, fmt } from "../lib/gamify";
import Card from "../components/ui/Card";
import StatTile from "../components/ui/StatTile";
import PageHead from "../components/ui/PageHead";
import Avatar from "../components/ui/Avatar";

export default function Manager() {
  const totalXp = departments.reduce((s, d) => s + d.xp, 0);
  const totalPlayers = departments.reduce((s, d) => s + d.members, 0);
  const series = weeklySeries.map((w) => ({ ...w, week: w.week.slice(5) }));
  const top = players.slice(0, 8);
  const mostActive = [...players].sort((a, b) => b.milestones - a.milestones)[0];

  return (
    <>
      <PageHead title="Manager Dashboard" subtitle={`All departments overview · ${fmt(meta.totalEvents)} events processed`} />

      <div className="mb-5 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatTile icon={Zap} label="Total XP" value={totalXp} accent="#7C5CFF" />
        <StatTile icon={Users2} label="Active players" value={totalPlayers} accent="#3B82F6" delay={0.05} />
        <StatTile icon={Building2} label="Bookings" value={meta.bookings} accent="#FFC53D" delay={0.1} />
        <StatTile icon={HeartHandshake} label="Team-ups" value={meta.collabCount} accent="#22C55E" delay={0.15} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <h3 className="mb-3 font-display font-semibold text-ink">Weekly progress by department</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={series} margin={{ left: 0, right: 8, top: 8 }}>
                <XAxis dataKey="week" tick={{ fill: "#5B6080", fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: "#12131F", border: "1px solid rgba(255,255,255,.1)", borderRadius: 12, color: "#E8EAF6" }} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                {gamifiedDepts.map((d) => (
                  <Line key={d} type="monotone" dataKey={d} name={deptLabel(d)} stroke={DEPT_COLOR[d]} strokeWidth={2.5} dot={false} />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <div className="space-y-4">
          {departments.map((d, i) => (
            <Card key={d.name} hover delay={i * 0.06}>
              <div className="flex items-center justify-between">
                <span className="font-display font-bold text-ink">{d.name}</span>
                <span className="font-display text-xl font-bold" style={{ color: DEPT_COLOR[d.name] }}>{fmt(d.xp)}</span>
              </div>
              <div className="mt-2 text-xs text-muted">{d.members} players · {fmt(d.milestones)} milestones</div>
            </Card>
          ))}
          <Card className="bg-white/[.02]">
            <div className="text-xs uppercase tracking-wider text-muted">Most active employee</div>
            <div className="mt-1 flex items-center gap-2">
              <Avatar name={mostActive.name} size={32} />
              <div><div className="text-sm font-semibold text-ink">{mostActive.name}</div>
              <div className="text-xs text-muted">{fmt(mostActive.milestones)} milestones</div></div>
            </div>
          </Card>
        </div>
      </div>

      <Card className="mt-4">
        <h3 className="mb-3 font-display font-semibold text-ink">Top contributors</h3>
        <div className="grid gap-2 sm:grid-cols-2">
          {top.map((p, i) => (
            <div key={p.id} className="flex items-center gap-3 rounded-xl bg-white/[.03] px-3 py-2">
              <span className="w-5 text-center font-bold text-muted">{i + 1}</span>
              <Avatar name={p.name} size={32} />
              <div className="min-w-0 flex-1"><div className="truncate text-sm font-medium text-ink">{p.name}</div>
                <div className="text-xs text-muted">{p.rank} · {p.dept}</div></div>
              <span className="font-display font-bold text-gold">{fmt(p.xp)}</span>
            </div>
          ))}
        </div>
      </Card>
    </>
  );
}
