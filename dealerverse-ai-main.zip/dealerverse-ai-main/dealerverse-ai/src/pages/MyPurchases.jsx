import { useEffect } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Clock, CheckCircle2, Store, Mail, Fuel, Cog, BadgeCheck } from "lucide-react";
import { useMe } from "../store/useStore";
import { useWorkflow } from "../store/useWorkflow";
import { SALE_STAGES, inr } from "../lib/workflow";
import { fullSpecs } from "../lib/carimg";
import Card from "../components/ui/Card";
import PageHead from "../components/ui/PageHead";
import CarImage from "../components/ui/CarImage";
import SupportPanel from "../components/ui/SupportPanel";

function Track({ b }) {
  return (
    <div className="mt-4 flex items-center gap-1 overflow-x-auto pb-1">
      {SALE_STAGES.map((s, idx) => {
        const done = idx <= b.stageIdx;
        const cur = idx === b.stageIdx && !b.closed;
        return (
          <div key={s.key} className="flex items-center">
            <div title={s.label}
              className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-sm ring-1 ${
                done ? "bg-violet/25 ring-violet/60" : "bg-white/5 ring-white/10 opacity-50"} ${cur ? "ring-2 ring-violet shadow-glow" : ""}`}>
              {s.icon}
            </div>
            {idx < SALE_STAGES.length - 1 && <div className={`h-0.5 w-4 ${idx < b.stageIdx ? "bg-violet/60" : "bg-white/10"}`} />}
          </div>
        );
      })}
    </div>
  );
}

const fmtTime = (iso) => {
  try { return new Date(iso).toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }); }
  catch { return ""; }
};

export default function MyPurchases() {
  const me = useMe();
  const bookings = useWorkflow((s) => s.bookings);
  const mails = useWorkflow((s) => s.mails);
  const markMailsRead = useWorkflow((s) => s.markMailsRead);
  const mine = bookings.filter((b) => b.buyerId === me?.id);
  const myMails = mails.filter((m) => m.toId === me?.id);

  useEffect(() => { if (me?.id) markMailsRead(me.id); }, [me?.id, markMailsRead]);

  return (
    <>
      <PageHead title="My Purchases" subtitle="Track your reserved cars from finance to delivery — and every email we send you along the way."
        right={<Link to="/market" className="chip"><Store size={13} /> Browse more</Link>} />

      {mine.length === 0 ? (
        <Card className="text-muted">
          You haven't reserved a car yet. <Link to="/market" className="text-violet-400">Head to the Marketplace →</Link>
        </Card>
      ) : (
        <div className="grid gap-6 lg:grid-cols-3">
          {/* bookings */}
          <div className="space-y-4 lg:col-span-2">
            {mine.map((b, i) => {
              const stage = SALE_STAGES[b.stageIdx];
              const specs = fullSpecs(b.model, b.specs, b.year);
              return (
                <motion.div key={b.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} className="glass overflow-hidden">
                  <div className="flex flex-col sm:flex-row">
                    <div className="h-40 w-full shrink-0 overflow-hidden sm:h-auto sm:w-48">
                      <CarImage model={b.model} images={b.images} className="h-full w-full object-cover" />
                    </div>
                    <div className="flex-1 p-5">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <div className="font-display text-lg font-semibold text-ink">{b.model}</div>
                          <div className="num-grad font-display text-xl font-semibold tracking-tight">{inr(b.retailPrice)}</div>
                        </div>
                        {b.closed
                          ? <span className="chip" style={{ color: "#22C55E", borderColor: "#22C55E55" }}><CheckCircle2 size={13} /> Delivered 🏁</span>
                          : <span className="chip" style={{ color: "#9B7CFF", borderColor: "#9B7CFF55" }}>{stage.icon} {stage.label}</span>}
                      </div>
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        <span className="chip"><Cog size={12} /> {specs.engine}</span>
                        <span className="chip"><Fuel size={12} /> {specs.fuel}</span>
                        <span className="chip"><BadgeCheck size={12} /> {specs.variant}</span>
                      </div>
                      <Track b={b} />
                      {!b.closed && (
                        <div className="mt-3 rounded-2xl bg-white/[.03] px-3 py-2 text-xs text-muted">
                          Our team is working on your car — next up: <b className="text-ink">{SALE_STAGES[Math.min(b.stageIdx + 1, SALE_STAGES.length - 1)].label}</b>.
                        </div>
                      )}
                      <div className="mt-3 space-y-1">
                        {b.timeline.map((t, j) => (
                          <div key={j} className="flex items-center gap-2 text-xs text-faint"><Clock size={11} /> {t.label}</div>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* order updates — email communication trail */}
          <div>
            <div className="mb-3 flex items-center gap-2 px-1 text-xs font-semibold uppercase tracking-[0.14em] text-faint">
              <Mail size={14} strokeWidth={1.75} className="text-violet-400" /> Order updates
            </div>
            {myMails.length === 0 ? (
              <Card className="text-sm text-muted">No emails yet — you'll get one at each step of your order.</Card>
            ) : (
              <div className="space-y-3">
                {myMails.map((m) => (
                  <motion.div key={m.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-3xl p-4">
                    <div className="flex items-start gap-2">
                      <span className="mt-1.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-violet/10 text-violet-400"><Mail size={14} strokeWidth={1.75} /></span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <div className="min-w-0 flex-1 truncate text-sm font-semibold text-ink">{m.subject}</div>
                          {!m.read && <span className="h-2 w-2 shrink-0 rounded-full bg-violet-400" title="Unread" />}
                        </div>
                        <p className="mt-1 text-xs leading-relaxed text-muted">{m.body}</p>
                        <div className="mt-1.5 text-[11px] text-faint">{fmtTime(m.at)}</div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      <div className="mt-8 lg:max-w-2xl"><SupportPanel me={me} /></div>
    </>
  );
}
