import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Gavel, Check, X, ShieldAlert, ShieldCheck, FileText, ZoomIn, Fuel, Gauge, Cog, Clock } from "lucide-react";
import { useStore, useMe } from "../store/useStore";
import { useWorkflow } from "../store/useWorkflow";
import { canPrice, DEAL_STATUS, inr } from "../lib/workflow";
import { fullSpecs } from "../lib/carimg";
import { confetti } from "../lib/confetti";
import Card from "../components/ui/Card";
import PageHead from "../components/ui/PageHead";
import CarImage from "../components/ui/CarImage";

let _tid = 0;

function DealCard({ d, me, delay, setZoom }) {
  const priceDeal = useWorkflow((s) => s.priceDeal);
  const rejectDeal = useWorkflow((s) => s.rejectDeal);
  const pushToast = useStore((s) => s.pushToast);
  const [price, setPrice] = useState(d.expected || "");
  const specs = fullSpecs(d.model, d.specs, d.year);
  const photos = d.images && d.images.length ? d.images : [null]; // null -> CarImage illustration

  const approve = (e) => {
    if (!price) return;
    priceDeal(d.id, Number(price), me);
    pushToast({ id: ++_tid, icon: "⚖️", label: "Deal priced — seller emailed", xp: 40, color: "#22C55E", name: me.name });
    const r = e.currentTarget.getBoundingClientRect(); confetti(r.left + r.width / 2, r.top, 40);
  };

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay }} className="glass p-4">
      {/* seller-submitted photos — the evidence PDI inspects */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {photos.map((src, i) => (
          <button key={i} onClick={() => setZoom(src || null, d)} className="relative h-24 w-32 shrink-0 overflow-hidden rounded-xl ring-1 ring-white/10">
            <CarImage model={d.model} images={src ? [src] : null} className="h-full w-full object-cover" />
            <span className="absolute bottom-1 right-1 rounded-md bg-black/50 p-1 text-white/90"><ZoomIn size={12} /></span>
          </button>
        ))}
      </div>

      <div className="mt-3 flex items-center gap-2">
        <span className="font-display font-semibold text-ink">{d.model}</span>
        <span className="chip" style={{ color: "#F59E0B", borderColor: "#F59E0B55" }}>{DEAL_STATUS[d.status].label}</span>
      </div>
      <div className="mt-1 text-sm text-muted">{d.customerName} · {d.year || "—"} · {d.km ? `${Number(d.km).toLocaleString()} km` : "—"}</div>
      <div className="mt-2 flex flex-wrap gap-1.5">
        <span className="chip"><Cog size={12} /> {specs.engine}</span>
        <span className="chip"><Fuel size={12} /> {specs.fuel}</span>
        <span className="chip"><Gauge size={12} /> {specs.transmission}</span>
        <span className="chip">{specs.variant}</span>
      </div>
      <div className="mt-2 text-sm">Customer asking: <b className="text-ink">{inr(d.expected)}</b></div>

      {canPrice(me) ? (
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <div className="flex items-center rounded-2xl border border-white/10 bg-white/5 px-3">
            <span className="text-muted">₹</span>
            <input value={price} onChange={(e) => setPrice(e.target.value)} placeholder="Set price" className="w-32 bg-transparent px-2 py-2.5 text-ink outline-none" />
          </div>
          <button onClick={approve} className="btn btn-primary !py-2.5"><Check size={15} /> Approve &amp; Price</button>
          <button onClick={() => rejectDeal(d.id, me)} className="btn btn-ghost !py-2.5"><X size={15} /> Reject</button>
        </div>
      ) : (
        <div className="mt-4 flex items-center gap-2 rounded-2xl bg-amber/10 px-3 py-2 text-sm text-amber">
          <ShieldAlert size={15} /> Only a supervisor can price deals. Log in as Supervisor to evaluate.
        </div>
      )}
    </motion.div>
  );
}

function DocReview({ d, me, setZoom }) {
  const verifyDoc = useWorkflow((s) => s.verifyDoc);
  return (
    <div className="glass flex gap-3 p-4">
      <button onClick={() => d.dataUrl && setZoom(d.dataUrl, d)} className="relative h-16 w-16 shrink-0 overflow-hidden rounded-xl ring-1 ring-white/10">
        {d.dataUrl
          ? <><img src={d.dataUrl} alt="" className="h-full w-full object-cover" /><span className="absolute bottom-0.5 right-0.5 rounded bg-black/50 p-0.5 text-white/90"><ZoomIn size={11} /></span></>
          : <div className="flex h-full w-full items-center justify-center bg-white/5"><FileText className="text-muted" /></div>}
      </button>
      <div className="min-w-0 flex-1">
        <div className="truncate text-sm font-semibold text-ink">{d.fileName}</div>
        <div className="truncate text-xs text-muted">{d.refLabel} · {d.step} · {d.entity === "deal" ? "Acquisition" : "Sale"}</div>
        <div className="text-xs text-faint">uploaded by {d.uploadedBy}</div>
        <div className="mt-2 flex gap-2">
          <button onClick={() => verifyDoc(d.id, true, me)} className="btn btn-primary !py-1.5 !px-3 text-xs"><Check size={13} /> Verify</button>
          <button onClick={() => verifyDoc(d.id, false, me)} className="btn btn-ghost !py-1.5 !px-3 text-xs"><X size={13} /> Reject</button>
        </div>
      </div>
    </div>
  );
}

export default function Evaluate() {
  const me = useMe();
  const deals = useWorkflow((s) => s.deals);
  const docs = useWorkflow((s) => s.docs);
  const [zoom, setZoomState] = useState(null); // { src, doc }
  const setZoom = (src, ref) => setZoomState(src ? { src, ref } : null);
  const pending = deals.filter((d) => d.status === "INSPECTED");
  const priced = deals.filter((d) => ["PRICED", "ACCEPTED", "ACQUIRED"].includes(d.status)).slice(0, 6);
  const pendingDocs = docs.filter((d) => d.status === "pending");
  const reviewedDocs = docs.filter((d) => d.status !== "pending").slice(0, 6);

  return (
    <>
      <PageHead title="Evaluation Queue" subtitle="Review seller photos, price inspected trade-ins, and verify the step documents your team uploads" right={<span className="chip"><Gavel size={13} /> {pending.length} pending</span>} />
      {pending.length === 0
        ? <Card className="text-muted">🎉 Queue is clear — no cars waiting for evaluation.</Card>
        : <div className="grid gap-4 lg:grid-cols-2">{pending.map((d, i) => <DealCard key={d.id} d={d} me={me} delay={i * 0.05} setZoom={setZoom} />)}</div>}

      {/* document verifications — legit review of the actual uploads */}
      <h3 className="mb-3 mt-10 flex items-center gap-2 font-display font-semibold text-ink">
        <ShieldCheck size={17} strokeWidth={1.75} className="text-cyan" /> Document verifications
        <span className="text-sm font-normal text-muted">({pendingDocs.length} pending)</span>
      </h3>
      {!me?.supervisor ? (
        <Card className="flex items-center gap-2 text-sm text-amber"><ShieldAlert size={15} /> Only a supervisor can verify step documents. Log in as Supervisor to review uploads.</Card>
      ) : pendingDocs.length === 0 ? (
        <Card className="text-sm text-muted">No documents awaiting verification. Employees upload proof for each step in the Pipeline; open a document to inspect it, then Verify or Reject.</Card>
      ) : (
        <div className="grid gap-3 lg:grid-cols-2">{pendingDocs.map((d) => <DocReview key={d.id} d={d} me={me} setZoom={setZoom} />)}</div>
      )}
      {me?.supervisor && reviewedDocs.length > 0 && (
        <div className="mt-4 space-y-2">
          {reviewedDocs.map((d) => {
            const ok = d.status === "verified"; const c = ok ? "#22C55E" : "#F43F5E";
            return (
              <div key={d.id} className="glass flex items-center justify-between gap-3 px-4 py-2.5 text-sm">
                <span className="min-w-0 truncate text-ink">{d.fileName} <span className="text-muted">· {d.refLabel} · {d.step}</span></span>
                <span className="flex items-center gap-2 shrink-0">
                  {d.verifiedAt && <span className="flex items-center gap-1 text-xs text-faint"><Clock size={11} /> {new Date(d.verifiedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>}
                  <span className="chip" style={{ color: c, borderColor: `${c}55` }}>{ok ? "Verified ✓" : "Rejected"} · {d.verifiedBy}</span>
                </span>
              </div>
            );
          })}
        </div>
      )}

      {priced.length > 0 && (
        <>
          <h3 className="mb-3 mt-10 font-display font-semibold text-ink">Recently priced</h3>
          <div className="space-y-2">
            {priced.map((d) => (
              <div key={d.id} className="glass flex items-center justify-between px-4 py-3">
                <div className="text-sm text-ink">{d.model} <span className="text-muted">· {d.customerName}</span></div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-semibold text-good">{inr(d.quotedPrice)}</span>
                  <span className="chip" style={{ color: DEAL_STATUS[d.status].color, borderColor: `${DEAL_STATUS[d.status].color}55` }}>{DEAL_STATUS[d.status].label}</span>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {/* lightbox */}
      <AnimatePresence>
        {zoom && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 p-6 backdrop-blur-sm" onClick={() => setZoom(null)}>
            <motion.div initial={{ scale: 0.94 }} animate={{ scale: 1 }} className="max-h-[85vh] max-w-3xl overflow-hidden rounded-3xl ring-1 ring-white/15" onClick={(e) => e.stopPropagation()}>
              <CarImage model={zoom.ref?.model || zoom.ref?.refLabel} images={[zoom.src]} className="max-h-[85vh] w-auto object-contain" />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
