import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { ChevronRight, Lock, CheckCircle2, Search, Gavel, Wallet, Store, Tag, Upload, FileText, Paperclip } from "lucide-react";
import { useStore, useMe } from "../store/useStore";
import { useWorkflow } from "../store/useWorkflow";
import { SALE_STAGES, nextSaleStage, canInspect, canOffer, canPayout, canSetRetail, canAdvanceSale, DEAL_STATUS, inr } from "../lib/workflow";
import { confetti } from "../lib/confetti";
import Card from "../components/ui/Card";
import PageHead from "../components/ui/PageHead";
import CarImage from "../components/ui/CarImage";

let _tid = 0;
const pop = (e, n = 40) => { const r = e.currentTarget.getBoundingClientRect(); confetti(r.left + r.width / 2, r.top, n); };

const DOC_STATUS = {
  pending:  { c: "#F59E0B", t: "Pending review" },
  verified: { c: "#22C55E", t: "Verified ✓" },
  rejected: { c: "#F43F5E", t: "Rejected" },
};

/* Per-step document upload by the employee; verified later by a supervisor. */
function StepDocs({ entity, refId, refLabel, step, me }) {
  const docs = useWorkflow((s) => s.docs);
  const attachDoc = useWorkflow((s) => s.attachDoc);
  const pushToast = useStore((s) => s.pushToast);
  const inputRef = useRef();
  const mine = docs.filter((d) => d.entity === entity && d.refId === refId);

  const onFile = (e) => {
    const file = e.target.files?.[0]; if (!file) return;
    const finish = (dataUrl) => {
      attachDoc({ entity, refId, refLabel, step, fileName: file.name, fileType: file.type, dataUrl, actor: me });
      pushToast({ id: ++_tid, icon: "📎", label: "Document uploaded — awaiting supervisor", xp: 0, color: "#38BDF8", name: me.name });
    };
    if (file.type.startsWith("image/") && file.size <= 700000) {
      const rd = new FileReader(); rd.onload = () => finish(rd.result); rd.readAsDataURL(file);
    } else { finish(null); }  // store metadata only for large/non-image files
    e.target.value = "";
  };

  return (
    <div className="mt-3 rounded-2xl border border-white/6 bg-white/[.02] p-3">
      <div className="mb-2 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 text-xs font-medium text-muted"><Paperclip size={13} className="text-cyan" /> Step documents <span className="text-faint">· {step}</span></div>
        <button onClick={() => inputRef.current?.click()} className="btn btn-ghost !py-1 !px-3 text-xs"><Upload size={12} /> Upload</button>
        <input ref={inputRef} type="file" hidden onChange={onFile} />
      </div>
      {mine.length === 0 ? (
        <div className="text-xs text-faint">No documents yet — attach proof for this step; a supervisor will verify it.</div>
      ) : (
        <div className="space-y-1.5">
          {mine.map((d) => {
            const sm = DOC_STATUS[d.status];
            return (
              <div key={d.id} className="flex items-center gap-2 text-xs">
                <FileText size={13} className="shrink-0 text-muted" />
                <span className="min-w-0 flex-1 truncate text-ink">{d.fileName}</span>
                <span className="hidden shrink-0 text-faint sm:inline">{d.step}</span>
                <span className="chip shrink-0 !py-0.5" style={{ color: sm.c, borderColor: `${sm.c}55` }}>{sm.t}</span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ---------------- acquisition (sell-side) ---------------- */
function AcqCard({ d, me }) {
  const pushToast = useStore((s) => s.pushToast);
  const inspectDeal = useWorkflow((s) => s.inspectDeal);
  const priceDeal = useWorkflow((s) => s.priceDeal);
  const payoutSeller = useWorkflow((s) => s.payoutSeller);
  const [price, setPrice] = useState(d.expected || "");
  const st = DEAL_STATUS[d.status];

  const doInspect = (e) => { inspectDeal(d.id, me); pushToast({ id: ++_tid, icon: "🔍", label: "Car inspected", xp: 20, color: "#38BDF8", name: me.name }); pop(e); };
  const doOffer = (e) => { if (!price) return; priceDeal(d.id, Number(price), me); pushToast({ id: ++_tid, icon: "⚖️", label: "Offer made", xp: 40, color: "#3B82F6", name: me.name }); pop(e); };
  const doPayout = (e) => { payoutSeller(d.id, me); pushToast({ id: ++_tid, icon: "💰", label: "Acquired into inventory", xp: 50, color: "#22C55E", name: me.name }); pop(e, 50); };

  return (
    <div className="glass p-4">
      <div className="mb-3 h-28 w-full overflow-hidden rounded-xl ring-1 ring-white/8">
        <CarImage model={d.model} images={d.images} className="h-full w-full object-cover" />
      </div>
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0">
          <div className="truncate font-display font-bold text-ink">{d.model}</div>
          <div className="text-xs text-muted">{d.customerName} · {d.year || "—"} · {d.km ? `${Number(d.km).toLocaleString()} km` : "—"} · asks {inr(d.expected)}</div>
        </div>
        <span className="chip shrink-0" style={{ color: st.color, borderColor: `${st.color}55` }}>{st.label}</span>
      </div>

      {d.status === "PENDING" && (canInspect(me)
        ? <button onClick={doInspect} className="btn btn-primary mt-3 !py-2"><Search size={15} /> Inspect car <span className="text-white/70">+20</span></button>
        : <Await owner="PDI" verb="inspect" />)}

      {d.status === "INSPECTED" && (canOffer(me)
        ? <div className="mt-3 flex flex-wrap items-center gap-2">
            <div className="flex items-center rounded-xl border border-white/10 bg-white/5 px-3"><span className="text-muted">₹</span>
              <input value={price} onChange={(e) => setPrice(e.target.value)} placeholder="Offer" className="w-28 bg-transparent px-2 py-2 text-ink outline-none" /></div>
            <button onClick={doOffer} className="btn btn-primary !py-2"><Gavel size={15} /> Make offer <span className="text-white/70">+40</span></button>
          </div>
        : <Await owner="Sales" verb="make an offer" />)}

      {d.status === "PRICED" && (
        <div className="mt-3 rounded-xl bg-blue-500/10 px-3 py-2 text-sm text-blue-300">
          Offered <b>{inr(d.quotedPrice)}</b> · awaiting {d.customerName}'s acceptance.
        </div>
      )}

      {d.status === "ACCEPTED" && (canPayout(me)
        ? <button onClick={doPayout} className="btn btn-primary mt-3 !py-2"><Wallet size={15} /> Pay out {inr(d.quotedPrice)} & acquire <span className="text-white/70">+50</span></button>
        : <Await owner="Accounts" verb="pay out & acquire" />)}

      <StepDocs entity="deal" refId={d.id} refLabel={d.model} step={st.label} me={me} />
    </div>
  );
}

function Await({ owner, verb }) {
  return <div className="mt-3 inline-flex items-center gap-2 rounded-xl bg-white/5 px-3 py-2 text-sm text-muted"><Lock size={14} /> Awaiting <b className="text-ink">{owner}</b> to {verb}</div>;
}

/* ---------------- inventory (re-pricing) ---------------- */
function InvRow({ it, me }) {
  const setRetail = useWorkflow((s) => s.setRetail);
  const pushToast = useStore((s) => s.pushToast);
  const [price, setPrice] = useState(it.retailPrice);
  const [editing, setEditing] = useState(false);
  const save = () => { setRetail(it.id, price, me); setEditing(false); pushToast({ id: ++_tid, icon: "🏷️", label: "Retail re-priced", xp: 10, color: "#F59E0B", name: me.name }); };

  return (
    <div className="glass flex items-center justify-between gap-3 px-4 py-3">
      <div className="min-w-0">
        <div className="truncate text-sm font-semibold text-ink">{it.model} <span className="text-xs font-normal text-faint">· {it.year || "—"}</span></div>
        <div className="text-xs text-muted">acq {inr(it.acquisitionPrice)} + recon {inr(it.reconditioning)} · margin baked in</div>
      </div>
      {editing && canSetRetail(me) ? (
        <div className="flex items-center gap-2">
          <div className="flex items-center rounded-lg border border-white/10 bg-white/5 px-2"><span className="text-muted">₹</span>
            <input value={price} onChange={(e) => setPrice(e.target.value)} className="w-24 bg-transparent px-1 py-1.5 text-ink outline-none" /></div>
          <button onClick={save} className="btn btn-primary !py-1.5 !px-3 text-xs">Save</button>
        </div>
      ) : (
        <div className="flex items-center gap-2">
          <span className="font-display font-bold text-good">{inr(it.retailPrice)}</span>
          {canSetRetail(me) && <button onClick={() => setEditing(true)} className="text-muted hover:text-ink" title="Re-price"><Tag size={15} /></button>}
        </div>
      )}
    </div>
  );
}

/* ---------------- sale fulfillment (buy-side) ---------------- */
function SaleCard({ b, me }) {
  const pushToast = useStore((s) => s.pushToast);
  const advanceSale = useWorkflow((s) => s.advanceSale);
  const next = nextSaleStage(b);
  const allowed = canAdvanceSale(me, b);
  const advance = (e) => { const n = advanceSale(b.id, me); if (n) { pushToast({ id: ++_tid, icon: n.icon, label: n.label, xp: n.xp, color: "#22C55E", name: me.name }); pop(e); } };

  return (
    <div className="glass p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="font-display font-bold text-ink">{b.model}</div>
          <div className="text-xs text-muted">{inr(b.retailPrice)} · buyer {b.buyerName}</div>
        </div>
        <span className="chip" style={{ color: "#9B7CFF", borderColor: "#9B7CFF55" }}>{SALE_STAGES[b.stageIdx].label}</span>
      </div>
      <div className="mt-3 flex items-center gap-1 overflow-x-auto pb-1">
        {SALE_STAGES.map((s, idx) => (
          <div key={s.key} className="flex items-center">
            <div title={s.label} className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-sm ring-1 ${idx <= b.stageIdx ? "bg-violet/25 ring-violet/60" : "bg-white/5 ring-white/10 opacity-50"} ${idx === b.stageIdx && !b.closed ? "ring-2 ring-violet shadow-glow" : ""}`}>{s.icon}</div>
            {idx < SALE_STAGES.length - 1 && <div className={`h-0.5 w-4 ${idx < b.stageIdx ? "bg-violet/60" : "bg-white/10"}`} />}
          </div>
        ))}
      </div>
      {next && (
        <div className="mt-3">
          {allowed
            ? <button onClick={advance} className="btn btn-primary !py-2">{next.icon} Mark "{next.label}" <ChevronRight size={15} /> <span className="text-white/70">+{next.xp}</span></button>
            : <Await owner={next.owner === "RTO / REGN TEAM" ? "RTO / Regn" : next.owner.charAt(0) + next.owner.slice(1).toLowerCase()} verb={`mark "${next.label}"`} />}
        </div>
      )}

      <StepDocs entity="sale" refId={b.id} refLabel={b.model} step={SALE_STAGES[b.stageIdx].label} me={me} />
    </div>
  );
}

export default function Pipeline() {
  const me = useMe();
  const deals = useWorkflow((s) => s.deals);
  const inventory = useWorkflow((s) => s.inventory);
  const bookings = useWorkflow((s) => s.bookings);

  const funnel = deals.filter((d) => d.status !== "ACQUIRED" && d.status !== "REJECTED");
  const listed = inventory.filter((it) => it.status === "LISTED");
  const activeSales = bookings.filter((b) => !b.closed);
  const delivered = bookings.filter((b) => b.closed);

  return (
    <>
      <PageHead title="Operations" subtitle="Acquire trade-ins, list them, and fulfil buyer orders to delivery — every step earns your department XP"
        right={<span className="chip">{me?.supervisor ? "⭐ Supervisor — any stage" : `Acting as ${me?.dept}`}</span>} />

      {/* acquisition funnel */}
      <h3 className="mb-2 font-display font-semibold text-ink">🔻 Acquisition funnel <span className="text-sm font-normal text-muted">({funnel.length})</span></h3>
      {funnel.length === 0
        ? <Card className="mb-6 text-sm text-muted">No trade-ins in the funnel. Customers submit cars from the seller portal.</Card>
        : <div className="mb-6 grid gap-3 lg:grid-cols-2">{funnel.map((d) => <AcqCard key={d.id} d={d} me={me} />)}</div>}

      {/* inventory */}
      <h3 className="mb-2 font-display font-semibold text-ink flex items-center gap-2"><Store size={16} /> Live inventory <span className="text-sm font-normal text-muted">({listed.length} listed)</span></h3>
      {listed.length === 0
        ? <Card className="mb-6 text-sm text-muted">Nothing listed yet — acquire a trade-in to stock the marketplace.</Card>
        : <div className="mb-6 space-y-2">{listed.map((it) => <InvRow key={it.id} it={it} me={me} />)}</div>}

      {/* sale fulfillment */}
      <h3 className="mb-2 font-display font-semibold text-ink">🏁 Buyer orders in fulfilment <span className="text-sm font-normal text-muted">({activeSales.length})</span></h3>
      {activeSales.length === 0
        ? <Card className="text-sm text-muted">No active buyer orders. When a buyer reserves a car it appears here for your department to action.</Card>
        : <div className="space-y-3">{activeSales.map((b) => <SaleCard key={b.id} b={b} me={me} />)}</div>}

      {delivered.length > 0 && (
        <>
          <h3 className="mb-2 mt-8 font-display font-semibold text-ink">Delivered <span className="text-sm font-normal text-muted">({delivered.length})</span></h3>
          <div className="space-y-2">
            {delivered.map((b) => (
              <div key={b.id} className="glass flex items-center justify-between px-4 py-3">
                <div className="flex items-center gap-2 text-sm text-ink"><CheckCircle2 size={16} className="text-good" /> {b.model} <span className="text-muted">· {b.buyerName}</span></div>
                <span className="chip" style={{ color: "#22C55E", borderColor: "#22C55E55" }}>🏁 Delivered · {inr(b.retailPrice)}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </>
  );
}
