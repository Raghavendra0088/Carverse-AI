import { useStore, useMe } from "../store/useStore";
import Card from "../components/ui/Card";
import PageHead from "../components/ui/PageHead";
import { BadgePill } from "../components/ui/Badge";

const CATALOG = [
  { id: "first_booking", name: "First Booking", icon: "🏅", desc: "Create your first booking", purpose: "Every sale starts with a booking — this marks your first real milestone." },
  { id: "century", name: "Centurion", icon: "💯", desc: "Log 100 milestones", purpose: "Consistent milestone output is the backbone of dealership throughput." },
  { id: "team", name: "Team Player", icon: "🤝", desc: "Earn 10 team bonuses", purpose: "Rewards the cross-department teamwork that actually delivers cars." },
  { id: "sharp", name: "Sharpshooter", icon: "🎯", desc: "Approve 25 discounts", purpose: "Fast, decisive pricing approvals keep deals from stalling." },
  { id: "fast_appr", name: "Fast Approver", icon: "⚡", desc: "Clear 20 finances", purpose: "Quick finance clearances are the #1 unblock for deliveries." },
  { id: "streak7", name: "7-Day Streak", icon: "🔥", desc: "Stay active 7 days straight", purpose: "Daily consistency compounds into long-term performance." },
  { id: "closer", name: "Deal Closer", icon: "🤝", desc: "Reach Deal Closer rank", purpose: "Proves sustained, closing-focused sales impact." },
  { id: "fin_hero", name: "Finance Hero", icon: "💰", desc: "Reach Finance Hero rank", purpose: "Reflects mastery of loan throughput and clean processing." },
  { id: "legend", name: "Legend", icon: "👑", desc: "Reach the top rank", purpose: "The top rank — sustained, category-leading contribution to the dealership." },
];

export default function Achievements() {
  const me = useMe();
  if (!me) return null;
  const earned = new Set(me.badges.map((b) => b.id));

  return (
    <>
      <PageHead title="Achievements" subtitle={`${earned.size} of ${CATALOG.length} badges unlocked · each badge rewards a real performance behaviour`} />
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {CATALOG.map((b) => {
          const has = earned.has(b.id);
          return (
            <Card key={b.id} hover className="flex flex-col items-center text-center">
              <BadgePill badge={b} locked={!has} />
              <div className={`mt-3 text-sm font-semibold ${has ? "text-good" : "text-faint"}`}>{has ? "Unlocked" : "Locked"}</div>
              <p className="mt-1 text-xs font-medium text-muted">{b.desc}</p>
              <p className="mt-2 border-t border-white/6 pt-2 text-xs leading-relaxed text-faint">
                <span className="font-medium text-muted">Purpose:</span> {b.purpose}
              </p>
            </Card>
          );
        })}
      </div>
    </>
  );
}
