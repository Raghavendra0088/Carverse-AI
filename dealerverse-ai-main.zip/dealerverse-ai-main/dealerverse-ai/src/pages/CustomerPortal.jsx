import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Car, Upload, Plus, Clock, Mail, CheckCircle2, Cog, Fuel, Gauge } from "lucide-react";
import { useStore, useMe } from "../store/useStore";
import { useWorkflow } from "../store/useWorkflow";
import { carModels } from "../data/db";
import { DEAL_STATUS, inr } from "../lib/workflow";
import { confetti } from "../lib/confetti";
import Card from "../components/ui/Card";
import PageHead from "../components/ui/PageHead";
import CarImage from "../components/ui/CarImage";
import SupportPanel from "../components/ui/SupportPanel";

let _tid = 0;
const BLANK = { model: "", year: "", km: "", expected: "", variant: "", engine: "", fuel: "", transmission: "", color: "", owners: "" };
const fmtTime = (iso) => { try { return new Date(iso).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }); } catch { return ""; } };

export default function CustomerPortal() {
  const me = useMe();
  const pushToast = useStore((s) => s.pushToast);
  const submitDeal = useWorkflow((s) => s.submitDeal);
  const acceptOffer = useWorkflow((s) => s.acceptOffer);
  const markMailsRead = useWorkflow((s) => s.markMailsRead);
  const deals = useWorkflow((s) => s.deals);
  const mails = useWorkflow((s) => s.mails);
  const mine = deals.filter((d) => d.customerId === me?.id);
  const myMails = mails.filter((m) => m.toId === me?.id);

  const [f, setF] = useState(BLANK);
  const [images, setImages] = useState([]);
  const [sent, setSent] = useState(false);

  // snapshot unread at open, then mark read (so unread dots reflect what was new)
  const [unread, setUnread] = useState(new Set());
  useEffect(() => {
    if (!me?.id) return;
    const ids = new Set(useWorkflow.getState().mails.filter((m) => m.toId === me.id && !m.read).map((m) => m.id));
    setUnread(ids);
    markMailsRead(me.id);
  }, [me?.id, markMailsRead]);

  const onFiles = async (e) => {
    const files = [...e.target.files].slice(0, 4);
    const urls = await Promise.all(files.map((file) => new Promise((res) => {
      const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(file);
    })));
    setImages(urls);
  };

  const submit = (e) => {
    e.preventDefault();
    if (!f.model) return;
    submitDeal({
      customerId: me.id, customerName: me.name, model: f.model, year: f.year, km: f.km,
      expected: Number(f.expected) || 0, images,
      specs: { variant: f.variant, engine: f.engine, fuel: f.fuel, transmission: f.transmission, color: f.color, owners: f.owners },
    });
    pushToast({ id: ++_tid, icon: "🚗", label: "Request sent — check your email", xp: 0, color: "#7C5CFF", name: me.name });
    confetti(innerWidth / 2, 200, 50);
    setF(BLANK); setImages([]); setSent(true);
    setTimeout(() => setSent(false), 6000);
  };

  const FUELS = ["Petrol", "Diesel", "CNG", "Hybrid", "Electric"];

  return (
    <>
      <PageHead title={`Hi ${me?.name?.split(" ")[0]}.`} subtitle="Post a car you want to sell — add its details and photos. Our team inspects it, emails you an offer, and keeps you posted at every step." />

      <div className="grid gap-6 lg:grid-cols-2">
        {/* new deal form */}
        <Card>
          <div className="mb-5 flex items-center gap-2"><Car size={18} strokeWidth={1.75} className="text-violet-400" /><h3 className="font-display text-lg font-semibold text-ink">List a car for sale</h3></div>

          {sent && (
            <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }}
              className="mb-4 flex items-center gap-2 rounded-2xl border border-good/25 bg-good/10 px-4 py-3 text-sm text-good">
              <CheckCircle2 size={16} /> Request sent ✓ — we've emailed a confirmation and our team will evaluate it shortly.
            </motion.div>
          )}

          <form onSubmit={submit} className="space-y-3">
            <div>
              <label className="mb-1.5 block text-xs font-medium text-muted">Car model</label>
              <input list="models" value={f.model} onChange={(e) => setF({ ...f, model: e.target.value })} placeholder="e.g. Hyundai Creta" className="field" required />
              <datalist id="models">{carModels.map((m) => <option key={m} value={m} />)}</datalist>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div><label className="mb-1.5 block text-xs font-medium text-muted">Year</label><input value={f.year} onChange={(e) => setF({ ...f, year: e.target.value })} placeholder="2021" className="field" /></div>
              <div><label className="mb-1.5 block text-xs font-medium text-muted">KM driven</label><input value={f.km} onChange={(e) => setF({ ...f, km: e.target.value })} placeholder="35000" className="field" /></div>
              <div><label className="mb-1.5 block text-xs font-medium text-muted">Expected ₹</label><input value={f.expected} onChange={(e) => setF({ ...f, expected: e.target.value })} placeholder="900000" className="field" /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="mb-1.5 block text-xs font-medium text-muted">Variant</label><input value={f.variant} onChange={(e) => setF({ ...f, variant: e.target.value })} placeholder="SX(O)" className="field" /></div>
              <div><label className="mb-1.5 block text-xs font-medium text-muted">Engine</label><input value={f.engine} onChange={(e) => setF({ ...f, engine: e.target.value })} placeholder="1497 cc" className="field" /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1.5 block text-xs font-medium text-muted">Fuel</label>
                <select value={f.fuel} onChange={(e) => setF({ ...f, fuel: e.target.value })} className="field appearance-none">
                  <option value="" className="bg-surface">Select fuel</option>
                  {FUELS.map((x) => <option key={x} value={x} className="bg-surface">{x}</option>)}
                </select>
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium text-muted">Transmission</label>
                <select value={f.transmission} onChange={(e) => setF({ ...f, transmission: e.target.value })} className="field appearance-none">
                  <option value="" className="bg-surface">Select</option>
                  <option value="Manual" className="bg-surface">Manual</option>
                  <option value="Automatic" className="bg-surface">Automatic</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="mb-1.5 block text-xs font-medium text-muted">Colour</label><input value={f.color} onChange={(e) => setF({ ...f, color: e.target.value })} placeholder="Pearl White" className="field" /></div>
              <div><label className="mb-1.5 block text-xs font-medium text-muted">Previous owners</label><input type="number" min="1" value={f.owners} onChange={(e) => setF({ ...f, owners: e.target.value })} placeholder="1" className="field" /></div>
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-medium text-muted">Photos (up to 4)</label>
              <label className="flex cursor-pointer items-center justify-center gap-2 rounded-2xl border border-dashed border-white/15 bg-white/[.03] py-4 text-sm text-muted transition hover:border-violet/50">
                <Upload size={16} strokeWidth={1.75} /> {images.length ? `${images.length} photo(s) selected` : "Upload car photos"}
                <input type="file" accept="image/*" multiple className="hidden" onChange={onFiles} />
              </label>
              {images.length > 0 && (
                <div className="mt-2 flex gap-2">{images.map((src, i) => <img key={i} src={src} alt="" className="h-16 w-16 rounded-xl object-cover ring-1 ring-white/10" />)}</div>
              )}
            </div>
            <button type="submit" className="btn btn-primary w-full"><Plus size={16} /> Send sell request</button>
          </form>
        </Card>

        {/* your deals */}
        <div>
          <h3 className="mb-3 font-display text-lg font-semibold text-ink">Your deals ({mine.length})</h3>
          <div className="space-y-3">
            {mine.length === 0 && <Card className="text-sm text-muted">No deals yet — list your first car on the left.</Card>}
            {mine.map((d, i) => {
              const st = DEAL_STATUS[d.status];
              const sp = d.specs || {};
              return (
                <motion.div key={d.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} className="glass p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex gap-3">
                      <div className="h-16 w-20 shrink-0 overflow-hidden rounded-xl ring-1 ring-white/10">
                        <CarImage model={d.model} images={d.images} className="h-full w-full object-cover" />
                      </div>
                      <div>
                        <div className="font-semibold text-ink">{d.model}</div>
                        <div className="text-xs text-muted">{d.year || "—"} · asking {inr(d.expected)}</div>
                        <div className="mt-1.5 flex flex-wrap gap-1.5">
                          {sp.variant && <span className="chip !py-0.5 text-[11px]">{sp.variant}</span>}
                          {sp.fuel && <span className="chip !py-0.5 text-[11px]"><Fuel size={11} /> {sp.fuel}</span>}
                          {sp.transmission && <span className="chip !py-0.5 text-[11px]"><Cog size={11} /> {sp.transmission}</span>}
                          {d.km && <span className="chip !py-0.5 text-[11px]"><Gauge size={11} /> {Number(d.km).toLocaleString()} km</span>}
                        </div>
                      </div>
                    </div>
                    <span className="chip shrink-0" style={{ color: st.color, borderColor: `${st.color}55` }}>{st.label}</span>
                  </div>
                  {d.quotedPrice != null && (
                    <div className="mt-3 rounded-2xl bg-good/10 px-3 py-2 text-sm text-good ring-1 ring-good/20">
                      💰 Dealer offer: <b>{inr(d.quotedPrice)}</b> {d.evaluator && <span className="text-muted">· by {d.evaluator}</span>}
                    </div>
                  )}
                  {d.status === "PRICED" && (
                    <button onClick={() => { acceptOffer(d.id); pushToast({ id: ++_tid, icon: "🤝", label: "Offer accepted!", xp: 0, color: "#22C55E", name: me.name }); confetti(innerWidth / 2, 200, 50); }}
                      className="btn btn-primary mt-3 w-full !py-2">Accept offer of {inr(d.quotedPrice)}</button>
                  )}
                  {d.status === "ACCEPTED" && <div className="mt-3 text-xs text-amber">✓ Accepted — Accounts will process your payout shortly.</div>}
                  {d.status === "ACQUIRED" && <div className="mt-3 text-xs text-good">🎉 Sold to the dealership — payout complete.</div>}
                  <div className="mt-3 space-y-1">
                    {d.timeline.map((t, j) => (
                      <div key={j} className="flex items-center gap-2 text-xs text-faint"><Clock size={11} /> {t.label}</div>
                    ))}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="mt-8 lg:max-w-2xl"><SupportPanel me={me} /></div>

      {/* inbox — communication from the system, one email per step */}
      <h3 className="mb-3 mt-8 flex items-center gap-2 font-display text-lg font-semibold text-ink">
        <Mail size={18} strokeWidth={1.75} className="text-cyan" /> Emails from CarVerse
        {myMails.length > 0 && <span className="text-sm font-normal text-muted">({myMails.length})</span>}
      </h3>
      {myMails.length === 0 ? (
        <Card className="text-sm text-muted">No emails yet. Once you list a car, we'll email you at every step — confirmation, inspection, offer, and payout.</Card>
      ) : (
        <div className="grid gap-3 lg:grid-cols-2">
          {myMails.map((m, i) => (
            <motion.div key={m.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i, 8) * 0.04 }} className="glass p-4">
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-grad-vb text-white"><Mail size={16} strokeWidth={1.75} /></div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="truncate font-semibold text-ink">{m.subject}</span>
                    {unread.has(m.id) && <span className="h-2 w-2 shrink-0 rounded-full bg-violet-400" />}
                  </div>
                  <div className="mt-0.5 text-[11px] text-faint">CarVerse · to {m.to} · {fmtTime(m.at)}</div>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{m.body}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </>
  );
}
