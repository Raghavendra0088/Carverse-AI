import { BarChart, Bar, ResponsiveContainer, Tooltip, XAxis, Cell } from "recharts";
import { MapPin, UserCog, Flame, Users2 } from "lucide-react";
import { useStore, useMe } from "../store/useStore";
import { actionMeta, rankProgress, fmt, DEPT_COLOR } from "../lib/gamify";
import Card from "../components/ui/Card";
import PageHead from "../components/ui/PageHead";
import Avatar from "../components/ui/Avatar";
import RankRing from "../components/ui/RankRing";
import { BadgePill } from "../components/ui/Badge";

export default function Profile() {
  const me = useMe();
  const sessionXp = useStore((s) => s.sessionXp);
  if (!me) return null;
  const rp = rankProgress(me);
  const breakdown = Object.entries(me.actions || {})
    .map(([a, c]) => ({ name: actionMeta(a).label, count: c, color: actionMeta(a).color }))
    .sort((x, y) => y.count - x.count);

  return (
    <>
      <PageHead title="Employee Profile" subtitle="Your full DealerVerse card" />

      <Card className="mb-5 flex flex-col items-center gap-6 sm:flex-row">
        <RankRing pct={rp.pct} size={120}>
          <div className="text-[10px] uppercase tracking-widest text-muted">Lvl {me.rankIdx + 1}</div>
          <div className="px-2 text-center font-display text-sm font-bold text-ink">{me.rank}</div>
        </RankRing>
        <div className="flex flex-1 flex-col items-center gap-2 sm:items-start">
          <Avatar name={me.name} size={54} ring />
          <div className="text-center sm:text-left">
            <div className="font-display text-2xl font-bold text-ink">{me.name}</div>
            <div className="text-sm text-muted">{me.designation || me.dept}</div>
          </div>
          <div className="mt-1 flex flex-wrap justify-center gap-2 sm:justify-start">
            <span className="chip"><MapPin size={12} /> {me.locName}</span>
            <span className="chip"><UserCog size={12} /> Mgr: {me.manager || "—"}</span>
            <span className="chip" style={{ color: DEPT_COLOR[me.dept], borderColor: `${DEPT_COLOR[me.dept]}55` }}>{me.dept}</span>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-3 text-center sm:grid-cols-1 sm:gap-2">
          <div><div className="font-display text-xl font-bold grad-text">{fmt(me.xp + sessionXp)}</div><div className="text-xs text-muted">XP</div></div>
          <div><div className="font-display text-xl font-bold text-amber flex items-center justify-center gap-1"><Flame size={16} />{me.streak}</div><div className="text-xs text-muted">streak</div></div>
          <div><div className="font-display text-xl font-bold text-good flex items-center justify-center gap-1"><Users2 size={16} />{me.collab}</div><div className="text-xs text-muted">team-ups</div></div>
        </div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <h3 className="mb-3 font-display font-semibold text-ink">Milestone breakdown</h3>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={breakdown} margin={{ left: 0, right: 8, top: 8 }}>
                <XAxis dataKey="name" tick={{ fill: "#5B6080", fontSize: 10 }} axisLine={false} tickLine={false} interval={0} angle={-12} height={40} />
                <Tooltip cursor={{ fill: "rgba(255,255,255,.04)" }} contentStyle={{ background: "#12131F", border: "1px solid rgba(255,255,255,.1)", borderRadius: 12, color: "#E8EAF6" }} />
                <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                  {breakdown.map((b, i) => <Cell key={i} fill={b.color} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card>
          <h3 className="mb-3 font-display font-semibold text-ink">Badges ({me.badges.length})</h3>
          <div className="grid grid-cols-3 gap-2">
            {me.badges.map((b) => <BadgePill key={b.id} badge={b} />)}
          </div>
        </Card>
      </div>

      <Card className="mt-4">
        <h3 className="mb-3 font-display font-semibold text-ink">Recent milestones</h3>
        <div className="grid gap-2 sm:grid-cols-2">
          {(me.recent || []).slice(0, 8).map((r, i) => {
            const m = actionMeta(r.action);
            return (
              <div key={i} className="flex items-center gap-3 rounded-xl bg-white/[.03] px-3 py-2">
                <span className="text-lg">{m.icon}</span>
                <div className="min-w-0 flex-1"><div className="truncate text-sm text-ink">{m.label}</div>
                  <div className="text-xs text-faint">{r.ts.slice(0, 10)}</div></div>
                <span className="font-display font-bold" style={{ color: m.color }}>+{r.xp}</span>
              </div>
            );
          })}
        </div>
      </Card>
    </>
  );
}
