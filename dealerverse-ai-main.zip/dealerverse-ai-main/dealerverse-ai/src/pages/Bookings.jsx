import { useState } from "react";
import { motion } from "framer-motion";
import { ChevronRight, Lock, CheckCircle2, Plus, Car, Flag } from "lucide-react";
import { useStore, useMe } from "../store/useStore";
import { useWorkflow } from "../store/useWorkflow";
import { BOOKING_STAGES, BOOKING_LAST, nextBookingStage, canOpenBooking, canAdvanceBooking, ownerLabel } from "../lib/workflow";
import { deptLabel } from "../lib/gamify";
import { carModels } from "../data/db";
import { confetti } from "../lib/confetti";
import Card from "../components/ui/Card";
import PageHead from "../components/ui/PageHead";

let _tid = 0;
const pop = (e, n = 40) => { const r = e.currentTarget.getBoundingClientRect(); confetti(r.left + r.width / 2, r.top, n); };

function Stepper({ b }) {
  return (
    <div className="mt-3 flex items-center gap-1 overflow-x-auto pb-1">
      {BOOKING_STAGES.map((s, idx) => {
        const done = idx <= b.stageIdx;
        const cur = idx === b.stageIdx + 1 && !b.closed;
        return (
          <div key={s.key} className="flex items-center">
            <div title={`${s.label} · ${ownerLabel(s.owner)}`}
              className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-sm ring-1 ${
                done ? "bg-violet/25 ring-violet/60" : "bg-white/5 ring-white/10 opacity-50"} ${cur ? "ring-2 ring-violet shadow-glow" : ""}`}>
              {s.icon}
            </div>
            {idx < BOOKING_LAST && <div className={`h-0.5 w-3 ${idx <= b.stageIdx ? "bg-violet/60" : "bg-white/10"}`} />}
          </div>
        );
      })}
    </div>
  );
}

function BookingCard({ b, me, delay }) {
  const advanceBooking = useWorkflow((s) => s.advanceBooking);
  const cancelBooking = useWorkflow((s) => s.cancelBooking);
  const pushToast = useStore((s) => s.pushToast);
  const next = nextBookingStage(b);
  const allowed = canAdvanceBooking(me, b);
  const current = BOOKING_STAGES[b.stageIdx];

  const advance = (e) => {
    const n = advanceBooking(b.id, me);
    if (n) { pushToast({ id: ++_tid, icon: n.icon, label: n.label, xp: n.xp, color: "#22C55E", name: me.name }); pop(e, n.key === "GATEPASS" || n.key === "DELIVERED" ? 60 : 40); }
  };

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay }}
      className={`glass p-5 ${allowed ? "ring-1 ring-violet/40" : ""}`}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/[.05] text-lg">🚗</span>
          <div>
            <div className="font-display font-semibold text-ink">{b.model}</div>
            <div className="text-xs text-muted">for {b.customer} · opened by {b.createdBy}</div>
          </div>
        </div>
        {b.closed
          ? <span className="chip" style={{ color: b.cancelled ? "#F43F5E" : "#22C55E", borderColor: (b.cancelled ? "#F43F5E" : "#22C55E") + "55" }}>{b.cancelled ? "Cancelled" : <><Flag size={12} /> Delivered 🏁</>}</span>
          : <span className="chip" style={{ color: "#9B7CFF", borderColor: "#9B7CFF55" }}>{current.icon} {current.label}</span>}
      </div>

      <Stepper b={b} />

      {next && !b.closed && (
        <div className="mt-3 flex flex-wrap items-center gap-2">
          {allowed
            ? <button onClick={advance} className="btn btn-primary !py-2">{next.icon} {next.label} <ChevronRight size={15} /> <span className="text-white/70">+{next.xp}</span></button>
            : <div className="inline-flex items-center gap-2 rounded-2xl bg-white/[.04] px-3 py-2 text-sm text-muted">
                <Lock size={14} /> Awaiting <b className="text-ink">{ownerLabel(next.owner)}</b> to {next.verb}
              </div>}
          {me?.supervisor && <button onClick={() => cancelBooking(b.id, me)} className="text-xs text-faint transition hover:text-bad">Cancel</button>}
        </div>
      )}
    </motion.div>
  );
}

export default function Bookings() {
  const me = useMe();
  const carBookings = useWorkflow((s) => s.carBookings);
  const openBooking = useWorkflow((s) => s.openBooking);
  const pushToast = useStore((s) => s.pushToast);
  const [f, setF] = useState({ customer: "", model: "" });

  const active = carBookings.filter((b) => !b.closed);
  const closed = carBookings.filter((b) => b.closed);
  const mineTurn = active.filter((b) => canAdvanceBooking(me, b)).length;

  const submit = (e) => {
    e.preventDefault();
    if (!f.customer.trim() || !f.model.trim()) return;
    openBooking({ customer: f.customer.trim(), model: f.model.trim(), actor: me });
    pushToast({ id: ++_tid, icon: "🚗", label: "Booking opened", xp: 20, color: "#7C5CFF", name: me.name });
    confetti(innerWidth / 2, 220, 44);
    setF({ customer: "", model: "" });
  };

  return (
    <>
      <PageHead title="Bookings" subtitle="The cross-department booking race — every new car moves from booking to delivery, one department at a time."
        right={<span className="chip">{me?.supervisor ? "⭐ Supervisor — any stage" : `Acting as ${deptLabel(me?.dept)}`}{mineTurn > 0 ? ` · ${mineTurn} need you` : ""}</span>} />

      {/* open booking — Sales only */}
      {canOpenBooking(me) ? (
        <Card className="mb-6">
          <div className="mb-4 flex items-center gap-2"><Car size={18} strokeWidth={1.75} className="text-violet-400" /><h3 className="font-display text-lg font-semibold text-ink">Open a new booking</h3></div>
          <form onSubmit={submit} className="flex flex-col gap-3 sm:flex-row">
            <input value={f.customer} onChange={(e) => setF({ ...f, customer: e.target.value })} placeholder="Customer name" className="field flex-1" required />
            <input list="bk-models" value={f.model} onChange={(e) => setF({ ...f, model: e.target.value })} placeholder="Car model" className="field flex-1" required />
            <datalist id="bk-models">{carModels.map((m) => <option key={m} value={m} />)}</datalist>
            <button type="submit" className="btn btn-primary sm:w-auto"><Plus size={16} /> Open booking <span className="text-white/70">+20</span></button>
          </form>
          <p className="mt-3 text-xs text-faint">Constraint: bookings can only be opened by Sales, then must clear each department in order — Sales → Finance → Accounts → EDP → PDI → Customer Care → RTO → Accounts → Customer Care.</p>
        </Card>
      ) : (
        <Card className="mb-6 flex items-center gap-2 text-sm text-muted"><Lock size={15} className="text-faint" /> New bookings are opened by <b className="text-ink">Sales</b>. Your department acts when a booking reaches your stage below.</Card>
      )}

      <h3 className="mb-2 font-display font-semibold text-ink">In progress <span className="text-sm font-normal text-muted">({active.length})</span></h3>
      {active.length === 0
        ? <Card className="text-sm text-muted">No bookings in progress. {canOpenBooking(me) ? "Open one above to start the race." : "Sales will open bookings for your team to move forward."}</Card>
        : <div className="grid gap-3 lg:grid-cols-2">{active.map((b, i) => <BookingCard key={b.id} b={b} me={me} delay={i * 0.05} />)}</div>}

      {closed.length > 0 && (
        <>
          <h3 className="mb-2 mt-8 font-display font-semibold text-ink">Completed <span className="text-sm font-normal text-muted">({closed.length})</span></h3>
          <div className="space-y-2">
            {closed.map((b) => (
              <div key={b.id} className="glass flex items-center justify-between px-4 py-3 text-sm">
                <span className="flex items-center gap-2 text-ink"><CheckCircle2 size={15} className={b.cancelled ? "text-bad" : "text-good"} /> {b.model} <span className="text-muted">· {b.customer}</span></span>
                <span className="chip" style={{ color: b.cancelled ? "#F43F5E" : "#22C55E", borderColor: (b.cancelled ? "#F43F5E" : "#22C55E") + "55" }}>{b.cancelled ? "Cancelled" : "Delivered 🏁"}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </>
  );
}
