import { useState } from "react";
import { Link } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import { AreaChart, Area, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { Zap, Trophy, Users2, CalendarDays, Flame, ArrowRight, Sparkles, Info, Swords, Crown } from "lucide-react";
import { useStore, useMe } from "../store/useStore";
import { rankProgress, actionMeta, fmt, coachInsights, TONE, DEPT_COLOR, deptLabel } from "../lib/gamify";
import { players } from "../data/db";
import Card from "../components/ui/Card";
import StatTile from "../components/ui/StatTile";
import RankRing from "../components/ui/RankRing";
import XPBar from "../components/ui/XPBar";
import CountUp from "../components/ui/CountUp";
import PageHead from "../components/ui/PageHead";
import { BadgePill } from "../components/ui/Badge";
import XpInfoModal from "../components/ui/XpInfoModal";

const greeting = () => {
  const h = new Date().getHours();
  return h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening";
};

export default function Dashboard() {
  const me = useMe();
  const sessionXp = useStore((s) => s.sessionXp);
  const liveCounts = useStore((s) => s.liveCounts);
  const [showXp, setShowXp] = useState(false);
  if (!me) return null;
  const rp = rankProgress(me);
  const deptPlayers = players.filter((p) => p.dept === me.dept);
  const rank = deptPlayers.findIndex((p) => p.id === me.id) + 1;
  const above = rank > 1 ? deptPlayers[rank - 2] : null;
  const gap = above ? Math.max(0, above.xp - me.xp) : 0;
  const cum = (me.daily || []).reduce((acc, d) => { const last = acc.length ? acc[acc.length - 1].xp : 0; acc.push({ date: d.date.slice(5), xp: last + d.xp }); return acc; }, []);
  const insights = coachInsights(me, liveCounts).slice(0, 2);
  const color = DEPT_COLOR[me.dept];

  return (
    <>
      <PageHead title={`${greeting()}, ${me.name.split(" ")[0]}.`} subtitle={`${me.designation || me.dept} · ${me.locName}`}
        right={<button onClick={() => setShowXp(true)} className="chip transition hover:border-violet/50 hover:text-ink" style={{ cursor: "pointer" }}><Info size={13} className="text-violet-400" /> How XP works</button>} />

      {/* hero */}
      <Card className="mb-5 flex flex-col items-center gap-6 sm:flex-row sm:items-center">
        <RankRing pct={rp.pct}>
          <div className="text-[10px] uppercase tracking-widest text-muted">{me.dept}</div>
          <div className="font-display text-base font-bold text-ink">{me.rank}</div>
          <div className="mt-0.5 text-xs text-gold">Lvl {me.rankIdx + 1}</div>
        </RankRing>
        <div className="flex-1">
          <div className="flex items-baseline gap-2">
            <span className="font-display text-4xl font-bold grad-text"><CountUp value={me.xp + sessionXp} /></span>
            <span className="text-muted">total XP</span>
          </div>
          <div className="mt-3">
            <div className="mb-1 flex justify-between text-xs text-muted">
              <span>{me.rank}</span>
              <span>{rp.next != null ? `${fmt(rp.toNext)} XP → ${me.rankNextName}` : "Max rank 👑"}</span>
            </div>
            <XPBar pct={rp.pct} />
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            <span className="chip"><Flame size={13} className="text-amber" /> {me.streak}-day streak</span>
            <span className="chip"><Trophy size={13} className="text-gold" /> #{rank} in {deptLabel(me.dept)}</span>
            {above
              ? <span className="chip" style={{ color: "#FFC53D", borderColor: "#FFC53D55" }}><Swords size={13} /> {fmt(gap)} XP to overtake {above.name.split(" ")[0]}</span>
              : <span className="chip" style={{ color: "#FFC53D", borderColor: "#FFC53D55" }}><Crown size={13} /> Leading {deptLabel(me.dept)} 👑</span>}
            <span className="chip"><Users2 size={13} className="text-blue-400" /> {me.collab} team bonuses</span>
          </div>
        </div>
      </Card>

      {/* stat tiles */}
      <div className="mb-5 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatTile icon={Zap} label="Milestones" value={me.milestones} accent="#7C5CFF" delay={0.02} />
        <StatTile icon={Users2} label="Team XP" value={me.teamXp} accent="#FFC53D" delay={0.06} />
        <StatTile icon={CalendarDays} label="Active days" value={me.activeDays} accent="#3B82F6" delay={0.1} />
        <StatTile icon={Flame} label="Best streak" value={me.longestStreak} suffix="d" accent="#F59E0B" delay={0.14} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        {/* xp trend */}
        <Card className="lg:col-span-2">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="font-display font-semibold text-ink">XP growth</h3>
            <span className="text-xs text-muted">cumulative over active days</span>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={cum} margin={{ left: 0, right: 8, top: 8 }}>
                <defs>
                  <linearGradient id="xpg" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={color} stopOpacity={0.5} />
                    <stop offset="100%" stopColor={color} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" tick={{ fill: "#5B6080", fontSize: 11 }} axisLine={false} tickLine={false} minTickGap={28} />
                <Tooltip contentStyle={{ background: "#12131F", border: "1px solid rgba(255,255,255,.1)", borderRadius: 12, color: "#E8EAF6" }} />
                <Area type="monotone" dataKey="xp" stroke={color} strokeWidth={2.5} fill="url(#xpg)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* AI coach teaser */}
        <Card className="flex flex-col">
          <div className="mb-3 flex items-center gap-2">
            <Sparkles size={16} className="text-violet-400" />
            <h3 className="font-display font-semibold text-ink">AI Coach</h3>
          </div>
          <div className="flex-1 space-y-3">
            {insights.map((it, i) => (
              <div key={i} className="rounded-xl border border-white/8 bg-white/[.03] p-3 text-sm text-muted">
                <span className={`mr-1 ${TONE[it.tone]}`}>{it.icon}</span> {it.text}
              </div>
            ))}
          </div>
          <Link to="/coach" className="mt-3 flex items-center gap-1 text-sm font-semibold text-violet-400">
            Open coach <ArrowRight size={15} />
          </Link>
        </Card>
      </div>

      {/* recent + badges */}
      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="font-display font-semibold text-ink">Your recent milestones</h3>
            <Link to="/feed" className="text-xs font-semibold text-violet-400">Live feed →</Link>
          </div>
          <div className="space-y-2">
            {(me.recent || []).slice(0, 6).map((r, i) => {
              const m = actionMeta(r.action);
              return (
                <div key={i} className="flex items-center gap-3 rounded-xl bg-white/[.03] px-3 py-2">
                  <span className="text-xl">{m.icon}</span>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-medium text-ink">{m.label}</div>
                    <div className="text-xs text-faint">{r.ts.slice(0, 16).replace("T", " ")} · {r.bk}</div>
                  </div>
                  <span className="font-display font-bold" style={{ color: m.color }}>+{r.xp}</span>
                </div>
              );
            })}
          </div>
        </Card>
        <Card>
          <div className="mb-3 flex items-center justify-between">
            <h3 className="font-display font-semibold text-ink">Badges</h3>
            <Link to="/achievements" className="text-xs font-semibold text-violet-400">All →</Link>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {me.badges.slice(0, 6).map((b) => <BadgePill key={b.id} badge={b} />)}
            {me.badges.length === 0 && <p className="col-span-3 text-sm text-faint">Earn your first badge today!</p>}
          </div>
        </Card>
      </div>

      <AnimatePresence>
        {showXp && <XpInfoModal onClose={() => setShowXp(false)} />}
      </AnimatePresence>
    </>
  );
}
