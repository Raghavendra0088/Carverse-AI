import { useState } from "react";
import { motion } from "framer-motion";
import { Headset, Send, CheckCircle2, Clock, User, ShoppingCart, ShieldAlert, Check, Loader } from "lucide-react";
import { useStore, useMe } from "../store/useStore";
import { useWorkflow } from "../store/useWorkflow";
import Card from "../components/ui/Card";
import PageHead from "../components/ui/PageHead";

const shortTime = (iso) => { try { return new Date(iso).toLocaleString([], { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }); } catch { return ""; } };
const STATUS = {
  open:        { c: "#F59E0B", label: "Open",        icon: Clock },
  in_progress: { c: "#38BDF8", label: "In progress", icon: Loader },
  closed:      { c: "#22C55E", label: "Resolved",    icon: CheckCircle2 },
};

function TicketCard({ t, me, delay }) {
  const approveTicket = useWorkflow((s) => s.approveTicket);
  const replyTicket = useWorkflow((s) => s.replyTicket);
  const closeTicket = useWorkflow((s) => s.closeTicket);
  const pushToast = useStore((s) => s.pushToast);
  const [text, setText] = useState("");
  const sm = STATUS[t.status] || STATUS.open;

  const approve = () => { approveTicket(t.id, me); pushToast({ id: Date.now(), icon: "🎧", label: "Ticket approved — you're handling it", xp: 0, color: "#38BDF8", name: me.name }); };
  const reply = () => { if (!text.trim()) return; replyTicket(t.id, text.trim(), me); pushToast({ id: Date.now(), icon: "✉️", label: "Reply sent — customer emailed", xp: 0, color: "#38BDF8", name: me.name }); setText(""); };
  const close = () => { closeTicket(t.id, me); pushToast({ id: Date.now(), icon: "✅", label: "Ticket resolved & closed (+15 XP)", xp: 15, color: "#22C55E", name: me.name }); };

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay }} className="glass p-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/[.05] text-muted">
            {t.fromKind === "buyer" ? <ShoppingCart size={15} strokeWidth={1.75} /> : <User size={15} strokeWidth={1.75} />}
          </span>
          <div>
            <div className="text-sm font-semibold text-ink">{t.subject}</div>
            <div className="text-xs text-faint">{t.fromName} · {t.fromKind === "buyer" ? "Buyer" : "Seller"} · {shortTime(t.at)}{t.handledBy ? ` · handled by ${t.handledBy}` : ""}</div>
          </div>
        </div>
        <span className="chip shrink-0" style={{ color: sm.c, borderColor: `${sm.c}55` }}><sm.icon size={11} /> {sm.label}</span>
      </div>

      <p className="mt-3 rounded-2xl border border-white/6 bg-white/[.02] p-3 text-sm text-muted">{t.message}</p>

      {t.replies.map((r, i) => (
        <div key={i} className="mt-2 rounded-2xl border border-cyan/20 bg-cyan/[.06] p-3">
          <div className="text-[11px] font-semibold text-cyan">🎧 {r.by} · {shortTime(r.at)}</div>
          <p className="mt-1 text-sm text-ink">{r.text}</p>
        </div>
      ))}

      {/* actions depend on status */}
      {t.status === "open" && (
        <button onClick={approve} className="btn btn-primary mt-3 !py-2"><Check size={15} /> Approve &amp; take up</button>
      )}
      {t.status === "in_progress" && (
        <div className="mt-3 space-y-2">
          <div className="flex gap-2">
            <input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && reply()}
              placeholder="Reply to the customer…" className="field flex-1" />
            <button onClick={reply} disabled={!text.trim()} className={`btn ${text.trim() ? "btn-primary" : "btn-ghost cursor-not-allowed opacity-60"}`}><Send size={15} /></button>
          </div>
          <button onClick={close} className="btn btn-ghost w-full !py-2 !text-good hover:!border-good/40"><CheckCircle2 size={15} /> Mark resolved &amp; close <span className="text-gold">+15 XP</span></button>
        </div>
      )}
      {t.status === "closed" && (
        <div className="mt-3 flex items-center gap-2 rounded-2xl border border-good/20 bg-good/5 px-3 py-2 text-xs text-good">
          <CheckCircle2 size={14} /> Resolved &amp; closed{t.closedBy ? ` by ${t.closedBy}` : ""}{t.closedAt ? ` · ${shortTime(t.closedAt)}` : ""} · +15 XP awarded
        </div>
      )}
    </motion.div>
  );
}

export default function Support() {
  const me = useMe();
  const tickets = useWorkflow((s) => s.tickets);
  const canAnswer = me && me.kind === "employee" && (me.dept === "CUSTOMER CARE" || me.supervisor);
  const open = tickets.filter((t) => t.status === "open");
  const active = tickets.filter((t) => t.status === "in_progress");
  const closed = tickets.filter((t) => t.status === "closed").slice(0, 12);

  return (
    <>
      <PageHead title="Customer Care Desk"
        subtitle="Approve incoming queries, resolve them with the customer, then close the ticket — you earn XP only when a ticket is resolved."
        right={<span className="chip"><Headset size={13} className="text-teal" /> {open.length} open · {active.length} active</span>} />

      {!canAnswer ? (
        <Card className="flex items-center gap-2 text-sm text-amber"><ShieldAlert size={15} /> The Customer Care desk is for the Customer Care team (or supervisors). Log in as a Customer Care employee to handle queries.</Card>
      ) : (
        <>
          <h3 className="mb-3 font-display font-semibold text-ink">Open — awaiting approval <span className="text-sm font-normal text-muted">({open.length})</span></h3>
          {open.length === 0
            ? <Card className="text-sm text-muted">No new queries waiting for approval.</Card>
            : <div className="grid gap-3 lg:grid-cols-2">{open.map((t, i) => <TicketCard key={t.id} t={t} me={me} delay={i * 0.05} />)}</div>}

          {active.length > 0 && (
            <>
              <h3 className="mb-3 mt-8 font-display font-semibold text-ink">In progress <span className="text-sm font-normal text-muted">({active.length})</span></h3>
              <div className="grid gap-3 lg:grid-cols-2">{active.map((t, i) => <TicketCard key={t.id} t={t} me={me} delay={i * 0.05} />)}</div>
            </>
          )}

          {closed.length > 0 && (
            <>
              <h3 className="mb-3 mt-8 font-display font-semibold text-ink">Resolved <span className="text-sm font-normal text-muted">({closed.length})</span></h3>
              <div className="grid gap-3 lg:grid-cols-2">{closed.map((t, i) => <TicketCard key={t.id} t={t} me={me} delay={i * 0.04} />)}</div>
            </>
          )}
        </>
      )}
    </>
  );
}
