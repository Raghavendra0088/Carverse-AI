import { motion } from "framer-motion";
import { CalendarRange, Users2, HeartHandshake, Car, PackageCheck, Store, Flag } from "lucide-react";
import { meta, departments } from "../data/db";
import { DEPT_COLOR, deptLabel, fmt } from "../lib/gamify";
import { useWorkflow } from "../store/useWorkflow";
import Card from "../components/ui/Card";
import StatTile from "../components/ui/StatTile";
import PageHead from "../components/ui/PageHead";

export default function History() {
  const deals = useWorkflow((s) => s.deals);
  const inventory = useWorkflow((s) => s.inventory);
  const bookings = useWorkflow((s) => s.bookings);

  const acquired = deals.filter((d) => d.status === "ACQUIRED").length;
  const listed = inventory.filter((it) => it.status === "LISTED").length;
  const sold = inventory.filter((it) => it.status === "SOLD").length;
  const delivered = bookings.filter((b) => b.closed).length;

  const maxXp = Math.max(1, ...departments.map((d) => d.xp));
  const totalMilestones = departments.reduce((a, d) => a + d.milestones, 0);

  return (
    <>
      <PageHead title="History & Progress"
        subtitle={`Everything that's moved through CarVerse — ${meta.dateRange?.[0]} to ${meta.dateRange?.[1]}. Bookings logged and how every department is progressing.`} />

      {/* dealership totals */}
      <div className="mb-5 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatTile icon={CalendarRange} label="Total bookings" value={meta.bookings} accent="#7C5CFF" sub="all-time, across branches" />
        <StatTile icon={Users2} label="Active players" value={meta.players} accent="#38BDF8" sub={`${meta.totalEvents.toLocaleString()} events`} />
        <StatTile icon={HeartHandshake} label="Team-ups" value={meta.collabCount} accent="#FFC53D" sub="cross-dept collaborations" />
        <StatTile icon={PackageCheck} label="Milestones logged" value={totalMilestones} accent="#22C55E" sub="meaningful, once per booking" />
      </div>

      {/* live commerce history */}
      <div className="mb-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatTile icon={Car} label="Cars acquired" value={acquired} accent="#2EE6A6" sub="trade-ins bought" />
        <StatTile icon={Store} label="Cars listed" value={listed} accent="#A78BFA" sub="live in marketplace" />
        <StatTile icon={Flag} label="Cars delivered" value={delivered} accent="#FB7185" sub="buyer orders completed" />
        <StatTile icon={PackageCheck} label="Cars sold" value={sold} accent="#F59E0B" sub="handed to buyers" />
      </div>

      {/* per-department progress */}
      <h3 className="mb-4 font-display text-lg font-semibold text-ink">Progress of every department</h3>
      <div className="space-y-3">
        {departments.map((d, i) => {
          const color = DEPT_COLOR[d.name] || "#7C5CFF";
          const pct = Math.round((d.xp / maxXp) * 100);
          return (
            <motion.div key={d.name} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i, 8) * 0.05 }}
              className="glass p-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ background: color }} />
                  <span className="font-display font-semibold text-ink">{deptLabel(d.name)}</span>
                  <span className="chip">{d.members} {d.members === 1 ? "player" : "players"}</span>
                </div>
                <div className="font-display text-xl font-bold" style={{ color }}>{fmt(d.xp)} <span className="text-xs font-medium text-faint">XP</span></div>
              </div>
              <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-white/[.06]">
                <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 1, ease: [0.2, 0.85, 0.25, 1] }}
                  className="h-full rounded-full" style={{ background: color }} />
              </div>
              <div className="mt-2.5 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted">
                <span>{fmt(d.milestones)} milestones</span>
                <span>{fmt(d.collab)} team-ups</span>
                <span>{Math.round((d.milestones / (totalMilestones || 1)) * 100)}% of all milestones</span>
              </div>
            </motion.div>
          );
        })}
      </div>
    </>
  );
}
