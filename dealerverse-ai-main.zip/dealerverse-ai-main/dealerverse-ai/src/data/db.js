import data from "./dealerverse.json";

export const meta = data.meta;
export const players = data.players;
export const departments = data.departments;
export const weeklySeries = data.weeklySeries;
export const mostImproved = data.mostImproved;
export const fastestGrowing = data.fastestGrowing;
export const feed = data.feed;
export const staff = data.staff;
export const supervisors = data.supervisors;
export const carModels = data.carModels;
export const departmentsList = data.departmentsList;
export const gamifiedDepts = data.gamifiedDepts || departmentsList;

const byId = Object.fromEntries(players.map((p) => [p.id, p]));
export const getPlayer = (id) => byId[id];
export const playersByDept = (dept) => players.filter((p) => p.dept === dept);
export const topPlayers = (n = 20, dept = null) => (dept ? playersByDept(dept) : players).slice(0, n);

// unified directory (players + staff + supervisors) so any id resolves to a person
const dir = {};
players.forEach((p) => (dir[p.id] = { id: p.id, name: p.name, dept: p.dept, designation: p.designation, loc: p.locName }));
Object.entries(staff).forEach(([d, arr]) => arr.forEach((s) => { if (!dir[s.id]) dir[s.id] = { id: s.id, name: s.name, dept: d, designation: s.designation, loc: s.loc }; }));
supervisors.forEach((s) => { if (!dir[s.id]) dir[s.id] = { id: s.id, name: s.name, dept: s.dept, designation: s.designation, loc: "" }; });
export const getDirectory = (id) => dir[id];

// a player-shaped profile with zeros, for employees not in the gamified (Sales/Finance) set
export const synthProfile = (id) => {
  const d = dir[id] || { id, name: id, dept: "", designation: "", loc: "" };
  return {
    id, name: d.name, dept: d.dept, designation: d.designation, locName: d.loc || "",
    manager: "", xp: 0, teamXp: 0, collab: 0, milestones: 0, actions: {}, today: {},
    streak: 0, longestStreak: 0, activeDays: 0, rank: "Team Member", rankIdx: 0,
    rankFloor: 0, rankNext: null, rankNextName: null, badges: [], daily: [], recent: [],
  };
};

// pick a representative (rich) player id for a department, else fall back to staff
export const repEmployee = (dept, supervisor = false) => {
  if (supervisor) return supervisors[0]?.id;
  return demoProfileFor(dept)?.id || staff[dept]?.[0]?.id;
};

// login picker: list real gamified players for a dept (they have live dashboards); else static staff
export const staffFor = (dept) => {
  const ps = playersByDept(dept);
  return ps.length
    ? ps.slice(0, 12).map((p) => ({ id: p.id, name: p.name, designation: p.designation }))
    : (staff[dept] || []);
};

// a good demo profile for a department: a decorated, high-rank player
export const demoProfileFor = (dept) => {
  const ps = playersByDept(dept);
  if (!ps.length) return players[0];
  return ps.find((p) => p.rankIdx >= 3 && p.badges.length >= 3)
    || ps.find((p) => p.rankIdx >= 2)
    || ps[0];
};

export const rankLadder = (dept) => (meta.ranks[dept] || []).map((name, idx) => ({ name, idx, xp: meta.thresholds[dept]?.[idx] ?? 0 }));

// deterministic 4-digit PIN per employee id (client-side auth factor, no backend)
export const pinFor = (id) => {
  const s = String(id); let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return String((h % 9000) + 1000);
};
