import { useEffect } from "react";
import { HashRouter, Routes, Route, Navigate } from "react-router-dom";
import { useWorkflow } from "./store/useWorkflow";
import AppLayout from "./components/layout/AppLayout";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import ActivityFeed from "./pages/ActivityFeed";
import Missions from "./pages/Missions";
import Career from "./pages/Career";
import Achievements from "./pages/Achievements";
import Leaderboard from "./pages/Leaderboard";
import Department from "./pages/Department";
import Manager from "./pages/Manager";
import Coach from "./pages/Coach";
import Profile from "./pages/Profile";
import CustomerPortal from "./pages/CustomerPortal";
import Evaluate from "./pages/Evaluate";
import Pipeline from "./pages/Pipeline";
import Marketplace from "./pages/Marketplace";
import MyPurchases from "./pages/MyPurchases";
import History from "./pages/History";
import Support from "./pages/Support";
import Bookings from "./pages/Bookings";

export default function App() {
  useEffect(() => { useWorkflow.getState().seedIfEmpty(); }, []);
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route element={<AppLayout />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/feed" element={<ActivityFeed />} />
          <Route path="/pipeline" element={<Pipeline />} />
          <Route path="/bookings" element={<Bookings />} />
          <Route path="/evaluate" element={<Evaluate />} />
          <Route path="/customer" element={<CustomerPortal />} />
          <Route path="/market" element={<Marketplace />} />
          <Route path="/purchases" element={<MyPurchases />} />
          <Route path="/missions" element={<Missions />} />
          <Route path="/career" element={<Career />} />
          <Route path="/achievements" element={<Achievements />} />
          <Route path="/leaderboard" element={<Leaderboard />} />
          <Route path="/department" element={<Department />} />
          <Route path="/manager" element={<Manager />} />
          <Route path="/history" element={<History />} />
          <Route path="/support" element={<Support />} />
          <Route path="/coach" element={<Coach />} />
          <Route path="/profile" element={<Profile />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </HashRouter>
  );
}
