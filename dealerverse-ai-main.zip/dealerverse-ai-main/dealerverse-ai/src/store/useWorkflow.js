import { create } from "zustand";
import { persist } from "zustand/middleware";
import { SALE_STAGES, SALE_LAST, BOOKING_STAGES, BOOKING_LAST, suggestRetail, reconCost } from "../lib/workflow";
import { carModels } from "../data/db";
import { defaultSpecs } from "../lib/carimg";
import { useStore } from "./useStore";

// advance mission progress from a real action (no XP here — the ledger handles XP)
const live = (...actions) => useStore.getState().bumpLive(...actions);

const gid = (p) => p + Math.random().toString(36).slice(2, 8);
const stamp = (label) => ({ at: new Date().toISOString(), label });
const rup = (n) => "₹" + Number(n || 0).toLocaleString("en-IN");

export const useWorkflow = create(
  persist(
    (set, get) => ({
      customers: [],   // sellers
      buyers: [],      // buying customers
      deals: [],       // acquisition (sell-side)
      inventory: [],   // dealership-owned cars, listed for sale
      bookings: [],    // sale fulfillment (buy-side), one per reserved car
      carBookings: [], // new-car booking lifecycle (the cross-department booking race)
      ledger: {},      // empId -> live XP earned via workflow
      wfeed: [],       // workflow activity feed
      docs: [],        // step documents uploaded by employees, verified by supervisors
      mails: [],       // system -> customer/buyer emails, one per lifecycle step
      tickets: [],     // customer-care queries from buyers/sellers, answered by CCM employees

      ledgerXp: (id) => get().ledger[id] || 0,

      // ---------- customer care (buyer/seller query -> employee reply) ----------
      postTicket: ({ fromId, fromName, fromKind, subject, message }) => {
        const id = gid("tkt");
        set((s) => ({ tickets: [{ id, fromId, fromName, fromKind: fromKind || "buyer",
          subject: subject || "General query", message, at: new Date().toISOString(),
          status: "open", replies: [] }, ...s.tickets].slice(0, 120) }));
        return id;
      },
      // CCM accepts/takes up an open ticket (no XP yet)
      approveTicket: (ticketId, actor) =>
        set((s) => ({ tickets: s.tickets.map((t) => t.id === ticketId && t.status === "open"
          ? { ...t, status: "in_progress", handledBy: actor?.name || "Customer Care", handledById: actor?.id || "" }
          : t) })),
      // reply while resolving — emails the customer, but NO XP for chatter
      replyTicket: (ticketId, text, actor) => {
        set((s) => ({ tickets: s.tickets.map((t) => t.id === ticketId && t.status !== "closed"
          ? { ...t, status: "in_progress",
              handledBy: t.handledBy || actor?.name || "Customer Care", handledById: t.handledById || actor?.id || "",
              replies: [...t.replies, { by: actor?.name || "Customer Care", at: new Date().toISOString(), text }] }
          : t) }));
        const t = get().tickets.find((x) => x.id === ticketId);
        if (t) get().sendMail({ toId: t.fromId, to: t.fromName, kind: "support", subject: `Re: ${t.subject}`, body: text });
      },
      // resolve & close — XP is awarded ONCE, here, only when the query is closed
      closeTicket: (ticketId, actor) => {
        const t = get().tickets.find((x) => x.id === ticketId);
        if (!t || t.status === "closed") return;
        set((s) => ({ tickets: s.tickets.map((x) => x.id === ticketId
          ? { ...x, status: "closed", closedBy: actor?.name || "Customer Care", closedAt: new Date().toISOString() } : x) }));
        get().sendMail({ toId: t.fromId, to: t.fromName, kind: "support", subject: `Resolved: ${t.subject}`,
          body: `Hi ${t.fromName}, your query "${t.subject}" has been resolved and closed by our Customer Care team. Reply anytime if you need more help — thank you for choosing CarVerse!` });
        if (actor?.id) get().award(actor.id, 15, `Resolved & closed a customer ticket`);
      },
      ticketsFor: (fromId) => get().tickets.filter((t) => t.fromId === fromId),

      // ---------- email communication (system -> customer, every step) ----------
      sendMail: ({ toId, to, subject, body, kind }) =>
        set((s) => ({
          mails: [{ id: gid("mail"), at: new Date().toISOString(), toId, to, subject, body, kind: kind || "update", read: false }, ...s.mails].slice(0, 120),
        })),
      mailsFor: (toId) => get().mails.filter((m) => m.toId === toId),
      markMailsRead: (toId) => set((s) => ({ mails: s.mails.map((m) => (m.toId === toId ? { ...m, read: true } : m)) })),

      // ---------- step documents (employee upload -> supervisor verification) ----------
      attachDoc: ({ entity, refId, refLabel, step, fileName, fileType, dataUrl, actor }) =>
        set((s) => ({
          docs: [{
            id: gid("doc"), entity, refId, refLabel, step,
            fileName, fileType: fileType || "", dataUrl: dataUrl || null,
            uploadedBy: actor?.name || "—", uploadedById: actor?.id || "",
            at: new Date().toISOString(), status: "pending", verifiedBy: null,
          }, ...s.docs].slice(0, 200),
        })),
      verifyDoc: (docId, ok, actor) =>
        set((s) => ({
          docs: s.docs.map((d) => d.id === docId
            ? { ...d, status: ok ? "verified" : "rejected", verifiedBy: actor?.name || "Supervisor", verifiedAt: new Date().toISOString() }
            : d),
        })),
      docsFor: (entity, refId) => get().docs.filter((d) => d.entity === entity && d.refId === refId),

      award: (empId, xp, text) =>
        set((s) => ({
          ledger: { ...s.ledger, [empId]: (s.ledger[empId] || 0) + xp },
          wfeed: [{ id: gid("f"), at: new Date().toISOString(), text, xp, empId }, ...s.wfeed].slice(0, 60),
        })),

      ensureCustomer: (name, phone) => {
        const existing = get().customers.find((c) => c.name.toLowerCase() === name.toLowerCase());
        if (existing) return existing.id;
        const id = gid("cust");
        set((s) => ({ customers: [...s.customers, { id, name, phone }] }));
        return id;
      },
      ensureBuyer: (name, phone) => {
        const existing = get().buyers.find((c) => c.name.toLowerCase() === name.toLowerCase());
        if (existing) return existing.id;
        const id = gid("buyer");
        set((s) => ({ buyers: [...s.buyers, { id, name, phone }] }));
        return id;
      },

      // ---------- acquisition (sell-side) ----------
      submitDeal: ({ customerId, customerName, model, year, km, expected, images, specs }) => {
        const id = gid("deal");
        const deal = { id, customerId, customerName, model, year, km, expected, images: images || [], specs: specs || {},
          status: "PENDING", inspectedBy: null, points: null, quotedPrice: null, evaluator: null,
          invId: null, createdAt: new Date().toISOString(), timeline: [stamp(`Submitted by ${customerName}`)] };
        set((s) => ({ deals: [deal, ...s.deals] }));
        get().sendMail({ toId: customerId, to: customerName, kind: "seller",
          subject: `We've received your ${model}`,
          body: `Hi ${customerName}, thanks for listing your ${model}${year ? ` (${year})` : ""} with CarVerse. Our PDI team will inspect it and email you a price offer shortly. Track everything in your seller portal.` });
        return deal;
      },

      inspectDeal: (dealId, actor) => {
        const points = 180 + Math.floor(Math.random() * 40); // 180-219 point check
        set((s) => ({ deals: s.deals.map((d) => d.id === dealId
          ? { ...d, status: "INSPECTED", inspectedBy: actor.name, points,
              timeline: [...d.timeline, stamp(`Inspected (${points}-pt check) by ${actor.name}`)] } : d) }));
        get().award(actor.id, 20, `Inspected a trade-in car`);
        live("DISPATCH_BY_PDI");
        const d = get().deals.find((x) => x.id === dealId);
        if (d) get().sendMail({ toId: d.customerId, to: d.customerName, kind: "seller",
          subject: `Your ${d.model} passed inspection`,
          body: `Good news ${d.customerName} — your ${d.model} completed our ${points}-point inspection. We're preparing a price offer and will email it to you next.` });
      },

      priceDeal: (dealId, price, actor) => {
        set((s) => ({ deals: s.deals.map((d) => d.id === dealId
          ? { ...d, status: "PRICED", quotedPrice: price, evaluator: actor.name,
              timeline: [...d.timeline, stamp(`Acquisition offer ${rup(price)} by ${actor.name}`)] } : d) }));
        get().award(actor.id, 40, `Made an acquisition offer`);
        const d = get().deals.find((x) => x.id === dealId);
        if (d) get().sendMail({ toId: d.customerId, to: d.customerName, kind: "seller",
          subject: `Your offer: ${rup(price)} for your ${d.model}`,
          body: `Hi ${d.customerName}, we're pleased to offer ${rup(price)} for your ${d.model}. Log in to your seller portal to accept — once you do, our Accounts team will arrange your payout.` });
      },

      rejectDeal: (dealId, actor) => {
        set((s) => ({ deals: s.deals.map((d) => d.id === dealId
          ? { ...d, status: "REJECTED", timeline: [...d.timeline, stamp(`Rejected by ${actor.name}`)] } : d) }));
        const d = get().deals.find((x) => x.id === dealId);
        if (d) get().sendMail({ toId: d.customerId, to: d.customerName, kind: "seller",
          subject: `Update on your ${d.model}`,
          body: `Hi ${d.customerName}, after inspection we're unable to make an offer on your ${d.model} at this time. Thank you for considering CarVerse.` });
      },

      // seller accepts our offer (no employee XP — customer action)
      acceptOffer: (dealId) => {
        set((s) => ({ deals: s.deals.map((d) => d.id === dealId
          ? { ...d, status: "ACCEPTED", timeline: [...d.timeline, stamp(`Offer accepted by ${d.customerName}`)] } : d) }));
        const d = get().deals.find((x) => x.id === dealId);
        if (d) get().sendMail({ toId: d.customerId, to: d.customerName, kind: "seller",
          subject: `Offer accepted — payout in progress`,
          body: `Thanks ${d.customerName}! You've accepted our offer of ${rup(d.quotedPrice)} for your ${d.model}. Our Accounts team will process your payout shortly and email you confirmation.` });
      },

      // accounts pays the seller -> car becomes dealership inventory, auto-listed at retail
      payoutSeller: (dealId, actor) => {
        const d = get().deals.find((x) => x.id === dealId);
        if (!d || d.status !== "ACCEPTED") return null;
        const acq = d.quotedPrice || 0;
        const invId = gid("inv");
        const item = {
          id: invId, dealId: d.id, model: d.model, year: d.year, km: d.km, images: d.images || [], specs: d.specs || {},
          acquisitionPrice: acq, reconditioning: reconCost(acq), retailPrice: suggestRetail(acq),
          status: "LISTED", certified: true, points: d.points || 190, listedBy: actor.name,
          buyerId: null, buyerName: null, saleBookingId: null, soldPrice: null,
          createdAt: new Date().toISOString(), timeline: [stamp(`Acquired & paid out by ${actor.name}`)],
        };
        set((s) => ({
          inventory: [item, ...s.inventory],
          deals: s.deals.map((x) => x.id === dealId
            ? { ...x, status: "ACQUIRED", invId, timeline: [...x.timeline, stamp(`Paid out ${rup(acq)} · listed for sale`)] } : x),
        }));
        get().award(actor.id, 50, `Acquired ${d.model} into inventory`);
        get().sendMail({ toId: d.customerId, to: d.customerName, kind: "seller",
          subject: `Payout complete for your ${d.model}`,
          body: `${rup(acq)} has been paid out for your ${d.model}. The sale is complete — thank you for choosing CarVerse. We hope to see you again!` });
        return item;
      },

      // employee override of the auto-computed retail price
      setRetail: (invId, price, actor) => {
        set((s) => ({ inventory: s.inventory.map((it) => it.id === invId
          ? { ...it, retailPrice: Number(price), timeline: [...it.timeline, stamp(`Retail re-priced to ${rup(price)} by ${actor.name}`)] } : it) }));
        get().award(actor.id, 10, `Priced a listing for retail`);
      },

      // ---------- sale (buy-side) ----------
      reserveInventory: (invId, buyer) => {
        const it = get().inventory.find((x) => x.id === invId);
        if (!it || it.status !== "LISTED") return null;
        const bid = gid("sale");
        const booking = { id: bid, invId, model: it.model, retailPrice: it.retailPrice,
          images: it.images || [], specs: it.specs || {},
          buyerId: buyer.id, buyerName: buyer.name, stageIdx: 0, closed: false,
          createdAt: new Date().toISOString(), timeline: [stamp(`Reserved by ${buyer.name}`)] };
        set((s) => ({
          bookings: [booking, ...s.bookings],
          inventory: s.inventory.map((x) => x.id === invId
            ? { ...x, status: "RESERVED", buyerId: buyer.id, buyerName: buyer.name, saleBookingId: bid } : x),
        }));
        get().sendMail({ toId: buyer.id, to: buyer.name, kind: "buyer",
          subject: `Reservation confirmed — ${it.model}`,
          body: `Hi ${buyer.name}, your reservation for the ${it.model} (${rup(it.retailPrice)}) is confirmed. Our team will now handle finance, payment, invoicing, registration and delivery — you'll get an email at each step. Track it in "My Purchases".` });
        return booking;
      },

      advanceSale: (bookingId, actor) => {
        const b = get().bookings.find((x) => x.id === bookingId);
        if (!b || b.closed || b.stageIdx >= SALE_LAST) return null;
        const next = SALE_STAGES[b.stageIdx + 1];
        const closed = b.stageIdx + 1 === SALE_LAST;
        set((s) => ({
          bookings: s.bookings.map((x) => x.id === bookingId
            ? { ...x, stageIdx: x.stageIdx + 1, closed, timeline: [...x.timeline, stamp(`${next.label} by ${actor.name}`)] } : x),
          inventory: closed ? s.inventory.map((it) => it.saleBookingId === bookingId
            ? { ...it, status: "SOLD", soldPrice: it.retailPrice, timeline: [...it.timeline, stamp(`Delivered to ${b.buyerName}`)] } : it) : s.inventory,
        }));
        get().award(actor.id, next.xp, `${next.label} — ${b.model}`);
        const saleMap = { FINANCE: "FINANCE_CLEARED", PAYMENT: "CREDIT_APPROVED", INVOICE: "INVOICE_APPROVED_EDP", RTO: "REGISTRATION_ADDED", DELIVERED: "DISPATCH_BY_CCM" };
        live(saleMap[next.key], "TEAM_BONUS", next.key === "INVOICE" ? "RGISTRATION_CREATED_EDP" : next.key === "RTO" ? "RTO_REQUEST" : null);
        get().sendMail({ toId: b.buyerId, to: b.buyerName, kind: "buyer",
          subject: closed ? `Delivered! Enjoy your ${b.model} 🎉` : `${next.label} — ${b.model}`,
          body: closed
            ? `Congratulations ${b.buyerName}! Your ${b.model} has been delivered. Your 1-year warranty and 7-day return are now active. Welcome to the CarVerse family!`
            : `Update on your ${b.model}: "${next.label}" is complete. We'll email you again at the next step.` });
        return next;
      },

      // ---------- new-car booking lifecycle (department-gated, sequential) ----------
      openBooking: ({ customer, model, actor }) => {
        const id = gid("bk");
        const st = BOOKING_STAGES[0];
        const bk = { id, customer, model, stageIdx: 0, closed: false, cancelled: false,
          createdBy: actor?.name || "Sales", createdAt: new Date().toISOString(),
          timeline: [stamp(`Booking opened for ${customer} · ${model} by ${actor?.name || "Sales"}`)] };
        set((s) => ({ carBookings: [bk, ...s.carBookings] }));
        if (actor?.id) get().award(actor.id, st.xp, `Opened booking — ${model}`);
        live("BOOKING_CREATED");
        return bk;
      },
      advanceBooking: (id, actor) => {
        const b = get().carBookings.find((x) => x.id === id);
        if (!b || b.closed || b.stageIdx >= BOOKING_LAST) return null;
        const next = BOOKING_STAGES[b.stageIdx + 1];
        // constraint: only the owning department (or a supervisor) may advance
        if (!(actor?.supervisor || actor?.dept === next.owner)) return null;
        const closed = b.stageIdx + 1 === BOOKING_LAST;
        set((s) => ({ carBookings: s.carBookings.map((x) => x.id === id
          ? { ...x, stageIdx: x.stageIdx + 1, closed, timeline: [...x.timeline, stamp(`${next.label} by ${actor.name}`)] } : x) }));
        if (actor?.id) get().award(actor.id, next.xp, `${next.label} — ${b.model}`);
        // auto-update missions: the stage's milestone, a team bonus (cross-dept handoff),
        // and the backend-paired action where relevant
        const extra = next.action === "INVOICE_APPROVED_EDP" ? "RGISTRATION_CREATED_EDP"
          : next.action === "REGISTRATION_ADDED" ? "RTO_REQUEST" : null;
        live(next.action, "TEAM_BONUS", extra);
        return next;
      },
      cancelBooking: (id, actor) =>
        set((s) => ({ carBookings: s.carBookings.map((x) => x.id === id
          ? { ...x, closed: true, cancelled: true, timeline: [...x.timeline, stamp(`Cancelled by ${actor?.name || "—"}`)] } : x) })),

      resetDemo: () => set({ deals: [], inventory: [], bookings: [], carBookings: [], docs: [], mails: [], tickets: [] }),

      seedIfEmpty: () => {
        if (get().inventory.length || get().deals.length) return;
        const mkDeal = (customerName, model, year, km, expected, status = "PENDING") => ({
          id: gid("deal"), customerId: gid("cust"), customerName, model, year, km, expected,
          images: [], specs: defaultSpecs(model, year), status,
          inspectedBy: status === "PENDING" ? null : "Supervisor",
          points: status === "PENDING" ? null : 195,
          quotedPrice: status === "PRICED" || status === "ACCEPTED" ? Math.round(expected * 0.95) : null,
          evaluator: status === "PRICED" || status === "ACCEPTED" ? "Supervisor" : null,
          invId: null, createdAt: new Date().toISOString(),
          timeline: [stamp(`Submitted by ${customerName}`)],
        });
        const deals = [
          mkDeal("Rahul Menon", carModels[5], 2021, 32000, 1150000, "PENDING"),
          mkDeal("Priya Nair", carModels[2], 2019, 54000, 720000, "INSPECTED"),
          mkDeal("Arjun Rao", carModels[7], 2022, 18000, 980000, "ACCEPTED"),
        ];
        const mkInv = (model, year, km, acq) => ({
          id: gid("inv"), dealId: null, model, year, km, images: [], specs: defaultSpecs(model, year),
          acquisitionPrice: acq, reconditioning: reconCost(acq), retailPrice: suggestRetail(acq),
          status: "LISTED", certified: true, points: 190 + Math.floor(Math.random() * 25),
          listedBy: "Dealership", buyerId: null, buyerName: null, saleBookingId: null, soldPrice: null,
          createdAt: new Date().toISOString(), timeline: [stamp("Listed for sale")],
        });
        const inventory = [
          mkInv(carModels[0], 2022, 21000, 620000),
          mkInv(carModels[4], 2021, 34000, 780000),
          mkInv(carModels[6], 2023, 12000, 1320000),
          mkInv(carModels[9], 2020, 61000, 2650000),
          mkInv(carModels[3], 2021, 44000, 1480000),
          mkInv(carModels[13], 2023, 9000, 690000),
        ];
        const mkBk = (customer, model, stageIdx) => ({
          id: gid("bk"), customer, model, stageIdx, closed: false, cancelled: false, createdBy: "Sales",
          createdAt: new Date().toISOString(), timeline: [stamp(`Booking opened for ${customer} · ${model}`)],
        });
        const carBookings = [
          mkBk("Vikram Rao", carModels[6], 1),    // awaiting Finance — loan file
          mkBk("Sneha Pillai", carModels[2], 3),  // awaiting Accounts — payment
          mkBk("Imran Khan", carModels[8], 6),    // awaiting Customer Care — insurance
        ];
        set((s) => ({ deals: [...deals, ...s.deals], inventory: [...inventory, ...s.inventory], carBookings: [...carBookings, ...s.carBookings] }));
      },
    }),
    { name: "dealerverse.workflow.v2" }
  )
);
