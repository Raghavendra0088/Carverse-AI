import { useMemo } from "react";
import { create } from "zustand";
import { getPlayer, synthProfile } from "../data/db";

const LS = "dealerverse.identity.v1";
let saved = null;
try { saved = JSON.parse(localStorage.getItem(LS) || "null"); } catch { saved = null; }

const persist = (identity) => {
  if (identity) localStorage.setItem(LS, JSON.stringify(identity));
  else localStorage.removeItem(LS);
};

export const useStore = create((set, get) => ({
  identity: saved,        // { kind:'employee'|'customer', id, name, dept, supervisor }
  sessionXp: 0,
  sessionEvents: [],
  liveCounts: {},         // action_code -> count logged this session (drives live mission progress)

  loginEmployee: (id, { supervisor = false, dept } = {}) => {
    const p = getPlayer(id) || synthProfile(id);
    const identity = { kind: "employee", id, name: p.name, dept: dept || p.dept, supervisor };
    persist(identity); set({ identity, sessionXp: 0, sessionEvents: [], liveCounts: {} });
  },
  loginCustomer: (id, name) => {
    const identity = { kind: "customer", id, name };
    persist(identity); set({ identity, sessionXp: 0, sessionEvents: [], liveCounts: {} });
  },
  loginBuyer: (id, name) => {
    const identity = { kind: "buyer", id, name };
    persist(identity); set({ identity, sessionXp: 0, sessionEvents: [], liveCounts: {} });
  },
  logout: () => { persist(null); set({ identity: null, sessionXp: 0, sessionEvents: [], liveCounts: {} }); },

  me: () => {
    const idn = get().identity;
    if (!idn) return null;
    if (idn.kind === "customer" || idn.kind === "buyer") return { kind: idn.kind, id: idn.id, name: idn.name };
    const p = getPlayer(idn.id) || synthProfile(idn.id);
    return { ...p, kind: "employee", dept: idn.dept || p.dept, supervisor: !!idn.supervisor };
  },

  addSessionXp: (xp, evt) => set((s) => {
    const liveCounts = { ...s.liveCounts, __any: (s.liveCounts.__any || 0) + 1 };
    if (evt && evt.action) liveCounts[evt.action] = (liveCounts[evt.action] || 0) + 1;
    return { sessionXp: s.sessionXp + xp, sessionEvents: [evt, ...s.sessionEvents].slice(0, 30), liveCounts };
  }),

  // pure mission-progress tracking from real workflow actions (no XP, no toast) —
  // XP for the action is handled by the workflow ledger; this just advances missions.
  bumpLive: (...actions) => set((s) => {
    const liveCounts = { ...s.liveCounts, __any: (s.liveCounts.__any || 0) + 1 };
    for (const a of actions) if (a) liveCounts[a] = (liveCounts[a] || 0) + 1;
    return { liveCounts };
  }),
  pushToast: (evt) => set((s) => ({ sessionEvents: [evt, ...s.sessionEvents].slice(0, 30) })),
}));

// Stable, memoized current-user profile. Use THIS in components — never useStore(s=>s.me())
// (me() builds a fresh object each call, which would loop useSyncExternalStore).
export function useMe() {
  const identity = useStore((s) => s.identity);
  return useMemo(() => {
    if (!identity) return null;
    if (identity.kind === "customer" || identity.kind === "buyer") return { kind: identity.kind, id: identity.id, name: identity.name };
    const p = getPlayer(identity.id) || synthProfile(identity.id);
    return { ...p, kind: "employee", dept: identity.dept || p.dept, supervisor: !!identity.supervisor };
  }, [identity]);
}
